#!/usr/bin/env python3
"""Check an orders.json before the bot touches Qargo.

Every source (PDF parser, photo skill, hand-written file) must produce this format.
ERRORS mean the order is wrong or incomplete and must not be filled (also when the parser itself says a
printed line did not reach the order: the "unread" list).
WARNINGS mean "look at this" - the order can still be filled.

    python3 validate_orders.py orders.json            # exit code 1 if there are errors
    python3 validate_orders.py orders.json --pdf-dir ~/Downloads

From Python:  errors, warnings = validate(orders)   # lists of (order_key, message)
The format itself is described in SCHEMA.md.
"""
import argparse, json, re, sys
from datetime import datetime, timedelta
from pathlib import Path

CUSTOMER_PREFIX = {"Sx0013x": "CT-", "Sx0014x": "SL-", "Sx0016x": "PN-", "Sx0019x": "Sx0048x-", "Sx0010x": "Sx0010x-",
                   "Sx0002x": "Sx0003x-", "Sx0066x Türkiye": "Sx0066x-", "Sx0017x": "Sx0017x-", "Sx0058x": "GL-"}
NEEDS_RITNUMMER = {"Sx0013x", "Sx0014x", "Sx0019x"}

ORDER_KEYS = {"key": True, "customer": True, "customer_reference": True, "ritnummer": False,
              "instructions": False, "source": True, "setup": False, "teardown": False,
              "consignments": True, "review": False, "unread": False, "pages": False,
              "service": False, "container": False, "vehicle_category": False, "change": False}
# the "Transport service" chosen first on Qargo's Create order page (left out = Transport)
SERVICES = ("Transport", "Container shunt", "Container import/export")
CONTAINER_KEYS = {"number": False, "scenario": False, "liner": False, "seal": False}
SCENARIOS = ("Import", "Export")                    # Qargo's "Import/export" field of Container import/export
CONSIGNMENT_KEYS = {"reference": False, "instructions": False, "pickup": True,
                    "delivery": True, "goods": False, "stops": False}
STOP_KEYS = {"location": True, "date": True, "start": False, "end": False, "duration": False,
             "reference": False, "phone": False, "note": False, "activity": False}
# an extra stop of a consignment (the container form's "Add stop"): where it goes among the form's own stops, by
# Qargo's Position option ("After Pickup full container"); its Stop action is one of Qargo's internal stop actions
EXTRA_STOP_KEYS = {k: v for k, v in STOP_KEYS.items() if k != "phone"} | {"position": True}
POSITION_RE = re.compile(r"^(Before|After) \S.*$")
LOCATION_KEYS = {"name": True, "street": True, "postcode": False, "city": False, "country": True,
                 "query": True, "store": False, "unverified": False, "no_address": False}
# a place the document names without any address (Sx0066x's rail terminal, "Köln Nord"): no street and no postcode, so
# the bot can pick no record by them and the stop stays empty unless the place has its own record (qargo_fill.py)
NAME_ONLY_KEYS = dict(LOCATION_KEYS, street=False)
GOODS_KEYS = {"quantity": False, "description": False, "weight_kg": False, "temperature_c": False}

# activities Qargo offers per stop type (None = Qargo's default for that stop)
# (the container ones are what Container shunt and Container import/export offer, read off the form 13 Oct 2026:
# Export shows a start stop "Pickup empty container", Import an end stop "Drop empty container")
ACTIVITIES = {
    "setup": {"Couple empty trailer", "Start of day", "Pickup empty container", "Couple chassis with empty container"},
    "teardown": {"Uncouple empty trailer", "End of day", "Drop empty container", "Uncouple chassis with empty container"},
    "pickup": {"Collect", "Couple trailer", "Start of day", "Pickup container", "Couple chassis with container",
               "Pickup full container"},
    "delivery": {"Delivery", "Uncouple trailer", "End of day", "Drop container", "Uncouple chassis with container",
                 "Drop full container"},
}

DATE_RE = re.compile(r"^\d{2}/\d{2}/\d{4}$")          # DD/MM/YYYY, as typed into Qargo
TIME_RE = re.compile(r"^([01]\d|2[0-3]):[0-5]\d$")     # HH:MM
POSTCODE_RE = {"NL": re.compile(r"^\d{4}[A-Z]{2}$"), "BE": re.compile(r"^\d{4}$"),
               "DE": re.compile(r"^\d{5}$")}
PHONE_RE = re.compile(r"^\+?[\d ()./-]{6,20}$")


def find_source(name, dirs):
    """first file called `name` in any of `dirs` (searched recursively), or None"""
    for d in dirs or []:
        d = Path(d).expanduser()
        if (d / name).is_file():
            return d / name
        if d.is_dir():
            hit = next((f for f in sorted(d.rglob(name)) if f.is_file() and "old" not in f.parts), None)
            if hit:
                return hit
    return None


def _keys(where, obj, spec, err):
    if not isinstance(obj, dict):
        err(f"{where}: expected an object, got {type(obj).__name__}")
        return False
    for k, required in spec.items():
        if required and obj.get(k) in (None, ""):
            err(f"{where}: '{k}' is missing or empty")
    for k in obj:
        if k not in spec:
            err(f"{where}: unknown field '{k}' (typo? the bot would ignore it)")
    return True


def _when(stop, field):
    """datetime of a stop's start/end (falls back to the other one), or None. A window that passes midnight
    (19:00-00:30) ends on the next day: Qargo keeps one date per stop and reads such a window that way"""
    t = stop.get(field) or stop.get("end" if field == "start" else "start")
    try:
        when = datetime.strptime(f"{stop['date']} {t or '00:00'}", "%d/%m/%Y %H:%M")
    except (KeyError, TypeError, ValueError):
        return None
    if field == "end" and stop.get("start") and stop.get("end") and str(stop["end"]) < str(stop["start"]):
        when += timedelta(days=1)
    return when


def _stop(where, s, kind, err, warn):
    if not _keys(where, s, EXTRA_STOP_KEYS if kind == "extra" else STOP_KEYS, err):
        return
    if kind == "extra" and s.get("position") and not (isinstance(s["position"], str) and POSITION_RE.match(s["position"])):
        err(f"{where}: position {s['position']!r} must be one of Qargo's 'Before ...' / 'After ...' options")
    d = s.get("date")
    if d is not None:
        if not isinstance(d, str) or not DATE_RE.match(d):
            err(f"{where}: date {d!r} is not DD/MM/YYYY")
        else:
            try:
                day = datetime.strptime(d, "%d/%m/%Y")
                if abs((day - datetime.now()).days) > 60:
                    warn(f"{where}: date {d} is more than 60 days from today (day/month swapped?)")
            except ValueError:
                err(f"{where}: date {d} does not exist")
    for f in ("start", "end", "duration"):
        v = s.get(f)
        if v is not None and (not isinstance(v, str) or not TIME_RE.match(v)):
            err(f"{where}: {f} {v!r} is not HH:MM")
    act = s.get("activity")
    if kind == "extra":         # the name of an internal stop action in Qargo; filled only when Qargo offers it
        if act is not None and not (isinstance(act, str) and act.strip()):
            err(f"{where}: activity must be the name of a stop action in Qargo")
    elif act is not None and act not in ACTIVITIES[kind]:
        err(f"{where}: activity {act!r} is not possible here; use one of {sorted(ACTIVITIES[kind])}")
    ph = s.get("phone")
    if ph is not None and kind in ("setup", "teardown"):
        err(f"{where}: start/end stops have no phone number in Qargo; remove 'phone'")
    elif ph is not None and (not isinstance(ph, str) or not PHONE_RE.match(ph)):
        err(f"{where}: phone {ph!r} does not look like a phone number")
    for f in ("reference", "note"):
        if s.get(f) is not None and not isinstance(s[f], str):
            err(f"{where}: {f} must be text")
    L = s.get("location")
    lw = f"{where}.location"
    name_only = isinstance(L, dict) and L.get("no_address") is True
    if not _keys(lw, L, NAME_ONLY_KEYS if name_only else LOCATION_KEYS, err):
        return
    if name_only:
        if L.get("street") or L.get("postcode"):
            err(f"{lw}: 'no_address' is for a place printed without an address; remove it or the street/postcode")
        return
    country = L.get("country") or "NL"
    pc = L.get("postcode") or ""
    if pc:
        rx = POSTCODE_RE.get(country)
        if rx and not rx.match(pc):
            err(f"{lw}: postcode {pc!r} is not a valid {country} postcode (write it without spaces, e.g. 1507CJ)")
    elif not L.get("unverified"):
        warn(f"{lw}: no postcode for {L.get('name')!r} - the bot can only match on street/name")
    if L.get("unverified"):
        warn(f"{lw}: {L.get('name')!r} was guessed from a one-line address; check the picked location")
    if L.get("store") is not None and not re.fullmatch(r"\d{4}", str(L["store"])):
        err(f"{lw}: store {L['store']!r} must be the 4-digit Sx0053x store number")
    if L.get("store") and L.get("query") != f"Winkel {L['store']}":
        warn(f"{lw}: Sx0053x store {L['store']} should be searched as 'Winkel {L['store']}', not {L.get('query')!r}")


def _place(s):
    L = s.get("location") or {}
    return (re.sub(r"\W", "", (L.get("street") or "").lower()) + (L.get("postcode") or "")) or (L.get("name") or "")


def _idle(o, cons):
    """odd trips: the truck stays at one place for hours, or nothing happens for very long (PN-B-009196-0014:
    load 11:00 and unload 19:00 at the same depot, 435 minutes 'Wachten' in between)"""
    ev = []
    for label, s in [("start stop", o.get("setup")), ("end stop", o.get("teardown"))] + \
            [(f"c{i} {r}", c.get({"collect": "pickup", "deliver": "delivery"}[r]))
             for i, c in enumerate(cons, 1) if isinstance(c, dict) for r in ("collect", "deliver")]:
        if isinstance(s, dict) and (s.get("start") or s.get("end")) and _when(s, "start"):   # date-only: no time
            ev.append((_when(s, "start"), label, _place(s), (s.get("location") or {}).get("name"),
                       "container" in (s.get("activity") or "")))
    ev.sort(key=lambda e: e[0])
    out = []
    for a, b in zip(ev, ev[1:]):
        gap = b[0] - a[0]
        if a[2] == b[2] and gap >= timedelta(hours=2):
            out.append(f"stays at {a[3]!r} for {gap} ({a[1]} {a[0]:%H:%M} -> {b[1]} {b[0]:%H:%M}) with nothing "
                       f"in between - is this a real trip? check with the customer")
        # a container terminal's Tijdslot is when the box may be fetched or brought (Sx0010x/Sx0003x 73724: 19:00-03:00
        # at ECT, unloaded at the client 17:01 the next day): a long wait next to one is the normal trip
        elif gap >= timedelta(hours=6) and not (a[4] or b[4]):
            out.append(f"nothing happens for {gap} ({a[1]} {a[0]:%H:%M} -> {b[1]} {b[0]:%H:%M}) - check the order")
    return out


def validate(orders, pdf_dirs=None):
    errors, warnings = [], []
    if not isinstance(orders, list):
        return [("-", "the file must contain a list of orders")], []
    seen = {}
    for n, o in enumerate(orders):
        key = o.get("key") if isinstance(o, dict) else None
        tag = key or f"order #{n + 1}"
        err = lambda m, t=tag: errors.append((t, m))
        warn = lambda m, t=tag: warnings.append((t, m))
        if not _keys("order", o, ORDER_KEYS, err):
            continue
        if key in seen:
            err(f"key appears twice (orders #{seen[key] + 1} and #{n + 1}); the bot would fill only one")
        seen.setdefault(key, n)
        cust = o.get("customer")
        pre = CUSTOMER_PREFIX.get(cust)
        if pre and key and not key.startswith(pre):
            err(f"key should start with {pre} for {cust}")
        if not isinstance(o.get("customer_reference"), str):
            err("customer_reference must be text (put it in quotes)")
        rit = o.get("ritnummer")
        if rit is not None and not (isinstance(rit, int) and not isinstance(rit, bool) and rit > 0):
            err(f"ritnummer {rit!r} must be a whole number or null")
        # a Sx0014x koppel rit ("route 558/220/271") has several trip numbers and so no single Ritnummer
        several = cust == "Sx0014x" and isinstance(o.get("instructions"), str) \
            and re.search(r"\broute \d+(?:/\d+)+", o["instructions"])
        if rit is None and cust in NEEDS_RITNUMMER and not several:
            warn(f"no ritnummer, but {cust} documents always have one")
        if "change" in o and not isinstance(o["change"], bool):
            err(f"change {o['change']!r} must be true or false")
        ins = o.get("instructions")
        if ins is not None and not isinstance(ins, str):
            err("instructions must be text")
        svc = o.get("service")
        if svc is not None and svc not in SERVICES:
            err(f"service {svc!r} is not one Qargo offers; use one of {list(SERVICES)}")
        box = o.get("container")
        if box is not None and not (svc or "Transport").startswith("Container"):
            err(f"container fields need a container service, not {svc or 'Transport'!r}")
        if box is not None and _keys("container", box, CONTAINER_KEYS, err):
            for f, v in box.items():
                if v is not None and not isinstance(v, str):
                    err(f"container: {f} must be text")
            sc = box.get("scenario")
            if sc is not None and sc not in SCENARIOS:
                err(f"container: scenario {sc!r} must be one of {list(SCENARIOS)}")
        vc = o.get("vehicle_category")
        if vc is not None and (not isinstance(vc, str) or not vc.strip()):
            err("vehicle_category must be text (the name of a vehicle category in Qargo, e.g. 'Chassis') or null")
        if svc == "Container import/export":
            sc = (box or {}).get("scenario")
            # (Export shows a start stop, Import an end stop; without `setup` / `teardown` the bot removes it)
            if sc not in SCENARIOS:
                err("no Import/Export scenario: Qargo requires one for 'Container import/export' and shows different "
                    "stops for each; make this order by hand")
        pg = o.get("pages")
        if pg is not None and not (isinstance(pg, list) and len(pg) == 2
                                   and all(isinstance(x, int) and not isinstance(x, bool) and x >= 1 for x in pg)
                                   and pg[0] <= pg[1]):
            err(f"pages {pg!r} must be [first, last]: whole page numbers, first <= last")
        rv = o.get("review")
        if rv is not None and not (isinstance(rv, list) and all(isinstance(x, str) and x for x in rv)):
            err("review must be a list of texts")
        elif rv:
            for x in rv:
                warn(f"check: {x}")
        ur = o.get("unread")
        if ur is not None and not (isinstance(ur, list) and all(isinstance(x, str) and x for x in ur)):
            err("unread must be a list of texts")
        elif ur:                 # the reader itself knows the order is incomplete: never fill it
            for x in ur:
                err(f"not read: {x}")
        if pdf_dirs and o.get("source") and not find_source(o["source"], pdf_dirs):
            warn(f"source file {o['source']} not found in {', '.join(map(str, pdf_dirs))}; nothing will be attached")
        cons = o.get("consignments")
        if not isinstance(cons, list) or not cons:
            err("needs at least one consignment")
            continue
        stops = []      # (label, start, end) in the order the trip is driven
        if o.get("setup") is not None:
            _stop("start stop", o["setup"], "setup", err, warn)
            stops.append(("start stop", o["setup"]))
        for i, c in enumerate(cons, 1):
            cw = f"c{i}"
            if not _keys(cw, c, CONSIGNMENT_KEYS, err):
                continue
            for f in ("reference", "instructions"):
                if c.get(f) is not None and not isinstance(c[f], str):
                    err(f"{cw}: {f} must be text")
            if c.get("pickup") is not None:
                _stop(f"{cw} collect", c["pickup"], "pickup", err, warn)
            if c.get("delivery") is not None:
                _stop(f"{cw} deliver", c["delivery"], "delivery", err, warn)
            extra = c.get("stops")
            if extra is not None and not isinstance(extra, list):
                err(f"{cw}: stops must be a list")
            elif extra:
                if not (o.get("service") or "").startswith("Container"):
                    err(f"{cw}: extra stops are only made on the container services, not {o.get('service') or 'Transport'!r}")
                for k, x in enumerate(extra, 1):
                    _stop(f"{cw} extra stop {k}", x, "extra", err, warn)
            p, d = _when(c.get("pickup") or {}, "start"), _when(c.get("delivery") or {}, "end")
            timed = lambda s: isinstance(s, dict) and bool(s.get("start") or s.get("end"))
            # a delivery with a date and no time is not "00:00": only its day can be before the collection
            if p and d and d < p and (timed(c.get("delivery")) or d.date() < p.date()):
                err(f"{cw}: delivery ({c['delivery'].get('date')} {c['delivery'].get('end') or c['delivery'].get('start')}) "
                    f"is before its collection ({c['pickup'].get('date')} {c['pickup'].get('start') or c['pickup'].get('end')})")
            elif p and d and d < p:
                # no error any more, but nobody read a time: never saved without a person looking (--save, autosave)
                warn(f"{cw} deliver: no time, on the day of its collection ({c['pickup'].get('date')} "
                     f"{c['pickup'].get('start') or c['pickup'].get('end')}); check the delivery time")
            goods = c.get("goods")
            if goods is not None and not isinstance(goods, list):
                err(f"{cw}: goods must be a list")
                goods = []
            for g_i, g in enumerate(goods or [], 1):
                gw = f"{cw} goods {g_i}"
                if not _keys(gw, g, GOODS_KEYS, err):
                    continue
                q = g.get("quantity")
                if q is not None and not (isinstance(q, (int, float)) and not isinstance(q, bool) and q > 0):
                    err(f"{gw}: quantity {q!r} must be a positive number")
                w = g.get("weight_kg")
                if w is not None and not (isinstance(w, (int, float)) and not isinstance(w, bool) and 0 < w <= 45000):
                    err(f"{gw}: weight_kg {w!r} must be a number of kg between 0 and 45000")
                t = g.get("temperature_c")      # Qargo's Requested temperature of the cargo item (a reefer's -18)
                if t is not None and not (isinstance(t, (int, float)) and not isinstance(t, bool) and -70 <= t <= 70):
                    err(f"{gw}: temperature_c {t!r} must be a number of degrees Celsius between -70 and 70")
                if q is None and not g.get("description"):
                    err(f"{gw}: empty cargo line")
        # start stop before the first collection, end stop after the last delivery
        firsts = [_when(c["pickup"], "start") for c in cons if isinstance(c, dict) and isinstance(c.get("pickup"), dict)]
        lasts = [_when(c["delivery"], "end") for c in cons if isinstance(c, dict) and isinstance(c.get("delivery"), dict)]
        firsts, lasts = [t for t in firsts if t], [t for t in lasts if t]
        su = _when(o["setup"], "start") if isinstance(o.get("setup"), dict) else None
        td = _when(o["teardown"], "end") if isinstance(o.get("teardown"), dict) else None
        if su and firsts and su > min(firsts):
            warn("start stop is later than the first collection")
        if o.get("teardown") is not None:
            _stop("end stop", o["teardown"], "teardown", err, warn)
        if td and lasts and td < max(lasts):
            warn("end stop is earlier than the last delivery")
        allt = [t for t in [su, td] + firsts + lasts if t]
        if allt and max(allt) - min(allt) > timedelta(hours=36):
            warn(f"trip spans {max(allt) - min(allt)} - wrong date somewhere?")
        for m in _idle(o, cons):
            warn(m)
    return errors, warnings


def report(errors, warnings, out=sys.stdout):
    for t, m in errors:
        print(f"ERROR   {t}: {m}", file=out)
    for t, m in warnings:
        print(f"warning {t}: {m}", file=out)


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("orders")
    ap.add_argument("--pdf-dir", action="append",
                    help="also check that each order's source file is in this folder (repeatable, searched recursively)")
    ap.add_argument("-q", "--quiet", action="store_true", help="only print errors")
    a = ap.parse_args()
    try:
        orders = json.loads(Path(a.orders).read_text(encoding="utf-8-sig"))
    except json.JSONDecodeError as e:
        print(f"ERROR   {a.orders} is not valid JSON: {e}")
        sys.exit(1)
    errors, warnings = validate(orders, a.pdf_dir)
    report(errors, [] if a.quiet else warnings)
    bad = {t for t, _ in errors}
    n = len(orders) if isinstance(orders, list) else 0
    print(f"{n} orders: {n - len(bad)} OK, {len(bad)} with errors, {len(warnings)} warnings")
    sys.exit(1 if errors else 0)


if __name__ == "__main__":
    main()
