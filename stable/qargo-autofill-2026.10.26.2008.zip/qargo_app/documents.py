"""Documents in, orders out: everything between a dropped file and a row of the list.

No browser here: this runs on the HTTP threads and on one reader thread. The operator's own files are never
moved or deleted; the program keeps a copy of each in <data>/inbox/<date>/ (the bot attaches that copy to the
order) and deletes copies older than 14 days.

PDFs are always read as ONE batch with parse_trips.parse_paths, every time a document is added: a coupling place
on one document is resolved with an address printed on another, so reading them one by one gives other orders.
"""
import datetime, hashlib, json, os, re, shutil, threading, time, traceback, urllib.parse
from pathlib import Path
import paths, parse_trips, validate_orders, messages, chat_import
from . import texts
from .server import FRESH, ACTIVE

PDF = (".pdf",)
PHOTO = (".jpg", ".jpeg", ".png", ".heic", ".heif", ".webp")
KEEP_INBOX_DAYS = 14          # the copies of the documents
KEEP_LOG_DAYS = 30
DAY = re.compile(r"\d{4}-\d{2}-\d{2}")


def safe_name(name):
    """the file's own name, never a path, whatever the browser sends; kept as it is where Windows allows it,
    because the order names its document by this name and the bot attaches it under it"""
    name = Path(urllib.parse.unquote(name or "").replace("\\", "/")).name
    name = re.sub(r'[<>:"/\\|?*\x00-\x1f]', "_", name).strip(" .") or "document"
    stem, ext = Path(name).stem, Path(name).suffix
    return stem[:140 - len(ext)] + ext


def free_name(folder, name):
    """name, or 'stem (2).pdf', 'stem (3).pdf'... if the folder already has it"""
    p, n = folder / name, 2
    while p.exists():
        p = folder / f"{Path(name).stem} ({n}){Path(name).suffix}"
        n += 1
    return p


def order_id(o):
    key = o.get("key") if isinstance(o, dict) else None
    return key.strip() if isinstance(key, str) and key.strip() else None


def check(order, dirs):
    """the validator on ONE order: (errors, warnings) as its own messages. It can crash on a malformed order
    (a number where it expects text); that order then simply cannot be filled, the others are not touched."""
    try:
        errors, warnings = validate_orders.validate([order], dirs)
    except Exception as e:
        return [f"validator crashed: {type(e).__name__}: {e}"], []
    return [m for _, m in errors], [m for _, m in warnings]


def unique(rs):
    """each sentence once. Two reasons are the same sentence when they differ only in a parameter their sentence
    does not show (the missing document, told by the validator for the order and by the bot at a stop)."""
    seen, out = set(), []
    for r in rs:
        shows = set(texts.PLACEHOLDER.findall(texts.tables()["en"].get("r." + r["code"], "")))
        mark = (r["code"], json.dumps({k: v for k, v in r["p"].items() if k in shows}, sort_keys=True, default=str))
        if mark not in seen:
            seen.add(mark)
            out.append(r)
    return out


def reasons(raw, origin, stop=None):
    """raw messages -> what the page shows, each sentence once"""
    return unique(r for r in (messages.reason(m, origin, stop) for m in raw) if messages.SEVERITY.get(r["code"]) != "info")


def sig(o):
    """which reading of the documents an order is (a row keeps the one it was made from)"""
    return hashlib.sha1(json.dumps(o, sort_keys=True, ensure_ascii=False, default=str).encode("utf-8")).hexdigest()[:10]


def row(oid, o, origin, errors, warnings):
    """the line the page shows for one order. Never the whole order: that stays in Store.full"""
    def g(d, *keys):
        for k in keys:
            d = d.get(k) if isinstance(d, dict) else None
        return d
    cons = o.get("consignments") if isinstance(o.get("consignments"), list) else []
    first = o.get("setup") or g(cons[0] if cons else {}, "pickup") or {}
    picks = {json.dumps(g(c, "pickup"), sort_keys=True, default=str) for c in cons if isinstance(c, dict)}
    text = lambda v, default="?": v if isinstance(v, str) and v else default
    return {"id": oid, "customer": text(o.get("customer")), "reference": text(o.get("customer_reference")),
            "date": text(g(first, "date"), ""), "time": text(g(first, "start") or g(first, "end"), ""),
            "stops": len(picks) + len(cons) + bool(o.get("setup")) + bool(o.get("teardown")),
            "origin": origin, "status": "invalid" if errors else "ready",
            "reasons": reasons(errors or warnings, origin), "step": None, "qargo": None,
            "change": bool(o.get("change")),        # edits the order Qargo has with this reference
            # which reading of the documents this row is (support: two machines, the same PDFs, the same marks?)
            "sig": sig(o)}


class Batch:
    """this session's documents and the orders read from them"""
    def __init__(self, app):
        self.app, self.st = app, app.store
        self.lock = threading.RLock()           # the lists below
        self.build_lock = threading.Lock()      # one rebuild of the list at a time: the last one to start wins
        self.parse_lock = threading.Lock()      # parse_trips keeps a module global: one reading at a time
        self.docs = []            # {"name", "path", "sha", "kind": "pdf" | "photo"} in the order they came
        self.parsed = []          # the orders of all PDFs, as parse_paths gave them for the whole batch
        self.pdf_unread = []      # PDFs of the batch that gave no orders: {"name", "code"}
        self.pdf_noorder = []     # PDFs the parser knows that make no order (Sx0020x day hires): {"name", "summary"}
        self.other_unread = []    # files we did not keep (wrong kind, too big, not an orders file)
        self.extra = {}           # order id -> (order, origin): orders files and chatbot answers, as they came
        self.notes = {}           # order id -> our own "app: ..." notes (they count as doubts, like the validator's)
        self.removed = set()      # orders the operator took off the list
        self.changes = set()      # orders the operator said are a change to the order Qargo has ("This is a change")
        self.pending = set()      # a change came in while the bot was filling that order: listed once it is done
        self.wake, self.more_until = threading.Event(), 0.0
        threading.Thread(target=self._reader, daemon=True, name="reader").start()

    # ---- files coming in
    def take(self, name, data, more=False, as_photo=False):
        """one dropped or chosen file. more: the page is sending further files of the same drop right now.
        as_photo: chosen on the photo screen (a scan may be a PDF: it is kept for the order, not read)"""
        name = safe_name(name)
        ext = Path(name).suffix.lower()
        if ext == ".json" and not as_photo:
            return self.take_orders_file(name, data)
        if ext not in PDF + PHOTO:
            self.unread(name, "wrong_type")
            return {"ok": False, "code": "wrong_type"}
        doc, _ = self.keep(name, data, "photo" if as_photo or ext in PHOTO else "pdf")
        if as_photo or doc["kind"] == "photo":
            return {"ok": True, "photo": doc["name"]}
        self.read_soon(more)
        return {"ok": True}

    def keep(self, name, data, kind):
        """our own copy of a document in inbox/<today>/; the same file twice is one document. -> (doc, new?)"""
        sha = hashlib.sha256(data).hexdigest()
        with self.lock:
            old = next((d for d in self.docs if d["sha"] == sha), None)
            if old:
                return old, False
            day = self.app.inbox / datetime.date.today().isoformat()
            day.mkdir(parents=True, exist_ok=True)
            path = day / name
            if not (path.is_file() and hashlib.sha256(path.read_bytes()).hexdigest() == sha):   # else: kept earlier today
                path = free_name(day, name)
                path.write_bytes(data)
            doc = {"name": path.name, "path": path, "sha": sha, "kind": kind}
            self.docs.append(doc)
            self.app.log(f"document kept: {path.name} ({len(data)} bytes, {kind})")
            return doc, True

    def unread(self, name, code):
        name = safe_name(name)
        with self.lock:
            self.other_unread = [u for u in self.other_unread if u["name"] != name] + [{"name": name, "code": code}]
        self.app.log(f"not taken: {name} ({code})")
        self.rebuild()

    def doc_dirs(self):
        """where the bot and the validator look for an order's document: the folders of this session's copies"""
        with self.lock:
            return list(dict.fromkeys(d["path"].parent for d in reversed(self.docs))) \
                or [self.app.inbox / datetime.date.today().isoformat()]

    # ---- reading the PDFs (the reader thread)
    def read_soon(self, more=False):
        self.st.update(reading=True)          # the page hides Start until the list is up to date again
        self.more_until = time.time() + 3 if more else 0.0
        self.wake.set()

    def _reader(self):
        while True:
            self.wake.wait()
            while time.time() < self.more_until:      # the rest of the same drop is on its way: read once, not 20 times
                time.sleep(0.05)
            self.wake.clear()
            try:
                self.read()
            except Exception:
                self.app.log("READER " + traceback.format_exc())
                self.st.update(problem="unexpected")
            if not self.wake.is_set():
                self.st.update(reading=False)

    def read(self):
        """the WHOLE batch through the parser again, then the list"""
        with self.lock:
            pdfs = sorted((d for d in self.docs if d["kind"] == "pdf"), key=lambda d: (d["name"], str(d["path"])))
        self.app.log(f"reading {len(pdfs)} document(s) together: {[d['name'] for d in pdfs]}")
        no_order = []
        with self.parse_lock:
            orders, skipped = parse_trips.parse_paths([str(d["path"]) for d in pdfs], no_order=no_order) if pdfs else ([], [])
        noorder = []
        for r in no_order:                    # a Sx0020x day hire: no order of its own, listed by its D-number
            self.app.log(f"no order: {r['file']}: {r['summary']}")
            noorder.append({"name": r["file"], "summary": r["summary"]})
        unread, no_tool = [], False
        for entry in skipped:                 # "name" (unknown layout) or "name (ExcType: message)"
            self.app.log(f"not read: {entry}")
            if "(PdfToolMissing:" in entry:
                no_tool = True                # one clear message, not a row per document
            elif any(entry == d["name"] for d in pdfs):
                unread.append({"name": entry, "code": "unknown_layout"})
            else:
                name = next((d["name"] for d in pdfs if entry.startswith(d["name"] + " (")), entry.split(" (")[0])
                # a ValueError is the parser's own refusal: the file opened, a value in it was not understood (the
                # reason is the "not read:" line above); anything else is a file the PDF reader could not open
                if "(ValueError:" in entry:
                    unread.append({"name": name, "code": "not_understood"})
                else:
                    unread.append({"name": name, "code": "read_error"})
        with self.lock:
            self.parsed, self.pdf_unread, self.pdf_noorder = orders, unread, noorder
        if no_tool:
            self.st.update(problem="pdf_tool_missing")
        elif self.st.read(lambda s: s["problem"]) == "pdf_tool_missing":
            self.st.update(problem=None)
        self.rebuild()

    def rebuild(self):
        """the list again from everything this session holds: leave out what done.json has and what came twice,
        validate each order by itself. Rows the bot already worked on stay exactly as they are - except for a change
        (a Routemutatie, or "This is a change"): that is new work on the same order, so it gets a fresh row, as soon
        as the bot is not busy with the old one."""
        with self.build_lock:
            with self.lock:
                cand = [(o, "pdf") for o in self.parsed] + list(self.extra.values())
                unread = self.pdf_unread + self.other_unread
                noorder = list(self.pdf_noorder)
                removed, notes, dirs, changes = set(self.removed), dict(self.notes), self.doc_dirs(), set(self.changes)
            done = self.app.done_now()
            worked = self.st.read(lambda s: {o["id"]: (o["status"], o.get("sig")) for o in s["orders"]
                                             if o["status"] not in FRESH})
            new, seen, already, dupes, replace = [], set(), 0, 0, set()
            for n, (o, origin) in enumerate(cand):
                oid = order_id(o) or f"?{n + 1}"
                if oid in seen:
                    dupes += 1                # the same order from a second document ("x.pdf" and "x (1).pdf")
                    continue
                seen.add(oid)
                if oid in changes and not o.get("change"):
                    o = dict(o, change=True)
                if oid in worked and o.get("change") and worked[oid][1] != sig(o):
                    if worked[oid][0] in ACTIVE:
                        with self.lock:
                            self.pending.add(oid)             # the engine calls rebuild() again when it is done
                        new.append((oid, None, None))
                        continue
                    replace.add(oid)                          # a change to what the bot did: new work, a fresh row
                if oid in worked and oid not in replace:
                    with self.lock:
                        self.pending.discard(oid)             # nothing new for it (any more)
                    new.append((oid, None, None))             # the bot has it: its row stays, whatever was read now
                elif oid in removed and oid not in replace:
                    continue
                elif oid in done and not o.get("change"):     # a change edits the order done.json has
                    already += 1
                else:
                    errors, warnings = check(o, dirs)
                    warnings += notes.get(oid, [])
                    for m in errors + warnings:
                        self.app.log(f"validate {oid}: {m}")
                    new.append((oid, row(oid, o, origin, errors, warnings),
                                {"order": o, "origin": origin, "warnings": warnings}))

            def put(s):
                old, rows = {r["id"]: r for r in s["orders"]}, []
                for oid, r, full in new:
                    cur = old.get(oid)
                    if cur is not None and (cur["status"] in ACTIVE if oid in replace else
                                            (cur["status"] not in FRESH or r is None)):
                        rows.append(cur)      # (also when the engine started on it while we were validating)
                        if oid in replace:
                            with self.lock:
                                self.pending.add(oid)
                    elif r is not None:
                        rows.append(r)
                        self.st.full[oid] = full
                        if oid in replace:
                            self.app.log(f"{oid}: a change to it came in ({full['order'].get('source')}): listed again "
                                         f"(was {cur['status'] if cur else '?'})")
                            with self.lock:
                                self.pending.discard(oid)
                rows += [r for r in s["orders"] if r["status"] not in FRESH and not any(x["id"] == r["id"] for x in rows)]
                for oid in [k for k in self.st.full if not any(r["id"] == k for r in rows)]:
                    del self.st.full[oid]
                s.update(orders=rows, unread=unread, noorder=noorder, left={"already": already, "dupes": dupes})
            self.st.update(put)

    # ---- orders that do not come from our parser
    def take_orders_file(self, name, data):
        """a .json file in the format of SCHEMA.md (made by parse_trips.py or by hand): taken as it is"""
        try:
            value = json.loads(data.decode("utf-8-sig"))
        except ValueError:                                        # also UnicodeDecodeError
            self.unread(name, "read_error")
            return {"ok": False, "code": "read_error"}
        orders = [value] if isinstance(value, dict) else value
        if not isinstance(orders, list) or not orders or not all(isinstance(o, dict) for o in orders):
            self.unread(name, "wrong_type")
            return {"ok": False, "code": "wrong_type"}
        self.app.log(f"orders file {name}: {len(orders)} order(s)")
        return {"ok": True, "added": self.add_extra(orders, "file", name)}

    def add_extra(self, orders, origin, tag):
        with self.lock:
            ids = []
            for n, o in enumerate(orders):
                oid = order_id(o) or f"?{tag}#{n + 1}"
                self.extra[oid] = (o, origin)
                self.removed.discard(oid)
                self.notes.pop(oid, None)
                ids.append(oid)
        self.rebuild()
        return ids

    def parse_answer(self, text, photos, driver="", customer="", batch=True):
        """a chatbot's or Claude's answer -> what is in it, adding nothing yet:
        {"orders", "unknown", "problems", "lines", "notes"}. Each order gets its photo (chat_import.photo_for) and,
        when no driver was typed, the driver its photo is named after ("Sx0055x-14-10.jpeg" -> "Sx0056x", first line
        of the Instructions). unknown: a customer Qargo does not know. problems/lines: the validator's refusals.
        batch: one answer for all the photos (the chatbot route) - then an order whose photo is not certain gets a
        note; False: one answer per photo (reader.py), where the photo is never in doubt.
        Raises chat_import.ImportProblem when the text holds nothing usable."""
        orders = chat_import.import_chat_answer(text, None, driver.strip() or None, customer.strip() or None, log=self.app.log)
        unknown = next((o["customer"] for o in orders if o["customer"] not in chat_import.CUSTOMERS), None)
        notes = {}
        for n, o in enumerate(orders):
            o["source"], sure = chat_import.photo_for(o.get("source"), photos, n, len(orders))
            if not driver.strip():
                who = chat_import.driver_from_file(o["source"])
                if who:
                    o["instructions"] = "\n".join(x for x in (who, o.get("instructions")) if x)
            if batch and len(photos) > 1 and (len(orders) == 1 or not sure):
                notes[o["key"]] = (f"app: only {o['source']} of the {len(photos)} photos is attached" if len(orders) == 1
                                   else f"app: not sure which of the {len(photos)} photos holds this trip: {o['source']} is attached")
            if len(photos) > 1:
                self.app.log(f"chatbot answer: {o['key']} -> {o['source']}" + ("" if sure else " (not sure)"))
        problems, lines = [], []
        for o in orders:
            errors, _ = check(o, None)
            lines += [f"{o['key']}: {m}" for m in errors]
            problems += [r for r in reasons(errors, "photo") if r not in problems]
        return {"orders": orders, "unknown": unknown, "problems": problems, "lines": lines, "notes": notes}

    def add_answer(self, orders, notes):
        """orders the validator accepted -> the list. -> {"ok": True, "added": [ids], "already": n}"""
        ids = self.add_extra(orders, "photo", "photo")
        if notes:
            with self.lock:
                for oid in ids:
                    if oid in notes:
                        self.notes[oid] = [notes[oid]]
            self.rebuild()
        listed = self.st.read(lambda s: [o["id"] for o in s["orders"]])
        return {"ok": True, "added": [i for i in ids if i in listed], "already": len([i for i in ids if i not in listed])}

    def import_answer(self, text, photos=(), driver="", customer=""):
        """a chatbot's answer to photo_prompt.txt -> orders in the list, or what is wrong with it in plain words.
        photos: the names take() gave for the photos the operator chose, in that order."""
        with self.lock:
            photos = [p for p in photos if any(d["name"] == p for d in self.docs)]
        refuse = lambda code, **p: {"ok": False, "problems": [{"code": code, "p": p}], "fix": ""}
        if not photos:
            return refuse("import.no_photo")
        try:
            r = self.parse_answer(text, photos, driver, customer)
        except chat_import.ImportProblem as e:
            self.app.log(f"chatbot answer refused: {e}")
            return refuse(e.key)
        if r["unknown"]:                                           # the bot could not pick such a customer in Qargo
            self.app.log(f"chatbot answer: unknown customer {r['unknown']!r}")
            return {"ok": False, "need_customer": r["unknown"] or "?", "choices": list(chat_import.CUSTOMERS),
                    "problems": [], "fix": ""}
        if r["problems"]:
            for line in r["lines"]:
                self.app.log(f"chatbot answer: {line}")
            return {"ok": False, "problems": r["problems"], "fix": texts.correction(r["lines"])}
        return self.add_answer(r["orders"], r["notes"])

    def read_photos(self, photos, driver="", customer="", lang="en"):
        """the program reads the photos itself (reader.py, with the operator's API key): one request per photo,
        all at the same time, so four route lists take as long as one. Each answer is checked as a pasted one is;
        an answer the validator refuses goes back to Claude once with the validator's own findings. The orders of
        the photos that came out right join the list; what is still wrong is shown per photo (without "copy the
        correction"). Qargo not knowing a customer stops everything until the operator chooses one."""
        from . import reader                                   # the SDK is loaded only when there is a key to use
        from concurrent.futures import ThreadPoolExecutor
        with self.lock:
            docs = [(d["name"], d["path"]) for p in photos for d in self.docs if d["name"] == p]
        refuse = lambda code, **p: {"ok": False, "problems": [{"code": code, "p": p}], "fix": ""}
        key = self.app.settings.get("claude_api_key")
        if not isinstance(key, str) or not key.strip():
            return refuse("import.no_key")
        if not docs:
            return refuse("import.no_photo")
        names = [n for n, _ in docs]
        self.app.log(f"claude: reading {len(docs)} photo(s), one request each: {', '.join(names)}")

        def one(i, doc):
            """-> (answer text, parse_answer's result or None, a problem {"code", "p"} or None, asked twice?)
            A small photo (reader.small: WhatsApp's 430-pixel copies) is still read, but each of its orders gets a
            note: the reading may be wrong, so the order is filled and waits for the operator, never saved by the bot."""
            try:
                size = reader.small(doc[1])
                if size:
                    self.app.log(f"claude: {doc[0]} is only {size[0]} x {size[1]} pixels: its orders are held for a check")
                text, history = reader.ask(key.strip(), [doc], lang, self.app.log, first=i + 1)
                r, retried = self.parse_answer(text, names, driver, customer, batch=False), False
                if r["problems"]:
                    self.app.log(f"claude: {doc[0]}: the answer was refused; asking once more with the correction")
                    text, _ = reader.ask(key.strip(), [doc], lang, self.app.log, history, texts.correction(r["lines"]), first=i + 1)
                    r, retried = self.parse_answer(text, names, driver, customer, batch=False), True
                if size:
                    for o in r["orders"]:
                        r["notes"][o["key"]] = (f"app: photo {doc[0]} is only {size[0]} x {size[1]} pixels: the reading may be "
                                                "wrong, check every number against the picture")
                return text, r, None, retried
            except reader.ReadProblem as e:
                self.app.log(f"claude: {doc[0]}: {e}")
                return "", None, {"code": e.key, "p": e.p}, False
            except chat_import.ImportProblem as e:
                self.app.log(f"claude: {doc[0]}: answer refused: {e}")
                return "", None, {"code": e.key, "p": {}}, False

        with ThreadPoolExecutor(max_workers=min(4, len(docs))) as ex:
            results = list(ex.map(lambda a: one(*a), enumerate(docs)))
        text = "\n\n".join(t for t, *_ in results if t)       # every answer, for a second import with the customer chosen
        unknown = next((r["unknown"] for _, r, _, _ in results if r and r["unknown"]), None)
        if unknown:
            self.app.log(f"claude: unknown customer {unknown!r}")
            return {"ok": False, "need_customer": unknown, "choices": list(chat_import.CUSTOMERS), "problems": [], "fix": "", "text": text}
        good, notes, problems, retried = [], {}, [], False
        for (name, _), (_, r, problem, re_) in zip(docs, results):
            if problem:
                if problem not in problems:
                    problems.append(problem)
            elif r["problems"]:
                for line in r["lines"]:
                    self.app.log(f"claude: {name}: {line}")
                problems += [x for x in r["problems"] if x not in problems]
                retried = retried or re_
            else:
                good += r["orders"]; notes.update(r["notes"])
        out = self.add_answer(good, notes) if good else {"ok": True, "added": [], "already": 0}
        if problems:
            out.update(ok=False, problems=problems, fix="", retried=retried)
        out["text"] = text
        return out

    # ---- taking things off the list
    def mark_change(self, oid):
        """the operator says this order is a change to the one Qargo already has: list it again as a change"""
        with self.lock:
            self.changes.add(oid)
        self.app.log(f"{oid}: marked as a change by the operator")
        self.rebuild()

    def remove(self, oid):
        with self.lock:
            self.removed.add(oid)
            self.extra.pop(oid, None)
        self.st.update(lambda s: s.update(orders=[o for o in s["orders"] if not (o["id"] == oid and o["status"] in FRESH)]))

    def remove_doc(self, name):
        with self.lock:
            gone = [d for d in self.docs if d["name"] == name and any(u["name"] == name for u in self.pdf_unread + self.pdf_noorder)]
            self.docs = [d for d in self.docs if d not in gone]            # our copy stays in the inbox until it is 14 days old
            self.pdf_unread = [u for u in self.pdf_unread if u["name"] != name]
            self.pdf_noorder = [u for u in self.pdf_noorder if u["name"] != name]
            self.other_unread = [u for u in self.other_unread if u["name"] != name]
        self.rebuild()



def clean_old(app, today=None):
    """Our own copies and logs do not stay forever: inbox folders after 14 days, logs, screenshots and reports
    after 30. Deleted, not put in the Trash: the documents are the operator's own files' copies, and attached
    to the orders in Qargo. Only names this program writes itself are touched."""
    today = today or datetime.date.today()
    gone = []
    for d in sorted(app.inbox.glob("*")):
        try:
            if d.is_dir() and DAY.fullmatch(d.name) and datetime.date.fromisoformat(d.name) < today - datetime.timedelta(days=KEEP_INBOX_DAYS):
                shutil.rmtree(d, ignore_errors=True)
                gone.append(f"inbox/{d.name}")
        except ValueError:
            pass
    limit = datetime.datetime.combine(today, datetime.time()).timestamp() - KEEP_LOG_DAYS * 86400
    # Next to the code (no QARGO_DATA_DIR) the logs folder is the command line's: its old logs and screenshots
    # go to the Trash by housekeeping.tidy(), where they can be taken back. Never deleted from here.
    ours = (("fill_log_*.txt", "error_*.png") if os.environ.get(paths.ENV_DATA) else ())
    for folder, patterns in ((app.logs, ours), (app.data / "reports", ("qargo-autofill-report-*.zip",))):
        for pattern in patterns:
            for f in sorted(folder.glob(pattern)):
                try:
                    if f.is_file() and f.stat().st_mtime < limit:
                        f.unlink()
                        gone.append(f.name)
                except OSError:
                    pass
    if gone:
        app.log(f"old copies and logs deleted: {gone}")
    return gone
