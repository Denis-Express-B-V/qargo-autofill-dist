"""The program reads the photos itself: the question in photo_prompt.txt goes to Claude (Anthropic's API) together
with the photos, numbered, and the answer is the same text the operator would otherwise paste from a chatbot;
documents.read_photos() takes it from there. Only used when the operator has put an API key in the settings.

The key is a secret: it goes into the client and nowhere else - never into the log, the state or the report.
The photos leave this computer: they are sent to Anthropic to be read (the settings say so to the operator).
"""
import base64, struct, subprocess, sys, tempfile, time
from pathlib import Path
import anthropic
from . import texts

# Measured on the four route lists of 2026-10-13, one request per photo, four in parallel: Sonnet 5.5 read every
# stop exactly as Opus 5.5 did (times, postcodes, phones, ERC counts) in 9 s against 22 s, at half the price;
# Haiku 5.5 (8 s) dropped the dock notes and misread a phone number. Thinking off: the reading is the same and
# the answer comes sooner.
MODEL = "claude-sonnet-5-5"
THINKING = {"type": "between_tools"}   # Sonnet 5.5's "no thinking" (the request has no tools)
EFFORT = "medium"
MAX_TOKENS = 16000                     # one trip of JSON; the answer is streamed, so no HTTP timeout
TIMEOUT = 600.0                        # seconds for one call
MEDIA = {".jpg": "image/jpeg", ".jpeg": "image/jpeg", ".png": "image/png", ".webp": "image/webp", ".gif": "image/gif",
         ".pdf": "application/pdf"}
HEIC = (".heic", ".heif")              # an iPhone's own format: the API does not take it
IMAGE_BYTES = 5 * 1024 * 1024          # the API's limit for one image
PDF_BYTES = 32 * 1024 * 1024
LONG_SIDE = 2400                       # pixels, when a photo has to be made smaller (the API reads up to ~1600 anyway)
MIN_LONG_SIDE = 800                    # pixels: under this the small print of a route list is a guess. 960 x 1280 and
                                       # 646 x 827 read fine (21 Oct 2026); at 436 x 433 Claude once answered "a clearer
                                       # photo is needed" and once read it (22 Oct 2026): such an order is checked by hand
NUMBERING = ('The photos are numbered above ("Photo 1", "Photo 2", ...): write each order\'s "source" as "photo N" '
             "with the number of the photo that trip is on.")


class ReadProblem(Exception):
    """the photos could not be read; .key is a sentence id (messages.py), .p the sentence's parameters,
    why: for the log only"""
    def __init__(self, key, why="", **p):
        super().__init__(f"{key}: {why}" if why else key)
        self.key, self.p = key, p


def sips_jpeg(path):
    """macOS: the picture as a JPEG of at most LONG_SIDE pixels on its long side (sips is part of the system)"""
    with tempfile.TemporaryDirectory() as tmp:
        out = Path(tmp) / "photo.jpg"
        r = subprocess.run(["sips", "-s", "format", "jpeg", "-s", "formatOptions", "85", "-Z", str(LONG_SIDE),
                            str(path), "--out", str(out)], capture_output=True, text=True, timeout=120)
        if r.returncode != 0 or not out.is_file():
            raise ReadProblem("import.heic", (r.stderr or r.stdout).strip()[:200], name=Path(path).name)
        return out.read_bytes()


def pixel_size(media, data):
    """-> (width, height) from the picture's own header, or None when it cannot be read there. None is "unknown",
    never "small": only a size that is read refuses a photo."""
    try:
        if media == "image/png" and data[12:16] == b"IHDR":
            w, h = struct.unpack(">II", data[16:24])
            return (w, h) if w and h else None
        if media == "image/gif" and data[:4] == b"GIF8":
            w, h = struct.unpack("<HH", data[6:10])
            return (w, h) if w and h else None
        if media == "image/jpeg" and data[:2] == b"\xff\xd8":
            i = 2
            while i + 9 < len(data):
                if data[i] != 0xFF:
                    return None
                marker = data[i + 1]
                if marker == 0xFF:                                   # fill byte
                    i += 1
                elif marker in (0xD8, 0x01) or 0xD0 <= marker <= 0xD7:   # markers without a length
                    i += 2
                elif 0xC0 <= marker <= 0xCF and marker not in (0xC4, 0xC8, 0xCC):   # a frame header: height, width
                    h, w = struct.unpack(">HH", data[i + 5:i + 9])
                    return (w, h) if w and h else None
                else:
                    i += 2 + struct.unpack(">H", data[i + 2:i + 4])[0]
        if media == "image/webp" and data[:4] == b"RIFF" and data[8:12] == b"WEBP":
            chunk = data[12:16]
            if chunk == b"VP8 " and data[23:26] == b"\x9d\x01\x2a":
                w, h = struct.unpack("<HH", data[26:30])
                return w & 0x3FFF, h & 0x3FFF
            if chunk == b"VP8L" and data[20] == 0x2F:
                b = data[21:25]
                return 1 + (b[0] | (b[1] & 0x3F) << 8), 1 + (b[1] >> 6 | b[2] << 2 | (b[3] & 0x0F) << 10)
            if chunk == b"VP8X":
                return 1 + int.from_bytes(data[24:27], "little"), 1 + int.from_bytes(data[27:30], "little")
    except (struct.error, IndexError):
        pass
    return None


def small(path):
    """-> (width, height) when the picture's long side is under MIN_LONG_SIDE, else None. Sx0020x's route lists
    come out of WhatsApp at about 430 pixels wide and will not come any bigger (22 Oct 2026): Claude still reads
    them, but every order from such a photo gets a note (documents.read_photos) that holds it from Save."""
    size = pixel_size(*prepare(path))
    return size if size and max(size) < MIN_LONG_SIDE else None


def prepare(path):
    """-> (media type, bytes) as the API takes them. HEIC and images over the API's limit are converted on macOS;
    on another system the operator is told to send a JPEG."""
    path = Path(path)
    ext = path.suffix.lower()
    data = path.read_bytes()
    if ext in HEIC or (ext in MEDIA and ext != ".pdf" and len(data) > IMAGE_BYTES):
        if sys.platform != "darwin":
            raise ReadProblem("import.heic" if ext in HEIC else "import.photo_too_big", name=path.name)
        data = sips_jpeg(path)
        if len(data) > IMAGE_BYTES:
            raise ReadProblem("import.photo_too_big", name=path.name)
        return "image/jpeg", data
    if ext not in MEDIA:
        raise ReadProblem("import.heic", f"{ext} is not a picture the API takes", name=path.name)
    if ext == ".pdf" and len(data) > PDF_BYTES:
        raise ReadProblem("import.photo_too_big", name=path.name)
    return MEDIA[ext], data


def question(photos, lang, first=1):
    """the first turn: every photo with its number (counting from `first`: its place in the operator's batch) and
    name, then the question"""
    content = []
    for i, (name, path) in enumerate(photos, first):
        media, data = prepare(path)
        content.append({"type": "text", "text": f"Photo {i}: {name}"})
        content.append({"type": "document" if media == "application/pdf" else "image",
                        "source": {"type": "base64", "media_type": media, "data": base64.standard_b64encode(data).decode("ascii")}})
    content.append({"type": "text", "text": texts.photo_prompt(lang) + "\n" + NUMBERING})
    return [{"role": "user", "content": content}]


def ask(api_key, photos, lang, log, history=None, correction=None, first=1):
    """One call to Claude. photos: [(name, path)], numbered from `first` (their place in the operator's batch, so
    the answer's "photo N" names the right one). A new conversation with the question and the photos - or, with
    `history` (returned by an earlier call) and `correction` (the validator's findings, texts.correction), the
    next turn of that conversation. -> (answer text, history for a next turn).
    Raises ReadProblem with a sentence for the operator; nothing technical reaches the page."""
    history = question(photos, lang, first) if history is None else history + [{"role": "user", "content": correction}]
    client = anthropic.Anthropic(api_key=api_key, max_retries=2, timeout=TIMEOUT)
    t0 = time.monotonic()
    try:
        with client.messages.stream(model=MODEL, max_tokens=MAX_TOKENS, thinking=THINKING, output_config={"effort": EFFORT},
                                    messages=history) as stream:
            msg = stream.get_final_message()
    except (anthropic.AuthenticationError, anthropic.PermissionDeniedError) as e:
        raise ReadProblem("import.bad_key", f"{e.status_code}")
    except anthropic.RateLimitError:
        raise ReadProblem("import.busy")
    except anthropic.BadRequestError as e:
        if "credit" in str(e).lower():
            raise ReadProblem("import.no_credit")
        raise ReadProblem("import.api_error", str(e)[:300], detail=str(e)[:120])
    except anthropic.APIStatusError as e:
        raise ReadProblem("import.api_error", f"{e.status_code} {e}"[:300], detail=f"{e.status_code}")
    except anthropic.APIConnectionError as e:            # a timeout is one of these
        raise ReadProblem("import.offline", f"{type(e).__name__}: {e}"[:300])
    text = "".join(b.text for b in msg.content if b.type == "text")
    u = msg.usage
    log(f"claude: {photos[0][0] if len(photos) == 1 else f'{len(photos)} photos'}: {msg.model} answered in "
        f"{time.monotonic() - t0:.1f} s, stop {msg.stop_reason}, tokens in {u.input_tokens} out {u.output_tokens}, "
        f"{len(text)} characters, request {getattr(msg, '_request_id', None)}")
    if msg.stop_reason == "refusal":
        raise ReadProblem("import.refused", str(getattr(msg, "stop_details", "") or "")[:200])
    if msg.stop_reason == "max_tokens":
        raise ReadProblem("import.read_cut_off")
    return text, history + [{"role": "assistant", "content": msg.content}]
