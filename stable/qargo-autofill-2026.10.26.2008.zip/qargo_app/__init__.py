"""Qargo Autofill: the operator's window around parse_trips.py, validate_orders.py and qargo_fill.py.

    python -m qargo_app        (the launcher starts it like this, with the folder of the flat modules as working directory)

  app.py        what one running program is: data folder, settings, log, single instance, support report
  engine.py     the main thread: the only code that touches the browser (Playwright's sync API)
  filler.py     the seam to qargo_fill.py (tests put a stand-in there)
  documents.py  dropped files -> orders -> rows of the list (HTTP threads and the reader thread)
  server.py     the page's state and the local web server the page talks to
  texts.py      the string tables (strings/<language>.json) and the chatbot question (photo_prompt.txt)
  page.html     the page itself: no sentence in it, only keys of the string tables
"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))      # the flat modules: paths, parse_trips, qargo_fill ...
