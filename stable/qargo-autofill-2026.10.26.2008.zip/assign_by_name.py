#!/usr/bin/env python3
"""Assign the trips of named orders to a driver you name, with that driver's truck and trailer from the planning
sheet. For the customers whose planning reaches Sx0001x outside the sheet: Sx0002x sends each
Transportopdracht PDF to one of two WhatsApp groups ("Sx0003x / Sx0004x 1 / Sx0005x", "Sx0003x / Sx0004x 2 / Sx0006x"),
and the group's driver drives it (asked 22 Oct 2026).

  .venv/bin/python assign_by_name.py --dry-run 74837="Sx0007x" 73721="Sx0008x Sx0009x"
  .venv/bin/python assign_by_name.py 74837="Sx0007x"               # Sx0002x by default
  .venv/bin/python assign_by_name.py --customer Sx0010x 363765="Sx0011x Sx0012x"

Rules, as in assign_trips.py: the driver's sheet row is the one of that customer (COMP., e.g. "Sx0003x") whose DRIVER
holds every word of the name; driver, truck and trailer each must fit exactly one Qargo resource; a trip already in
the driver's app, or assigned by a person, is left alone and listed; what the bot assigns goes in assign_state.json.
The sheet's CHARTER number is not used: for Sx0003x it is the other way round from the group names (22 Oct 2026).
"""
import argparse, datetime, sys, tempfile
from pathlib import Path
HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import paths
import planning_sheet
from assign_trips import (SHEET_JOBS, find_resource, in_app, load_state, order_of, plain, rows_by_driver, save_state,
                          trip_day, words)


def pick(driver, rows, resources):
    """[driver, tractor, trailer] Qargo resources for the sheet row of this driver, or (None, why)"""
    if not rows:
        return None, f"driver {driver} has no row in the sheet"
    if len(rows) > 1:
        return None, f"driver {driver} is in the sheet {len(rows)} times (rows {', '.join(str(e.row) for e in rows)})"
    row = rows[0]
    if not row.truck:
        return None, f"sheet row {row.row} ({row.driver}) has no truck"
    picked = []
    for kind, cell in (("DRIVER", row.driver), ("TRACTOR", row.truck), ("TRAILER", row.trailer)):
        if kind == "TRAILER" and not cell:
            continue
        r, why = find_resource(resources, kind, cell)
        if not r:
            return None, f"sheet row {row.row}: {why}"
        picked.append(r)
    return picked, None


def run(q, customer, want, entries_of, days, *, dry_run=False, state=None, now=None):
    """want: {customer reference: driver name}. Returns the report lines. q: a qargo_planning.Planning (or a
    stand-in with trips / to_plan_from / resources / assign); entries_of(day) -> sheet entries"""
    from qargo_planning import allocated
    state = state if state is not None else load_state()
    now = now or datetime.datetime.now().astimezone()
    out = []
    trips = {s["row_id"]: s for s in q.trips([d.isoformat() for d in days])}
    for s in q.to_plan_from(days[0].isoformat()):
        trips.setdefault(s["row_id"], s)
    found = {}
    for ship in trips.values():
        o = order_of(ship)
        if ((o.get("customer") or {}).get("name") or "").strip() == customer:
            found.setdefault((o.get("customer_reference_number") or "").strip(), []).append(ship)
    sheets, resources = {}, {}
    for ref, driver in want.items():
        ships = found.get(ref, [])
        if not ships:
            out.append(f"!! {customer} {ref}: no trip in Qargo's planning (not saved yet, not {customer}'s, or not "
                       f"{' / '.join(f'{d:%d-%m}' for d in days)} and not To plan)")
            continue
        for ship in ships:
            o = order_of(ship)
            label = f"{ship['name']} {o.get('name') or ''} {customer} ref {ref}"
            day = trip_day(ship) or days[0]
            if day not in sheets:
                try:
                    sheets[day] = entries_of(day)
                    resources[day] = q.resources(day.isoformat())
                except Exception as e:
                    sheets[day] = e
            if isinstance(sheets[day], Exception):
                out.append(f"!! {label}: SHEET for {day:%d-%m}: {sheets[day]}. Not assigned.")
                continue
            picked, why = pick(driver, rows_by_driver(sheets[day], customer, driver), resources[day])
            if not picked:
                out.append(f"!! {label}: {why}")
                continue
            names = " / ".join(r["name"] for r in picked)
            ids = sorted(r["row_id"] for r in picked)
            have = sorted(allocated(ship))
            rank = {"DRIVER": 0, "TRACTOR": 1, "TRAILER": 2}
            byid = {r["row_id"]: r for r in resources[day]}
            named = lambda rids: " / ".join(byid[i]["name"] if i in byid else i for i in
                                            sorted(rids, key=lambda i: (rank.get((byid.get(i) or {}).get("resource_type"), 9), i)))
            if in_app(ship):
                out.append(f"{label}: already sent to the driver's app, on {named(have) or 'nobody'}: left alone")
                continue
            if have == ids:
                out.append(f"{label}: already {names}")
                continue
            mine = state.get(ship["row_id"], {}).get("resources")
            if have and have != sorted(mine or []):
                out.append(f"!! {label}: assigned by hand in Qargo ({named(have)}); "
                           f"{driver} says {names}: left alone")
                continue
            if dry_run:
                out.append(f"{label}: WOULD {'CHANGE to' if have else 'ASSIGN'} {names} (sheet row {rows_by_driver(sheets[day], customer, driver)[0].row})")
                continue
            try:
                q.assign(ship, ids)
                state[ship["row_id"]] = {"trip": ship["name"], "resources": ids, "at": now.isoformat(),
                                         "by": f"assign_by_name {driver}"}
                save_state(state)
                out.append(f"{label}: {'CHANGED to' if have else 'ASSIGNED'} {names}")
            except Exception as e:
                out.append(f"!! {label}: not assigned: {str(e).splitlines()[0][:200]}")
    return out


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("pairs", nargs="+", metavar="REF=DRIVER", help='the order\'s customer reference and the driver, e.g. 74837="Sx0007x"')
    ap.add_argument("--customer", default="Sx0002x", help="the Qargo customer name (default: Sx0002x)")
    ap.add_argument("--dry-run", action="store_true", help="only say what it would do; nothing changes in Qargo")
    ap.add_argument("--today", help="YYYY-MM-DD (tests)")
    a = ap.parse_args(argv)
    bad = [p for p in a.pairs if "=" not in p or not words(p.split("=", 1)[1])]
    if bad:
        sys.exit(f"!! not REF=DRIVER: {bad}")
    want = {k.strip(): v.strip() for k, v in (p.split("=", 1) for p in a.pairs)}
    if a.customer not in SHEET_JOBS:
        sys.exit(f"!! {a.customer!r} has no sheet COMP. in assign_trips.SHEET_JOBS: {sorted(SHEET_JOBS)}")
    today = datetime.date.fromisoformat(a.today) if a.today else datetime.date.today()
    days = [today, today + datetime.timedelta(days=1)]
    token = {}
    def entries_of(d):
        token.setdefault("t", planning_sheet.access_token())
        return planning_sheet.entries(d, token=token["t"])
    from playwright.sync_api import sync_playwright
    from cancel_overdue import copy_profile
    from qargo_planning import Planning
    with tempfile.TemporaryDirectory(prefix="qargo-assign-") as tmp, sync_playwright() as pw:
        try:
            copy_profile(paths.profile_dir("chromium"), Path(tmp) / "profile")
            q = Planning(pw, Path(tmp) / "profile")
        except Exception as e:
            print(f"!! QARGO NOT OPENED: {str(e).splitlines()[0][:300]}. Nothing assigned.")
            return 1
        try:
            lines = run(q, a.customer, want, entries_of, days, dry_run=a.dry_run)
        finally:
            q.close()
    text = "\n".join([f"ASSIGN BY NAME {' + '.join(f'{d:%d-%m}' for d in days)}" + (" (dry run: nothing changed)" if a.dry_run else "")] + lines)
    print(text)
    if not a.dry_run:
        log = paths.logs_dir() / f"assign_log_{datetime.datetime.now():%Y%m%d_%H%M%S}.txt"
        log.write_text(text + "\n", encoding="utf-8")
        print(f"\nlog: {log}")
    return 1 if "!!" in text else 0


if __name__ == "__main__":
    sys.exit(main())
