"""The order a trip's stops should be driven in. Pure functions: Qargo's trip data in, a new order (or the reason
to leave the trip alone) out. assign_trips.py sends the order to Qargo.

Why: a "multiple collections and deliveries" order keeps each pickup next to its own delivery (Druten -> store ->
Druten -> store), Qargo's Edit route fixes it by hand (CLAUDE.md, decided with him 21 Oct 2026: the bot does it).

  by_time_windows(stops)              every customer but Sx0019x: the stops' requested time windows
  by_planning_rows(stops, vos, rows)  Sx0019x: the rows of the planning mail, in the order printed there

Both keep the trip's start stops (collect empty trailer / start of the driver's day) first and its end stops last,
and never put a delivery before its own pickup. Anything they cannot place for certain leaves the trip as it is.
"""
import datetime, re, zoneinfo
from dataclasses import dataclass

TIMEZONE = "Europe/Amsterdam"     # a stop's requested times are local; Qargo's locations carry no timezone of their own


@dataclass
class Stop:
    id: str
    seq: int                    # Qargo's current position (shipment_sequence_number)
    kind: str                   # pickup | delivery | start | end | other
    consignment: str            # consignment row id ('' for none)
    location: str               # location row id: merged stops share it
    postcode: str
    name: str
    window: tuple = None        # (start, end) ISO timestamps (UTC) when the stop has a requested time window


@dataclass
class Plan:
    order: list = None          # stop ids in the new order; None = leave the trip alone
    why: str = ""               # the reason, when order is None
    changed: bool = False       # order differs from Qargo's


def postcode(text):
    return re.sub(r"\s+", "", text or "").upper()


def window_of(stop):
    """the requested time window of Qargo's stop: (start, end) as UTC ISO timestamps, or None without one.
    It is what the trip's "Requested date" column shows: the stop's `date` plus the times of its PICKUPDELIVERY_TIME
    addon (local times; an end before the start is the next day: 19:00-00:30). NEVER estimated_*_timestamp: those
    are Qargo's own arrival times along the route as it is now, so sorting by them gives back the current order
    (Trip-0000318, 21 Oct 2026: Den Hoorn 22:11 stayed after Opmeer 00:50 because its arrival was computed 03:22)."""
    for a in stop.get("addon_instances") or []:
        if a.get("addon_type") != "PICKUPDELIVERY_TIME":
            continue
        cfg = (a.get("config") or {}).get("pickupdelivery_time") or {}
        if not (cfg.get("time_start") and stop.get("date")):
            continue                                        # opening hours as the window, or no date: no window
        try:
            tz = zoneinfo.ZoneInfo(((stop.get("location") or {}).get("timezone")) or TIMEZONE)
            day = datetime.date.fromisoformat(stop["date"])
            start = datetime.datetime.combine(day, datetime.time.fromisoformat(cfg["time_start"]), tz)
            end = datetime.datetime.combine(day, datetime.time.fromisoformat(cfg.get("time_end") or cfg["time_start"]), tz)
        except (ValueError, zoneinfo.ZoneInfoNotFoundError):
            return None
        if end < start:
            end += datetime.timedelta(days=1)
        return (start.astimezone(datetime.timezone.utc).isoformat(), end.astimezone(datetime.timezone.utc).isoformat())
    return None


def stops_of(shipment):
    """Qargo's shipment (PlanningBoardDataQuery) -> [Stop] in the current order"""
    out = []
    for s in shipment.get("actual_stops") or []:
        label = s.get("stop_activity_group") or ""
        label = (label.get("label") if isinstance(label, dict) else label or "").upper()
        kind = ("pickup" if s.get("is_pickup") else "delivery" if s.get("is_delivery")
                else "start" if label.startswith("COLLECT") else "end" if label.startswith("DROP") else "other")
        loc = s.get("location") or {}
        out.append(Stop(s["row_id"], s.get("shipment_sequence_number", 0), kind, s.get("consignment_id") or "",
                        s.get("location_id") or loc.get("row_id") or "", loc.get("postal_code") or "",
                        loc.get("name") or "", window_of(s)))
    return sorted(out, key=lambda x: x.seq)


def _finish(current, new):
    """the plan for `new` (a list of Stops), after checking that every pickup comes before its delivery"""
    if sorted(s.id for s in new) != sorted(s.id for s in current):
        return Plan(None, "the new order does not hold every stop of the trip exactly once")
    at = {s.id: i for i, s in enumerate(new)}
    for c in {s.consignment for s in new if s.consignment}:
        picks = [at[s.id] for s in new if s.consignment == c and s.kind == "pickup"]
        drops = [at[s.id] for s in new if s.consignment == c and s.kind == "delivery"]
        if picks and drops and max(picks) > min(drops):
            stop = next(s for s in new if s.consignment == c and s.kind == "delivery")
            return Plan(None, f"the delivery at {stop.name} would come before its own pickup")
    return Plan([s.id for s in new], "", [s.id for s in new] != [s.id for s in current])


def _ends(current):
    return ([s for s in current if s.kind == "start"], [s for s in current if s.kind not in ("start", "end")],
            [s for s in current if s.kind == "end"])


def by_time_windows(stops):
    """Sort the stops by their requested time windows (full timestamps, so a night past midnight sorts right).
    A stop without a window stays with the stop before it when that is the same place (Qargo gives only the first
    of two merged pickups the window); any other stop without one: leave the trip alone."""
    current = sorted(stops, key=lambda s: s.seq)
    starts, body, ends = _ends(current)
    units = []
    for s in body:
        if s.window and s.window[0]:
            units.append([s])
        elif units and units[-1][-1].location == s.location:
            units[-1].append(s)
        else:
            return Plan(None, f"the stop at {s.name} ({s.postcode}) has no time window")
    at = datetime.datetime.fromisoformat
    units.sort(key=lambda u: (at(u[0].window[0]), at(u[0].window[1] or u[0].window[0])))   # stable: ties keep their order
    return _finish(current, starts + [s for u in units for s in u] + ends)


def by_planning_rows(stops, vo_of, rows, refs=()):
    """Order the stops as the customer's planning prints them (Sx0019x's planning mail).
    vo_of: {consignment row id: VO-number}. rows: [{"action": "Laden"|"Lossen", "postcode": ..., "ref": ...,
    "vos": [...]}] in printed order, for one truck. refs: the trip's Laadreferentie(s); rows printed with another
    one belong to the truck's other trip and are skipped.
    A delivery goes where the Lossen row of its VO-number is. A pickup goes to the last Laden row at its own place
    (postcode) before that delivery: a return loaded on the way and unloaded at the end (Krimpen, Maassluis -> Druten)
    stays where it is loaded. Every stop must be placed, at the printed postcode, or the trip is left as it is."""
    current = sorted(stops, key=lambda s: s.seq)
    starts, body, ends = _ends(current)
    mine = {c: vo.upper() for c, vo in vo_of.items()}
    refs = {str(r).strip() for r in refs if str(r).strip()}
    norm = []
    for r in rows:
        ref = str(r.get("ref") or "").split("/")[0].strip()
        if refs and ref and ref not in refs:
            continue
        norm.append({"action": (r.get("action") or "").strip().capitalize(), "postcode": postcode(r.get("postcode")),
                     "vos": [v.strip().upper() for v in r.get("vos") or [] if v and v.strip()]})
    unload_at = {}
    for i, r in enumerate(norm):
        if r["action"] == "Lossen":
            for v in r["vos"]:
                unload_at.setdefault(v, i)
    pos = {}
    for s in body:
        vo = mine.get(s.consignment)
        if s.kind not in ("pickup", "delivery") or not vo or vo not in unload_at:
            return Plan(None, f"the {s.kind} at {s.name} ({vo or 'no VO-number'}) is not in the planning mail")
        at = unload_at[vo]
        if s.kind == "delivery":
            if norm[at]["postcode"] and postcode(s.postcode) != norm[at]["postcode"]:
                return Plan(None, f"{vo} is unloaded at {norm[at]['postcode']} in the mail, Qargo has {s.name} ({s.postcode})")
            pos[s.id] = (at, 1)
        else:
            loads = [i for i in range(at) if norm[i]["action"] == "Laden" and norm[i]["postcode"] == postcode(s.postcode)]
            if not loads:
                return Plan(None, f"the load of {vo} at {s.name} ({s.postcode}) is not printed before its delivery")
            pos[s.id] = (loads[-1], 0)
    new = sorted(body, key=lambda s: pos[s.id])                  # stable: merged stops keep their order
    return _finish(current, starts + new + ends)
