"""Sx0019x's planning mail: which truck (Wagen) drives which rows, in which order.

The mail ("Planning 22-10", t.Sx0087x@Sx0088x.eu, around 12:45 the day before, before the Transportopdracht PDFs) is
pictures of Sx0019x's planning rows, per Wagen:

    Hierbij de planning voor donderdag 22-10:  Wagen 1: [picture] [picture]  Wagen 2: ...  Wagen 3: Geen 1e werk rit ...

Each picture row: Laden/Lossen, town, name, postcode, weight, remarks, "<Laadreferentie> / <VO-number>".

  mail_watch.py   save_planning(): the pictures and manifest.json (date, Wagen -> pictures) into documents/
  the scheduled check (Claude) reads the pictures into plan.json next to it (format: PLAN_FORMAT below)
  assign_trips.py load_plan(): the newest plan.json for a date; a Wagen marked unsure is not used

Read-only on the mail, like mail_watch.py.
"""
import datetime, email, email.policy, json, re
from pathlib import Path

WEEKDAYS = ("maandag", "dinsdag", "woensdag", "donderdag", "vrijdag", "zaterdag", "zondag")
PLAN_FORMAT = """{"date": "YYYY-MM-DD", "wagens": [{"wagen": 1, "note": "text printed next to the Wagen, or ''",
  "unsure": false, "rows": [{"action": "Laden" or "Lossen", "place": "...", "name": "...", "postcode": "6651 KD",
  "ref": "558433", "vos": ["VO-1277064"]}]}]}"""


def is_planning_mail(sender, subject, attachments):
    """Sx0019x's planning (or 'programma <weekdag>') mail with pictures"""
    return ("Sx0088x.eu" in (sender or "").lower()
            and re.match(r"\s*(?:(?:re|fw|fwd|aw)\s*:\s*)*(?:planning|programma)\b", subject or "", re.I) is not None
            and any(a.lower().endswith((".png", ".jpg", ".jpeg", ".gif")) for a in attachments or []))


def planned_date(text, subject, received):
    """the day the mail plans: '... voor donderdag 22-10' / 'Planning 22-10' / 'programma vrijdag'; None if unclear"""
    for t in (text or "", subject or ""):
        m = re.search(r"\b(\d{1,2})[-/.](\d{1,2})(?:[-/.](\d{2,4}))?\b", t)
        if m:
            day, month = int(m.group(1)), int(m.group(2))
            year = int(m.group(3)) if m.group(3) else received.year
            year += 2000 if year < 100 else 0
            try:
                d = datetime.date(year, month, day)
            except ValueError:
                continue
            if d < received.date() - datetime.timedelta(days=180):       # 02-01 planned in late December
                d = d.replace(year=d.year + 1)
            return d
    for t in (text or "", subject or ""):
        m = re.search(r"\b(" + "|".join(WEEKDAYS) + r")\b", t, re.I)
        if m:
            ahead = (WEEKDAYS.index(m.group(1).lower()) - received.weekday()) % 7 or 7
            return received.date() + datetime.timedelta(days=ahead)
    return None


def wagens_of(text):
    """'Wagen 1: [cid:image001.png@..] [cid:image002.png@..] Wagen 3: Geen 1e werk rit [cid:..]' ->
    [{"wagen": 1, "note": "", "cids": ["image001.png@.."]}, ...] in printed order"""
    out = []
    parts = re.split(r"\bWagen\s*(\d+)\s*:?", text or "", flags=re.I)
    for n, body in zip(parts[1::2], parts[2::2]):
        body = re.split(r"\b(?:Alvast|Met vriendelijke|Mvg|Groet|Kind regards)", body, flags=re.I)[0]   # the signature
        cids = re.findall(r"\[cid:([^\]\s]+)\]", body)
        note = " ".join(re.sub(r"\[cid:[^\]]*\]", " ", body).split()).strip(" ,.")
        out.append({"wagen": int(n), "note": note, "cids": cids})
    return out


def save_planning(source, folder, received, subject, sender):
    """the pictures of one planning mail and manifest.json into folder; returns the manifest"""
    msg = email.message_from_string(source, policy=email.policy.default)
    body = msg.get_body(preferencelist=("plain", "html"))
    text = body.get_content() if body else ""
    if body is not None and body.get_content_type() == "text/html":
        text = re.sub(r"<img[^>]*src=\"cid:([^\"]+)\"[^>]*>", r" [cid:\1] ", text)
        text = re.sub(r"<[^>]+>", " ", text)
    folder.mkdir(parents=True, exist_ok=True)
    by_cid = {}
    for i, part in enumerate(msg.walk()):
        if part.get_content_maintype() != "image":
            continue
        cid = (part.get("Content-ID") or "").strip("<> ")
        name = re.sub(r"[^A-Za-z0-9._-]", "_", part.get_filename() or cid.split("@")[0] or f"picture{i}")
        (folder / name).write_bytes(part.get_payload(decode=True) or b"")
        if cid:
            by_cid[cid] = name
    wagens = []
    for w in wagens_of(text):
        wagens.append({"wagen": w["wagen"], "note": w["note"],
                       "pictures": [by_cid[c] for c in w["cids"] if c in by_cid],
                       "missing_pictures": [c for c in w["cids"] if c not in by_cid]})
    d = planned_date(text, subject, received)
    manifest = {"date": d.isoformat() if d else None, "subject": subject, "sender": sender,
                "received": received.isoformat(), "wagens": wagens, "text": " ".join(text.split())[:1500]}
    (folder / "manifest.json").write_text(json.dumps(manifest, indent=1, ensure_ascii=False), encoding="utf-8")
    return manifest


def load_plan(documents, day):
    """the newest plan.json (read from the pictures) for `day` (a date): ({wagen: [rows]}, [problems], folder)"""
    found = []
    for man in sorted(Path(documents).glob("*/mail/*/manifest.json")):
        try:
            m = json.loads(man.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            continue
        if m.get("date") == day.isoformat():
            found.append((m.get("received") or "", man.parent))
    if not found:
        return None, [f"no Sx0019x planning mail for {day:%d-%m-%Y} yet"], None
    folder = max(found)[1]
    plan_file = folder / "plan.json"
    if not plan_file.exists():
        return None, [f"the planning mail's pictures are not read yet ({folder}/plan.json missing)"], folder
    plan = json.loads(plan_file.read_text(encoding="utf-8"))
    rows, problems = {}, []
    for w in plan.get("wagens") or []:
        if w.get("unsure"):
            problems.append(f"Wagen {w.get('wagen')}: the pictures could not be read for certain")
            continue
        rows[int(w["wagen"])] = w.get("rows") or []
    return rows, problems, folder
