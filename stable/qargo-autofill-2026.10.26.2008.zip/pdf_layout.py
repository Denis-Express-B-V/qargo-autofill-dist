"""Text of a PDF in the physical layout that `pdftotext -layout` (poppler) prints - without poppler.

Why: parse_trips.py reads the customers' trip PDFs from that layout (column positions, which fragments
share a line). poppler is a C++ program that is not on a Windows PC or a Mac without Homebrew; this module
needs only the pure-Python package pdfminer.six (pip installs it everywhere).

How: pdfminer.six interprets the page and hands over every glyph (character, position, advance, font size);
the layout - words, lines, blocks, column numbers, line order - is a Python port of the "physical layout"
branch of poppler's TextOutputDev.cc (TextPage::addChar, TextBlock::coalesce, TextLine::coalesce,
TextPage::coalesce, TextPage::dump). pdfminer works in Python floats and keeps the glyph widths exactly as
the PDF gives them, so the numbers are the ones poppler computes; the page is interpreted with poppler's
own base matrix (origin top-left, y down) so that sums are made in the same order; and every real number in
the PDF is read as poppler's Lexer reads it, digit by digit (xf += scale * digit; scale *= 0.1), not with
Python's float(): the two differ in the last bit ("0.750000000" -> 0.7500000000000001), and a line break of
pdftotext can turn on that bit (int(baseline distance / font size); the Sx0066x forms, 21 Oct 2026).
Checked against pdftotext 26.10 -layout: byte-identical text for all real trip PDFs on file with hidden=True
(171 PDFs / 574 pages on 21 Oct 2026; 26 Oct 2026 also the customs declarations with a rotated title). By default one thing differs: a character drawn wholly outside the clipping path
is not on the page and is left out (poppler keeps it). In those 171 PDFs that is only the line 'Voorgaand ADR'
that every Sx0002x form hides in a text box 2.9 pt tall (it was read as an ADR flag).

Ported: text at 0/90/180/270 degrees, left-to-right, UTF-8, no fixed pitch, no HTML. Rotated text matters even
where nobody reads it: poppler gives its block a column like any other, so a title running up the left margin
(the T1 transit / customs declarations, 22-23 Oct 2026) moves every column right of it. poppler computes
rotation r as rotation 0 with the axes swapped and/or negated; the port does the same (_frame), which is exact
in floating point, and keeps the few places where poppler mixes in the raw page axes (block growing for
rotation 2 / 3, the column of a block, the place of a rotated line in the dump).
NOT ported: vertical writing mode (CJK), right-to-left reordering, text of form fields / annotations,
Type 3 font size guessing.

poppler is GPL-2.0-or-later (Copyright 1996-2011, 2022 Glyph & Cog, LLC; 2005-2026 The Poppler
Developers). This file is derived from it and is under the same licence.

    from pdf_layout import pdf_layout_text
    text = pdf_layout_text("trip.pdf")        # every page ends with a form feed, as pdftotext does
"""
import functools
import logging
import math

# ---------------------------------------------------------------- parameters (TextOutputDev.cc)
TEXT_POOL_STEP = 4                 # pool bucket height in points
MIN_WORD_BREAK_SPACE = 0.1         # gap (x font size) that starts a new word
MIN_DUP_BREAK_OVERLAP = 0.2        # overlap (x font size) that starts a new word
MAX_LINE_SPACING_DELTA = 1.5       # max baseline distance of two lines in one block
MAX_BLOCK_FONT_SIZE_DELTA1 = 0.05  # font size difference: lines above/below the block
MAX_BLOCK_FONT_SIZE_DELTA2 = 0.6   # ... text overlapping the block
MAX_BLOCK_FONT_SIZE_DELTA3 = 0.2   # ... text left/right of the block
MAX_WORD_FONT_SIZE_DELTA = 0.05
MAX_INTRA_LINE_DELTA = 0.5         # max baseline distance of two words on one line
MAX_WORD_SPACING = 1.5             # max gap between two words of one line
MIN_COL_SPACING1 = 0.7             # horizontal slack that still pulls a word into a block
MIN_COL_SPACING2 = 1.0             # minimum spacing between columns
MIN_CHAR_SPACING = -0.5
MAX_CHAR_SPACING = 0.03            # gap that becomes a space inside a line
MAX_WIDE_CHAR_SPACING_MUL = 1.3
MAX_WIDE_CHAR_SPACING = 0.4
DUP_MAX_PRI_DELTA = 0.1            # duplicated text (fake bold): max x / y distance
DUP_MAX_SEC_DELTA = 0.2

WHITESPACE = frozenset(map(chr, (0x09, 0x0A, 0x0B, 0x0C, 0x0D, 0x20, 0x85, 0xA0, 0x2000, 0x2001, 0x2002, 0x2003,
                                 0x2004, 0x2005, 0x2006, 0x2007, 0x2008, 0x2009, 0x200A, 0x2028, 0x2029, 0x202F,
                                 0x205F, 0x3000)))

# poppler does not trust the font descriptor of a non-embedded "base 14" font (or an alias such as Arial):
# it uses its built-in ascent/descent (GfxFont.cc base14FontMap + BuiltinFont.h)
_BUILTIN = {"Courier": (0.629, -0.157), "Helvetica": (0.718, -0.207), "Times": (0.683, -0.217),
            "Symbol": (1.010, -0.293), "ZapfDingbats": (0.820, -0.143)}
_BASE14 = {}            # BaseFont name (spaces removed) -> built-in family; the names of GfxFont.cc base14FontMap
for _family, _names in {
    "Helvetica": "Arial Arial,Bold Arial,BoldItalic Arial,Italic Arial-Bold Arial-BoldItalic Arial-BoldItalicMT "
                 "Arial-BoldMT Arial-Italic Arial-ItalicMT ArialMT Helvetica Helvetica,Bold Helvetica,BoldItalic "
                 "Helvetica,Italic Helvetica-Bold Helvetica-BoldItalic Helvetica-BoldOblique Helvetica-Italic "
                 "Helvetica-Oblique",
    "Courier": "Courier Courier,Bold Courier,BoldItalic Courier,Italic Courier-Bold Courier-BoldOblique "
               "Courier-Oblique CourierNew CourierNew,Bold CourierNew,BoldItalic CourierNew,Italic CourierNew-Bold "
               "CourierNew-BoldItalic CourierNew-Italic CourierNewPS-BoldItalicMT CourierNewPS-BoldMT "
               "CourierNewPS-ItalicMT CourierNewPSMT",
    "Times": "Times-Bold Times-BoldItalic Times-Italic Times-Roman TimesNewRoman TimesNewRoman,Bold "
             "TimesNewRoman,BoldItalic TimesNewRoman,Italic TimesNewRoman-Bold TimesNewRoman-BoldItalic "
             "TimesNewRoman-Italic TimesNewRomanPS TimesNewRomanPS-Bold TimesNewRomanPS-BoldItalic "
             "TimesNewRomanPS-BoldItalicMT TimesNewRomanPS-BoldMT TimesNewRomanPS-Italic TimesNewRomanPS-ItalicMT "
             "TimesNewRomanPSMT TimesNewRomanPSMT,Bold TimesNewRomanPSMT,BoldItalic TimesNewRomanPSMT,Italic",
    "Symbol": "Symbol Symbol,Bold Symbol,BoldItalic Symbol,Italic SymbolMT SymbolMT,Bold SymbolMT,BoldItalic "
              "SymbolMT,Italic",
    "ZapfDingbats": "ZapfDingbats",
}.items():
    for _name in _names.split():
        _BASE14[_name] = _family


def _builtin_metrics(font_name):
    """(ascent, descent) when poppler treats this BaseFont name as one of its 14 built-in fonts, else None"""
    family = _BASE14.get(font_name.replace(" ", ""))
    return _BUILTIN[family] if family else None


# ---------------------------------------------------------------- glyphs from pdfminer.six
def _poppler_font(font, spec):
    """Make a pdfminer font measure like poppler's GfxFont and return its (ascent, descent) per unit of
    font size. pdfminer swaps in its own metrics for fonts named like the 14 standard fonts ("Helvetica",
    "Arial", "TimesNewRoman", ...); poppler uses the PDF's /Widths whenever they are there, and the font
    descriptor's Ascent / Descent unless the font is one of its built-in ones and not embedded."""
    from pdfminer.pdffont import PDFCIDFont, PDFSimpleFont
    from pdfminer.pdftypes import resolve1

    def num(v):
        v = resolve1(v)
        return float(v) if isinstance(v, (int, float)) and not isinstance(v, bool) else None

    spec = spec if isinstance(spec, dict) else {}
    builtin = None
    if isinstance(font, PDFCIDFont):
        desc = resolve1(getattr(font, "descriptor", None))
    else:
        desc = resolve1(spec.get("FontDescriptor"))
        name = resolve1(spec.get("BaseFont"))
        builtin = _builtin_metrics(str(getattr(name, "name", name) or ""))
        widths = resolve1(spec.get("Widths"))
        if isinstance(font, PDFSimpleFont) and isinstance(widths, list) and resolve1(spec.get("Subtype")) is not None \
                and getattr(resolve1(spec.get("Subtype")), "name", "") != "Type3":
            first = num(spec.get("FirstChar")) or 0
            first = int(first) if 0 <= first <= 255 else 0
            font.widths = {first + i: w for i, w in enumerate(map(num, widths)) if w is not None}
            font.default_width = num((desc if isinstance(desc, dict) else {}).get("MissingWidth")) or 0
    if not isinstance(desc, dict):
        desc = {}
    ascent, descent = builtin or (0.95, -0.35)
    t = num(desc.get("Ascent"))
    if t is not None and 0 < abs(0.001 * t) < 3:
        ascent = abs(0.001 * t)
    t = num(desc.get("Descent"))
    if t is not None and 0 < abs(0.001 * t) < 3:
        descent = -abs(0.001 * t)
    if builtin and not any(k in desc for k in ("FontFile", "FontFile2", "FontFile3")):
        ascent, descent = builtin               # not embedded: poppler does not trust the descriptor
    return ascent, descent


def _outside(clip, x0, x1, y0, y1):
    """true when the box (x0, y0)-(x1, y1) lies wholly outside the clip box: nothing of it is drawn"""
    return x1 <= clip[0] or x0 >= clip[2] or y1 <= clip[1] or y0 >= clip[3]


# ---------------------------------------------------------------- rotation frames
# poppler's code for rotation r is its rotation-0 code with the page axes swapped and/or negated: along the
# line ("primary", u) x, y, -x, -y for r = 0..3; across it ("secondary", v, the baseline) always the raw
# page coordinate, y or x. Words, lines and blocks are built in that frame; negation is exact, so every sum
# and comparison gives poppler's bits.
def _frame(rot, x, y, dx, dy):
    """a point and an advance on the page -> (u, v, du) in the frame of rotation rot"""
    if rot == 0:
        return x, y, dx
    if rot == 1:
        return y, x, dy
    if rot == 2:
        return -x, y, -dx
    return -y, x, -dy


def _word_v(rot, base, ascent, descent):
    """the secondary extent of a word on this baseline (TextWord::setInitialBounds): the glyphs stand
    towards -v for rotation 0 and 3, towards +v for 1 and 2"""
    if rot in (0, 3):
        v0, v1 = base - ascent, base - descent
    else:
        v0, v1 = base + descent, base + ascent
    return (base, base + 1) if v0 == v1 else (v0, v1)


def _raw_box(rot, u0, u1, v0, v1):
    """a box in the frame of rotation rot -> (xMin, xMax, yMin, yMax) on the page"""
    if rot == 0:
        return u0, u1, v0, v1
    if rot == 1:
        return v0, v1, u0, u1
    if rot == 2:
        return -u1, -u0, v0, v1
    return v0, v1, -u1, -u0


def _div(a, b):
    """a / b as C computes it: no exception for b == 0"""
    if b:
        return a / b
    return math.nan if a == 0 or a != a else math.copysign(math.inf, a) * math.copysign(1.0, b)


def _c_int(v):
    """static_cast<int> on the Mac build (arm64): NaN -> 0, out of range saturates"""
    if v != v:
        return 0
    if v in (math.inf, -math.inf):
        return 2 ** 31 - 1 if v > 0 else -2 ** 31
    return int(v)


def _poppler_real(token):
    """the value poppler's Lexer gives a real number (Lexer::getObj, doReal): the integer part exact, then
    every decimal digit added as scale * digit with scale going 0.1, 0.01, ... by repeated multiplication.
    Not the nearest double: b"0.750000000" -> 0.7500000000000001, where Python's float() gives 0.75."""
    text = token.decode("latin-1")
    whole, _, fraction = text.lstrip("+-").partition(".")
    value, scale = float(int(whole)) if whole else 0.0, 0.1
    for digit in fraction:
        value = value + scale * (ord(digit) - 48)
        scale *= 0.1
    return -value if text.startswith("-") else value


def _read_reals_as_poppler():
    """pdfminer's tokenizer hands over every real number with the value poppler computes for it (see the
    module docstring). Wrapped once, on the class: pdfminer makes its own tokenizers for object streams and
    content streams, and nothing else in this program reads a PDF with pdfminer."""
    from pdfminer.psparser import PSBaseParser
    original = PSBaseParser._parse_float
    if getattr(original, "poppler_reals", False):
        return

    def _parse_float(self, s, i):
        n = len(self._tokens)
        j = original(self, s, i)
        if len(self._tokens) > n:                # the token is complete: pdfminer just made float() of it
            pos, _ = self._tokens[-1]
            self._tokens[-1] = (pos, _poppler_real(self._curtoken))
        return j

    _parse_float.poppler_reals = True
    PSBaseParser._parse_float = _parse_float


def _pages(path, max_pages=None, hidden=False):
    """yield (glyphs, page width, page height) for every page of the PDF (the first max_pages when given).
    A glyph is (char, x, y, advance, font size, font id, ascent, descent, vertical advance, rotation) in
    poppler's device space (layout_page).
    A character drawn wholly outside the clipping path is not on the page and is left out; hidden=True keeps
    it, as poppler does (pdftotext ignores clipping)."""
    from pdfminer.pdfdevice import PDFTextDevice
    from pdfminer.pdfdocument import PDFDocument
    from pdfminer.pdffont import PDFUnicodeNotDefined
    from pdfminer.pdfinterp import PDFPageInterpreter, PDFResourceManager
    from pdfminer.pdfpage import PDFPage
    from pdfminer.pdfparser import PDFParser
    from pdfminer.utils import apply_matrix_pt
    logging.getLogger("pdfminer").setLevel(logging.ERROR)
    _read_reals_as_poppler()

    class Fonts(PDFResourceManager):
        def get_font(self, objid, spec):
            font = super().get_font(objid, spec)
            if not hasattr(font, "poppler_metrics"):
                try:
                    font.poppler_metrics = (id(font),) + _poppler_font(font, spec)
                except Exception:                # an odd font dictionary must not stop the page
                    font.poppler_metrics = (id(font), 0.95, -0.35)
            return font

    class Interpreter(PDFPageInterpreter):
        """pdfminer's interpreter + the clipping path, which pdfminer ignores (W / W*): kept as its bounding box
        in device space, saved and restored with q / Q. A box is never smaller than the real clip (curves,
        even-odd, text clip and form BBox are not cut out), so it only drops text that is surely not drawn."""
        clip = None                              # (x0, y0, x1, y1); None = nothing clipped yet

        def subinterp(self):                     # a form XObject starts inside the clip of whoever draws it
            interp = super().subinterp()
            interp.clip = self.clip
            return interp

        def get_current_state(self):
            return super().get_current_state() + (self.clip,)

        def set_current_state(self, state):
            super().set_current_state(state[:3])
            self.clip = state[3]

        def do_W(self):
            pts = [apply_matrix_pt(self.ctm, seg[i:i + 2]) for seg in self.curpath for i in range(1, len(seg) - 1, 2)]
            if pts:
                xs, ys = [p[0] for p in pts], [p[1] for p in pts]
                c = self.clip or (-math.inf, -math.inf, math.inf, math.inf)
                self.clip = (max(c[0], min(xs)), max(c[1], min(ys)), min(c[2], max(xs)), min(c[3], max(ys)))

        do_W_a = do_W

        def do_TJ(self, seq):                    # Tj, ' and " come here too
            self.device.clip = None if hidden else self.clip
            super().do_TJ(seq)

    class GlyphDevice(PDFTextDevice):
        def __init__(self, rsrcmgr):
            super().__init__(rsrcmgr)
            self.glyphs, self.size, self.clip = [], 0.0, None

        def render_string(self, textstate, seq, ncs, graphicstate):
            tm, ctm, fs = textstate.matrix, self.ctm, textstate.fontsize     # GfxState::getTransformedFontSize
            x1, y1 = tm[2] * fs, tm[3] * fs
            x2, y2 = ctm[0] * x1 + ctm[2] * y1, ctm[1] * x1 + ctm[3] * y1
            self.size = math.sqrt(x2 * x2 + y2 * y2)
            super().render_string(textstate, seq, ncs, graphicstate)

        def render_char(self, matrix, font, fontsize, scaling, rise, cid, ncs, graphicstate):
            a, b, c, d, e, f = matrix
            adv = font.char_width(cid) * fontsize * scaling
            if abs(a * d) > abs(b * c):                           # TextPage::beginWord
                rot = 0 if a > 0 or d < 0 else 2
            else:
                rot = 1 if c > 0 else 3
            try:
                text = font.to_unichr(cid)
            except PDFUnicodeNotDefined:
                text = ""
            fid, ascent, descent = getattr(font, "poppler_metrics", (id(font), 0.95, -0.35))
            x, y, w, h = e + rise * c, f + rise * d, adv * a, adv * b
            if self.clip:                       # its box (as poppler measures a word) wholly clipped away?
                u0, v, du = _frame(rot, x, y, w, h)
                v0, v1 = _word_v(rot, v, ascent * self.size, descent * self.size)
                if _outside(self.clip, *_raw_box(rot, min(u0, u0 + du), max(u0, u0 + du), v0, v1)):
                    return adv
            for i, ch in enumerate(text):       # one glyph, several characters (ligature): equal shares
                self.glyphs.append((ch, x + i * (w / len(text)), y + i * (h / len(text)), w / len(text),
                                    self.size, fid, ascent, descent, h / len(text), rot))
            return adv

    with open(path, "rb") as fh:
        rsrcmgr = Fonts(caching=True)
        for number, page in enumerate(PDFPage.create_pages(PDFDocument(PDFParser(fh)))):
            if max_pages is not None and number >= max_pages:
                break
            x0, y0, x1, y1 = page.mediabox
            # poppler's base matrix at 72 dpi for an "upside down" device (GfxState constructor)
            ctm, w, h = {90: ((0, 1, 1, 0, -y0, -x0), y1 - y0, x1 - x0),
                         180: ((-1, 0, 0, 1, x1, -y0), x1 - x0, y1 - y0),
                         270: ((0, -1, -1, 0, y1, x1), y1 - y0, x1 - x0),
                         }.get(page.rotate, ((1, 0, 0, -1, -x0, y1), x1 - x0, y1 - y0))
            device = GlyphDevice(rsrcmgr)
            device.begin_page(page, ctm)
            Interpreter(rsrcmgr, device).render_contents(page.resources, page.contents, ctm=ctm)
            device.end_page(page)
            yield device.glyphs, w, h


# ---------------------------------------------------------------- TextWord / TextPool
class _Word:
    """a word in the frame of its rotation (_frame): x = along the line (u), y = across it (v)"""
    __slots__ = ("text", "edge", "edge_end", "x_min", "x_max", "y_min", "y_max", "base", "font_size",
                 "font", "space_after", "pos", "pos_end", "rot")

    def __init__(self, font_size, rot=0):
        self.text, self.edge = [], []
        self.font_size = font_size
        self.space_after = False
        self.rot = rot

    def add(self, ch, x, y, dx, font, ascent, descent, pos):
        if not self.text:                      # TextWord::setInitialBounds
            self.x_min = x
            self.y_min, self.y_max = _word_v(self.rot, y, ascent * self.font_size, descent * self.font_size)
            self.base = y
            self.font = font
            self.pos = pos
        self.text.append(ch)
        self.edge.append(x)
        self.x_max = self.edge_end = x + dx
        self.pos_end = pos + 1

    def primary_delta(self, other):            # gap from the end of this word to the start of `other`
        return other.x_min - self.x_max


class _Pool:
    """words in buckets of TEXT_POOL_STEP points of baseline (TextPool)"""

    def __init__(self):
        self.min_idx, self.max_idx = 0, -1
        self.rows = {}

    def add(self, word):
        idx = int(word.base / TEXT_POOL_STEP)
        if self.max_idx < self.min_idx and not self.rows:
            self.min_idx, self.max_idx = idx - 128, idx + 128
        while idx < self.min_idx:
            self.min_idx -= 128
        while idx > self.max_idx:
            self.max_idx += 128
        self.rows.setdefault(idx, []).append(word)

    def base_idx(self, base):
        v = base / TEXT_POOL_STEP
        if v != v or v < self.min_idx:
            return self.min_idx
        if v > self.max_idx:
            return self.max_idx
        return int(v)

    def sort(self):
        """TextPool::sort: every bucket from left to right (by the middle of the word), stable"""
        for row in self.rows.values():
            row.sort(key=lambda w: w.x_min + w.x_max)

    def row(self, idx):
        return self.rows.get(idx) or ()

    def first_row(self, start):
        """index of the first non-empty bucket at or after `start`, or None"""
        idxs = [i for i, r in self.rows.items() if r and i >= start]
        return min(idxs) if idxs else None

    def take(self, idx, keep):
        """remove and return, in order, the words of bucket idx for which keep(word) is true
        (keep is called once per word, in list order, so it may look at state the caller updates)"""
        row = self.rows.get(idx)
        if not row:
            return
        k = 0
        while k < len(row):
            if keep(row[k]):
                yield row.pop(k)
            else:
                k += 1


def _build_words(glyphs, page_w, page_h):
    """TextPage::addChar -> one pool of words per rotation"""
    pools = [_Pool() for _ in range(4)]
    cur, last_overlap, pos = None, False, 0

    def end_word():
        nonlocal cur
        if cur is not None and cur.text:
            pools[cur.rot].add(cur)
        cur = None

    for ch, x, y, w, size, font, ascent, descent, *more in glyphs:
        h, rot = more if more else (0.0, 0)
        pos += 1
        if x + w < 0 or x > page_w or y + h < 0 or y > page_h or x != x or y != y or w != w or h != h:
            continue
        if ch in WHITESPACE:
            end_word()
            continue
        if ch == "\0":
            continue
        if cur is not None and cur.text:       # measured in the frame of the word, not of the character
            u, v, _ = _frame(cur.rot, x, y, w, h)
            sp = u - cur.x_max
            delta = u - cur.edge[-1]
            fs = cur.font_size
            overlap = abs(delta) < DUP_MAX_PRI_DELTA * fs and abs(v - cur.base) < DUP_MAX_SEC_DELTA * fs
            if (overlap or last_overlap or sp < -MIN_DUP_BREAK_OVERLAP * fs or sp > MIN_WORD_BREAK_SPACE * fs
                    or abs(v - cur.base) > 0.5 or size != fs):
                end_word()
            last_overlap = overlap
        else:
            last_overlap = False
        if cur is None:
            cur = _Word(size, rot)
        if _frame(cur.rot, x, y, w, h)[2] < 0:   # drawn against its direction: one word per character
            end_word()
            cur = _Word(size, rot)
            x, y, w, h = x + w, y + h, -w, -h
        u, v, du = _frame(cur.rot, x, y, w, h)
        cur.add(ch, u, v, du, font, ascent, descent, pos)
    end_word()
    for pool in pools:
        pool.sort()                            # TextPage::endPage
    return pools


# ---------------------------------------------------------------- TextLine / TextBlock
class _Line:
    """x / y / edge in the frame of the rotation; raw (xMin, xMax, yMin, yMax) and raw_edge on the page, and
    the frag_* place in the dump (TextLineFrag::computeCoords), once the block is done"""
    __slots__ = ("words", "base", "x_min", "x_max", "y_min", "y_max", "text", "edge", "col", "len", "rot",
                 "raw", "raw_edge", "frag_x_min", "frag_x_max", "frag_y_min", "frag_y_max", "frag_base")

    def __init__(self, word):
        self.words = []
        self.rot = word.rot
        self.base = word.base
        self.x_min, self.x_max = 0.0, -1.0
        self.y_min = self.y_max = 0.0
        self.add(word)

    def add(self, w):
        self.words.append(w)
        if self.x_min > self.x_max:
            self.x_min, self.x_max, self.y_min, self.y_max = w.x_min, w.x_max, w.y_min, w.y_max
        else:
            self.x_min = min(self.x_min, w.x_min)
            self.x_max = max(self.x_max, w.x_max)
            self.y_min = min(self.y_min, w.y_min)
            self.y_max = max(self.y_max, w.y_max)

    def secondary(self):
        """the baseline as TextLine::secondaryCmp orders it: rotation 1 and 2 from the high end"""
        return self.base if self.rot in (0, 3) else -self.base

    def cmp_yx(self, other):
        if self.base != other.base:
            return -1 if self.secondary() < other.secondary() else 1
        return (self.x_min > other.x_min) - (self.x_min < other.x_min)

    def coalesce(self):
        """TextLine::coalesce: decide where the spaces are, build text / edge / col"""
        words = self.words
        if len(words) > 1:
            fs = words[0].font_size
            if len(words[0].text) > 1 or len(words[1].text) > 1:
                min_space = 0
            else:
                min_space = words[0].primary_delta(words[1])
                k = 1
                while k + 1 < len(words) and min_space > 0:
                    if len(words[k + 1].text) > 1:
                        min_space = 0
                    delta = words[k].primary_delta(words[k + 1])
                    if delta < min_space:
                        min_space = delta
                    k += 1
            if min_space <= 0:
                space = MAX_CHAR_SPACING * fs
            else:
                space = min(MAX_WIDE_CHAR_SPACING_MUL * min_space, MAX_WIDE_CHAR_SPACING * fs)
            w0, k = words[0], 1
            while k < len(words):
                w1 = words[k]
                if w0.primary_delta(w1) >= space:
                    w0.space_after = True
                    w0 = w1
                    k += 1
                elif (w0.font == w1.font and abs(w0.font_size - w1.font_size) < MAX_WORD_FONT_SIZE_DELTA * fs
                      and w1.pos == w0.pos_end):
                    w0.x_min = min(w0.x_min, w1.x_min); w0.y_min = min(w0.y_min, w1.y_min)
                    w0.x_max = max(w0.x_max, w1.x_max); w0.y_max = max(w0.y_max, w1.y_max)
                    w0.text += w1.text; w0.edge += w1.edge
                    w0.edge_end, w0.pos_end = w1.edge_end, w1.pos_end
                    del words[k]
                else:
                    w0 = w1
                    k += 1
        text, edge = [], []
        for w in words:
            text += w.text
            edge += w.edge
            if w.space_after:
                text.append(" ")
                edge.append(w.edge_end)
        edge.append(words[-1].edge_end)
        self.text, self.edge, self.len = "".join(text), edge, len(text)
        self.col = list(range(self.len + 1))


def _dup_keep(w0, w1, pri, sec):
    """TextBlock::coalesce keepSecond: (n, len(w1)) = drop the first n characters of w1; n == len -> drop w1"""
    n0, n1 = len(w0.text), len(w1.text)
    if w0.x_min > w1.x_max or w0.x_max < w1.x_min or w0.y_min > w1.y_max or w0.y_max < w1.y_min:
        return 0, n1

    def same_text(n, off=0):
        return w0.text[off:off + n] == w1.text[:n]

    def same_edges(n, off=0):
        return abs(w0.edge[off] - w1.edge[0]) < pri and abs(w0.edge[off + n - 1] - w1.edge[n - 1]) < pri

    same_height = abs(w0.y_min - w1.y_min) < sec and abs(w0.y_max - w1.y_max) < sec
    if n0 == n1 and same_text(n0):
        return (0, 0) if same_edges(n0) and same_height else (0, n1)
    if n0 < n1 and same_text(n0):
        if same_edges(n0) and same_height:
            return n0, n1
    elif n0 > n1 and same_text(n1):
        if same_edges(n1) and same_height:
            return 0, 0
    for off in range(1, n0):
        n = min(n0 - off, n1)
        if n == 0:
            break
        if same_text(n, off) and same_edges(n, off):
            return n, n1
    return 0, n1


class _Block:
    def __init__(self, word):
        self.rot = word.rot
        self.pool = _Pool()
        self.x_min, self.x_max = 0.0, -1.0
        self.y_min = self.y_max = 0.0
        self.lines, self.col, self.n_columns = [], 0, 0
        self.add(word)

    def add(self, w):
        self.pool.add(w)
        if self.x_min > self.x_max:
            self.x_min, self.x_max, self.y_min, self.y_max = w.x_min, w.x_max, w.y_min, w.y_max
        else:
            self.x_min = min(self.x_min, w.x_min)
            self.x_max = max(self.x_max, w.x_max)
            self.y_min = min(self.y_min, w.y_min)
            self.y_max = max(self.y_max, w.y_max)

    def _drop_duplicates(self):
        pool = self.pool
        for idx0 in sorted(pool.rows):
            row0 = pool.rows[idx0]
            i0 = 0
            while i0 < len(row0):
                w0 = row0[i0]
                pri, sec = DUP_MAX_PRI_DELTA * w0.font_size, DUP_MAX_SEC_DELTA * w0.font_size
                for idx1 in range(idx0, pool.base_idx(w0.base + sec) + 1):
                    row1 = pool.rows.get(idx1)
                    if not row1:
                        continue
                    k = i0 + 1 if idx1 == idx0 else 1
                    while k < len(row1):
                        first, total = _dup_keep(w0, row1[k], pri, sec)
                        if first == total:
                            del row1[k]
                            continue
                        if first:
                            w1 = row1[k]
                            del w1.text[:first]; del w1.edge[:first]
                            w1.x_min = w0.x_max
                        k += 1
                    if idx1 != idx0 and row1:
                        first, total = _dup_keep(w0, row1[0], pri, sec)
                        if first == total:
                            del row1[0]
                        elif first:
                            w1 = row1[0]
                            del w1.text[:first]; del w1.edge[:first]
                            if w1.rot == 0:              # poppler sets the raw xMin here, whatever the rotation
                                w1.x_min = w0.x_max
                            elif w1.rot == 2:
                                w1.x_max = w0.x_min
                            else:
                                w1.y_min = w0.y_max
                i0 += 1

    def coalesce(self):
        pool = self.pool
        pool.sort()
        self._drop_duplicates()

        # ---- build the lines
        lines, cur_line, start = [], None, pool.min_idx
        while True:
            start = pool.first_row(start)
            if start is None:
                break
            first = start                                    # left-most first word of the first four buckets
            for idx in range(start + 1, min(start + 4, pool.max_idx + 1)):
                if pool.row(idx) and pool.row(idx)[0].x_min < pool.row(first)[0].x_min:
                    first = idx
            w0 = pool.rows[first].pop(0)
            line = _Line(w0)
            last = w0
            fs = w0.font_size
            min_base, max_base = w0.base - MAX_INTRA_LINE_DELTA * fs, w0.base + MAX_INTRA_LINE_DELTA * fs
            lo, hi = pool.base_idx(min_base), pool.base_idx(max_base)
            while True:
                best = best_idx = None
                overlap = False
                for idx in range(lo, hi + 1):
                    for w1 in pool.row(idx):
                        if min_base <= w1.base <= max_base:
                            delta = last.primary_delta(w1)
                            if delta < MIN_CHAR_SPACING * fs:
                                overlap = True
                            elif delta < MAX_WORD_SPACING * fs and (best is None or w1.x_min < best.x_min):
                                best, best_idx = w1, idx
                            break
                    if overlap:
                        break
                if overlap or best is None:
                    break
                pool.rows[best_idx].remove(best)
                line.add(best)
                last = best
            # insert in (base, x) order, searching from the line added before this one
            k = lines.index(cur_line) + 1 if cur_line is not None and line.cmp_yx(cur_line) > 0 else 0
            while k < len(lines) and line.cmp_yx(lines[k]) > 0:
                k += 1
            lines.insert(k, line)
            cur_line = line
            line.coalesce()
        self.lines = lines

        # ---- column assignment inside the block
        self.n_columns = 0
        done = []
        for line0 in sorted(lines, key=lambda l: (l.x_min, l.secondary())):
            col1 = 0
            for line1 in done:
                if line0.x_min - line1.x_max >= 0:
                    col2 = line1.col[line1.len] + 1
                else:
                    k = 0
                    while k < line1.len and line0.x_min >= 0.5 * (line1.edge[k] + line1.edge[k + 1]):
                        k += 1
                    col2 = line1.col[k]
                col1 = max(col1, col2)
            line0.col = [c + col1 for c in line0.col]
            self.n_columns = max(self.n_columns, line0.col[line0.len])
            done.append(line0)

        # ---- the same boxes on the page (poppler keeps them so)
        self.raw = _raw_box(self.rot, self.x_min, self.x_max, self.y_min, self.y_max)
        for line in lines:
            line.raw = _raw_box(self.rot, line.x_min, line.x_max, line.y_min, line.y_max)
            line.raw_edge = line.edge if self.rot in (0, 1) else [-e for e in line.edge]
        self.char_count = sum(line.len for line in lines)


# ---------------------------------------------------------------- TextPage::coalesce / dump
def _build_blocks(pool):
    """TextPage::coalesce for the words of one rotation"""
    blocks, start = [], pool.min_idx
    while True:
        start = pool.first_row(start)
        if start is None:
            break
        first = start
        for idx in range(start + 1, min(start + 4, pool.max_idx + 1)):
            if pool.row(idx) and pool.row(idx)[0].x_min < pool.row(first)[0].x_min:
                first = idx
        w0 = pool.rows[first].pop(0)
        blk = _Block(w0)
        fs = w0.font_size
        min_base = max_base = w0.base
        col_space1, col_space2 = MIN_COL_SPACING1 * fs, MIN_COL_SPACING2 * fs
        line_space, intra = MAX_LINE_SPACING_DELTA * fs, MAX_INTRA_LINE_DELTA * fs
        found = True
        while found:
            found = False
            # words on the line above the top edge of the block
            new_min = min_base
            for idx in range(pool.base_idx(min_base), pool.base_idx(min_base - line_space) - 1, -1):
                for w in pool.take(idx, lambda w: (min_base - line_space <= w.base < min_base
                                                   and w.x_min < blk.x_max and w.x_max > blk.x_min
                                                   and abs(w.font_size - fs) < MAX_BLOCK_FONT_SIZE_DELTA1 * fs)):
                    blk.add(w)
                    found = True
                    new_min = w.base
            min_base = new_min
            # words on the line below the bottom edge of the block
            new_max = max_base
            for idx in range(pool.base_idx(max_base), pool.base_idx(max_base + line_space) + 1):
                for w in pool.take(idx, lambda w: (max_base < w.base <= max_base + line_space
                                                   and w.x_min < blk.x_max and w.x_max > blk.x_min
                                                   and abs(w.font_size - fs) < MAX_BLOCK_FONT_SIZE_DELTA1 * fs)):
                    blk.add(w)
                    found = True
                    new_max = w.base
            max_base = new_max
            # words on lines already in the block that overlap it horizontally
            for idx in range(pool.base_idx(min_base - intra), pool.base_idx(max_base + intra) + 1):
                for w in pool.take(idx, lambda w: (min_base - intra <= w.base <= max_base + intra
                                                   and w.x_min < blk.x_max + col_space1
                                                   and w.x_max > blk.x_min - col_space1
                                                   and abs(w.font_size - fs) < MAX_BLOCK_FONT_SIZE_DELTA2 * fs)):
                    blk.add(w)
                    found = True
            if found:
                continue
            # up to three words just left of the block, then just right of it (on the page: for rotation 2
            # and 3 poppler compares the raw axis, which is the other side in the frame)
            left = lambda w: w.x_max <= blk.x_min and w.x_max > blk.x_min - col_space2
            right = lambda w: w.x_min >= blk.x_max and w.x_min < blk.x_max + col_space2
            for near in ((left, right) if w0.rot in (0, 1) else (right, left)):
                def outlier(w):
                    return (min_base - intra <= w.base <= max_base + intra and near(w)
                            and abs(w.font_size - fs) < MAX_BLOCK_FONT_SIZE_DELTA3 * fs)
                lo, hi = pool.base_idx(min_base - intra), pool.base_idx(max_base + intra)
                n = sum(1 for idx in range(lo, hi + 1) if any(outlier(w) for w in pool.row(idx)))
                if 0 < n <= 3:
                    idx = lo
                    while idx <= pool.base_idx(max_base + intra):       # max_base can grow in this loop
                        w = next((w for w in pool.row(idx) if outlier(w)), None)
                        if w is not None:
                            pool.rows[idx].remove(w)
                            blk.add(w)
                            if w.base < min_base:
                                min_base = w.base
                            elif w.base > max_base:
                                max_base = w.base
                            found = True
                        idx += 1
        blk.coalesce()
        blocks.append(blk)
    return blocks


def _primary(rot, box):
    """(min, max, tie-break) of a page box (xMin, xMax, yMin, yMax) along the primary axis of rotation rot:
    the order of TextBlock::cmpXYPrimaryRot and the axis of the column assignment in TextPage::coalesce"""
    x0, x1, y0, y1 = box
    return {0: (x0, x1, y0), 1: (y0, y1, -x1), 2: (-x1, -x0, -y0), 3: (-y1, -y0, x1)}[rot]


def _assign_block_columns(blocks, primary_rot):
    done = []
    for blk0 in sorted(blocks, key=lambda b: (_primary(primary_rot, b.raw)[0], _primary(primary_rot, b.raw)[2])):
        p0 = _primary(primary_rot, blk0.raw)[0]
        col1 = 0
        for blk1 in done:
            q0, q1, _ = _primary(primary_rot, blk1.raw)
            if p0 > q1:
                col2 = blk1.col + blk1.n_columns + 3
            elif q1 == q0:
                col2 = blk1.col
            else:
                col2 = blk1.col + int((p0 - q0) / (q1 - q0) * blk1.n_columns)
            col1 = max(col1, col2)
        blk0.col = col1
        for line in blk0.lines:
            line.col = [c + col1 for c in line.col]
        done.append(blk0)
    return done


def _frag_coords(line, blk, one_rot, primary_rot):
    """TextLineFrag::computeCoords for a whole line: where the dump places it on the page"""
    x0, x1, y0, y1 = line.raw
    e0, e1 = line.raw_edge[0], line.raw_edge[line.len]
    if one_rot or (line.rot == 0 and primary_rot == 0):
        rot = line.rot if one_rot else 0
        line.frag_x_min, line.frag_x_max, line.frag_y_min, line.frag_y_max = {
            0: (e0, e1, y0, y1), 1: (x0, x1, e0, e1), 2: (e1, e0, y0, y1), 3: (x0, x1, e1, e0)}[rot]
        line.frag_base = line.base
        return
    bx0, bx1, by0, by1 = blk.raw
    bw, bh = bx1 - bx0, by1 - by0
    if line.rot == 0:
        d = (_div(e0 - bx0, bw), _div(e1 - bx0, bw), _div(y0 - by0, bh), _div(y1 - by0, bh), _div(line.base - by0, bh))
    elif line.rot == 1:
        d = (_div(e0 - by0, bh), _div(e1 - by0, bh), _div(bx1 - x1, bw), _div(bx1 - x0, bw), _div(bx1 - line.base, bw))
    elif line.rot == 2:
        d = (_div(bx1 - e0, bw), _div(bx1 - e1, bw), _div(by1 - y1, bh), _div(by1 - y0, bh), _div(by1 - line.base, bh))
    else:
        d = (_div(by1 - e0, bh), _div(by1 - e1, bh), _div(x0 - bx0, bw), _div(x1 - bx0, bw), _div(line.base - bx0, bw))
    d0, d1, d2, d3, d4 = d
    if primary_rot == 0:
        f = (bx0 + d0 * bw, bx0 + d1 * bw, by0 + d2 * bh, by0 + d3 * bh, by0 + d4 * bh)
    elif primary_rot == 1:
        f = (bx1 - d3 * bw, bx1 - d2 * bw, by0 + d0 * bh, by0 + d1 * bh, bx1 - d4 * bw)
    elif primary_rot == 2:
        f = (bx1 - d1 * bw, bx1 - d0 * bw, by1 - d3 * bh, by1 - d2 * bh, by1 - d4 * bh)
    else:
        f = (bx0 + d2 * bw, bx0 + d3 * bw, by1 - d1 * bh, by1 - d0 * bh, bx0 + d4 * bw)
    line.frag_x_min, line.frag_x_max, line.frag_y_min, line.frag_y_max, line.frag_base = f


def _std_sort(items, less):
    """std::sort as the C++ library of the Mac build of poppler (libc++) does it for fewer than 24
    elements: fixed swaps for 3, 4 and 5 elements, insertion sort above that. poppler's fragment
    comparison is not a consistent order when texts overlap, so the result depends on the algorithm."""
    a, n = list(items), len(items)

    def swap_if_less(i, j):                    # a[j] < a[i] -> swap; says whether it swapped
        if less(a[j], a[i]):
            a[i], a[j] = a[j], a[i]
            return True
        return False

    def sort3():
        if not less(a[1], a[0]):
            if less(a[2], a[1]):
                a[1], a[2] = a[2], a[1]
                swap_if_less(0, 1)
        elif less(a[2], a[1]):
            a[0], a[2] = a[2], a[0]
        else:
            a[0], a[1] = a[1], a[0]
            swap_if_less(1, 2)

    if n == 2:
        swap_if_less(0, 1)
    elif 3 <= n <= 5:
        sort3()
        for last in range(3, n):               # __sort4 / __sort5: sink the next element
            k = last
            while k > 0 and swap_if_less(k - 1, k):
                k -= 1
    elif 5 < n < 24:
        for i in range(1, n):
            if less(a[i], a[i - 1]):
                t, j = a[i], i
                while True:
                    a[j] = a[j - 1]
                    j -= 1
                    if j == 0 or not less(t, a[j - 1]):
                        break
                a[j] = t
    elif n >= 24:                              # pdqsort in libc++; same result whenever the order is consistent
        a.sort(key=functools.cmp_to_key(lambda x, y: -1 if less(x, y) else (1 if less(y, x) else 0)))
    return a


def _dump(blocks, primary_rot):
    """TextPage::dump, physical layout branch: the lines of all blocks, top to bottom, at their columns"""
    pairs = [(line, blk) for blk in blocks for line in blk.lines if line.len]
    one_rot = len({line.rot for line, _ in pairs}) == 1
    for line, blk in pairs:
        _frag_coords(line, blk, one_rot, primary_rot)
    frags = [line for line, _ in pairs]

    def yx(rot):                               # TextLineFrag::cmpYXLineRot / cmpYXPrimaryRot
        return lambda l: {0: (l.frag_y_min, l.frag_x_min), 1: (-l.frag_x_max, l.frag_y_min),
                          2: (-l.frag_y_min, -l.frag_x_max), 3: (l.frag_x_max, -l.frag_y_max)}[rot]

    def across(rot, l):                        # the axis that puts overlapping columns in order
        return {0: l.frag_y_min, 1: -l.frag_x_max, 2: -l.frag_y_min, 3: l.frag_x_max}[rot]

    if one_rot:
        frags.sort(key=lambda l: yx(l.rot)(l))
    else:
        frags.sort(key=yx(primary_rot))

    def before(f1, f2):                        # TextLineFrag::cmpXYColumnLineRot / cmpXYColumnPrimaryRot
        if f1.col[0] < f2.col[f2.len] and f2.col[0] < f1.col[f1.len]:      # columns overlap: top one first
            rot = f1.rot if one_rot else primary_rot
            return across(rot, f1) < across(rot, f2)
        return f1.col[0] < f2.col[0]

    i = 0
    while i < len(frags):                      # fragments on one baseline (+- half a font size): by column
        delta = MAX_INTRA_LINE_DELTA * frags[i].words[0].font_size
        j = i + 1
        while j < len(frags) and abs(frags[j].frag_base - frags[i].frag_base) < delta:
            j += 1
        frags[i:j] = _std_sort(frags[i:j], before)
        i = j

    out, col = [], 0
    for i, frag in enumerate(frags):
        if col < frag.col[0]:
            out.append(" " * (frag.col[0] - col))
            col = frag.col[0]
        out.append(frag.text)
        col += frag.len
        if i == len(frags) - 1:
            out.append("\n")
        else:
            nxt, fs = frags[i + 1], frag.words[0].font_size
            if nxt.col[0] < col or abs(nxt.frag_base - frag.frag_base) > MAX_INTRA_LINE_DELTA * fs:
                out.append("\n" * min(max(_c_int((nxt.frag_base - frag.frag_base) / fs), 1), 5))
                col = 0
    return "".join(out)


def layout_page(glyphs, page_w, page_h):
    """glyphs of one page -> its text as `pdftotext -layout` prints it (without the form feed).
    A glyph is (char, x, y, advance, font size, font id, ascent, descent[, vertical advance, rotation]): x, y =
    origin on the baseline in points from the top-left corner of the page, y pointing down; advance = how far
    the glyph moves the pen along x (vertical advance: along y, default 0); ascent / descent per unit of font
    size; rotation 0-3 = poppler's 0 / 90 / 180 / 270 degrees (default 0, upright)."""
    blocks, counts = [], [0] * 4
    for rot, pool in enumerate(_build_words(glyphs, page_w, page_h)):
        for blk in _build_blocks(pool):
            blocks.append(blk)
            counts[rot] += blk.char_count
    primary_rot = 0
    for rot in range(4):                       # the rotation with the most characters, the first on a tie
        if counts[rot] > counts[primary_rot]:
            primary_rot = rot
    return _dump(_assign_block_columns(blocks, primary_rot), primary_rot)


def pdf_layout_text(path, max_pages=None, hidden=False):
    """the whole PDF as `pdftotext -layout <path> -` prints it: every page ends with a form feed.
    max_pages=1 reads only the first page (`pdftotext -l 1`): enough to recognise a document, and quick
    even for a 300-page PDF that happens to sit in the Downloads folder.
    Text clipped away (not drawn on the page) is left out; hidden=True keeps it, exactly as pdftotext does."""
    return "".join(layout_page(*page) + "\f" for page in _pages(str(path), max_pages, hidden))


if __name__ == "__main__":
    import sys
    sys.stdout.reconfigure(encoding="utf-8", newline="\n")
    for _path in sys.argv[1:]:
        sys.stdout.write(pdf_layout_text(_path))
