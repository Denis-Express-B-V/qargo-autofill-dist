"""OpenStreetMap (Nominatim, no key needed): the postcode of a Belgian or German address, where the BAG register
(bag.py) has nothing. Used to settle "postcode differs" when a record on the printed street, number and town has
another postcode (26 Oct 2026, CT-4019584: "Schampbergstraat 22, 3500 Hasselt" printed, Qargo's record has 3511,
the map puts number 22 in 3511 Kuringen, a part of Hasselt).

Only an exact hit (the printed street and house number in the printed town) gives a postcode; anything else is
"not found" (None). No answer within ANSWER_S is its own outcome (OsmNoAnswer), never "not found".
Nominatim asks for a named client and at most one question a second: the bot asks a few per run at most.
"""
import json, urllib.error, urllib.parse, urllib.request
from bag import house, plain

URL = "https://nominatim.openstreetmap.org/search"
ANSWER_S = 20
AGENT = "qargo-autofill/1.0 (address check)"
TOWN_KEYS = ("city", "town", "village", "municipality", "suburb", "city_district")


class OsmNoAnswer(Exception):
    pass


def fetch(street, town, country):
    """the map's hits for the address, as Nominatim returns them (a list of dicts)"""
    name, nr = house(street)
    q = urllib.parse.urlencode({"street": f"{nr} {name}", "city": town, "countrycodes": country.lower(),
                                "format": "jsonv2", "addressdetails": 1, "limit": 10})
    try:
        req = urllib.request.Request(f"{URL}?{q}", headers={"User-Agent": AGENT})
        with urllib.request.urlopen(req, timeout=ANSWER_S) as r:
            return json.loads(r.read().decode("utf-8"))
    except (urllib.error.URLError, TimeoutError, OSError, ValueError) as e:
        raise OsmNoAnswer(f"NO ANSWER from OpenStreetMap within {ANSWER_S} s (internet?): {e}")


def postcode(street, city, country, fetch=fetch):
    """'Schampbergstraat 22', 'Hasselt', 'BE' -> '3511'; None when the map has no such address in that town"""
    name, nr = house(street)
    town = plain(city)
    if not name or not nr or not town:
        return None
    for d in fetch(street, town, country):
        a = d.get("address") or {}
        if (plain(a.get("road")) == name and plain(a.get("house_number")).replace(" ", "") == nr
                and town in {plain(a.get(k)) for k in TOWN_KEYS} and a.get("postcode")):
            return a["postcode"].strip()
    return None
