"""Sx0058x (Sx0059x Intermodal, Istanbul): the drivers' container jobs for the next day, mailed as a table
(rule in MAPPING.md, "Sx0058x").

Sx0058x sends no order document. Around 16:00-17:00 a mail "Sx0018x | Sx0060x'S SCHEDULE: 23.10.2026" (one per
driver and day; "RE:" with a new table when it changes, or with the papers added) comes to
planning.containers@Sx0061x-express.nl from Sx0057x.com.tr. Its text holds one or more tables, one row per
container; the container's CMR ("26I02505EX_CNEU4667742_GLI....pdf") and T1 customs paper are attached.

  a delivery (a full box from a rail terminal to a client, the empty box to a depot):
    FULL PICK UP | EMPTY DROP OFF | DELIVERY DATE | CONTAINER NO | DELIVERY ADDRESS | CUSTOMS ADDRESS | [NOTES] | [PLANNING]
  a loading (an empty box loaded at a client, the full box to a rail terminal):
    LOADING DATE | CONTAINER NO | LOADING ADDRESS | CUSTOMS ADDRESS | NOTES or DROP OFF [ADDRESS] | [PLANNING]

    is_schedule(sender, subject)            the schedule mails (and their "RE:")
    schedule_of(source)                     the rows of the raw mail: {"rows": [{column: cell}], "quoted": bool,
                                            "text": the words of the mail's own part}. Tables under a quoted older
                                            mail ("From: ... Sent: ...") count only when the mail's own part has none
    write_rows(rows, folder, ...)           one small PDF per row (the row as "LABEL: value" lines, with the mail's
                                            subject and the names of its CMR / T1 files, for the record), so the
                                            order carries what Sx0058x sent and run.py / the parser read it like
                                            any document
    is_Sx0057x_text(text)                  a PDF written by write_rows
    parse_text(text, source)                the order in such a PDF's text (parse_trips.py calls it)
"""
import datetime, email, email.policy, html, os, re, unicodedata
from pathlib import Path

CUSTOMER, PREFIX = "Sx0058x", "GL-"
SENDER = "Sx0057x"
SUBJECT = re.compile(r"^\s*(?:(?:re|fw|fwd|aw|ynt)\s*:\s*)*Sx0018x\s*\|\s*(?P<driver>.+?)['’`´]?S\s+SCHEDULE\s*:?\s*"
                     r"(?P<d>\d{1,2})[.\-/](?P<m>\d{1,2})[.\-/](?P<y>\d{4})", re.I)
TITLE = "Sx0058x schedule"
DELIVERY_COLUMNS = ("FULL PICK UP", "EMPTY DROP OFF", "DELIVERY DATE", "CONTAINER NO", "DELIVERY ADDRESS",
                    "CUSTOMS ADDRESS", "NOTES", "PLANNING")
LOADING_COLUMNS = ("LOADING DATE", "CONTAINER NO", "LOADING ADDRESS", "CUSTOMS ADDRESS", "DROP OFF", "DROP OFF ADDRESS",
                   "NOTES", "PLANNING")
COLUMNS = tuple(dict.fromkeys(DELIVERY_COLUMNS + LOADING_COLUMNS))
# a quoted older mail under the new text (Outlook, Apple Mail, Dutch / German / Turkish clients)
QUOTE = re.compile(r"(?i)(?:<b>|\b)(?:From|Van|Von|Kimden)\s*:|-----\s*Original Message\s*-----|Oorspronkelijk bericht"
                   r"|\bwrote:\s*(?:<|$)|\bschreef(?: het volgende)?:\s*<|\bschrieb:\s*<")
BOX = re.compile(r"\b([A-Z]{4})\s?(\d{7})\b")
PICKUP = re.compile(r"^\s*(?:ETA\s+)?(?P<place>[^:]+?)\s*:?\s*(?:READY(?:\s+(?:FOR\s+)?PICK\s*-?\s*UP)?\b"
                    r"|(?P<eta>\d{1,2}[.\-/]\d{1,2}(?:[.\-/]\d{4})?(?:\s*-?\s*\d{1,2}[:.]\d{2})?))?"
                    r"\s*(?:REF(?:ERENCE)?\s*:?\s*(?P<ref>.+?))?\s*$", re.I)
DROP = re.compile(r"^(?P<place>.+?)\s*(?:-+>|→|=>|:)\s*(?P<box>[A-Z]{4}\s?\d{7})\s*(?P<mt>MT)?\s*$")
WHEN = re.compile(r"^(?P<d>\d{1,2})[.\-/](?P<m>\d{1,2})[.\-/](?P<y>\d{4})\s*(?:-\s*)?(?P<t>\d{1,2}[:.]\d{2})?\s*(?P<rest>.*?)\s*$")
REF_LABEL = re.compile(r"^(?:[^\s:\d]+\s+)*REF(?:ERENCE)?\s*:?\s*", re.I)      # 'REF: ', 'UNLOADING REF : '
CUSTOMS_AT_DELIVERY = re.compile(r"^\s*CUSTOMS\s*@\s*DELIVERY\s*(?:POINT|PLACE|ADDRESS)?\s*$", re.I)
CUSTOMS_AT_LOADING = re.compile(r"^\s*(?:DOCUMENTS?\s+WILL\s+BE\s+GIVEN\s+(?:FROM|BY|AT)\s+(?:THE\s+)?LOADING\s+"
                                r"(?:ADDRESS|PLACE|POINT)|CUSTOMS\s*@\s*LOADING\s*(?:POINT|PLACE|ADDRESS)?)\s*\.?\s*$", re.I)
EMPTY_PICKUP = re.compile(r"^\s*PICK\s*-?\s*UP\s*:?\s*(?P<place>.+?)\s*(?:REF(?:ERENCE)?\s*:?\s*(?P<ref>.+?))?\s*$", re.I)
DROP_TERMINAL = re.compile(r"DROP\s*(?:OFF\s*)?TERMINAL\s*:?\s*(?P<place>.+?)\s*(?:DROP\s*(?:OFF\s*)?REF(?:ERENCE)?\s*:?\s*(?P<ref>.+?))?\s*$", re.I)
UNKNOWN = re.compile(r"^\s*(?:WILL\s+BE\s+SHARED|TBA|TBC|TBD|\?+|-+|N/?A)\s*\.?\s*$", re.I)
REPLY = re.compile(r"^\s*(?:(?:re|fw|fwd|aw|ynt)\s*:\s*)+", re.I)
COUNTRY = {"hollanda": "NL", "nederland": "NL", "netherlands": "NL", "the netherlands": "NL", "holland": "NL", "nl": "NL",
           "almanya": "DE", "germany": "DE", "deutschland": "DE", "de": "DE",
           "belçika": "BE", "belcika": "BE", "belgium": "BE", "belgië": "BE", "belgie": "BE", "be": "BE"}
PC_RE = {"NL": r"(?<![\dA-Z])(\d{4})\s?([A-Z]{2})(?![A-Z])", "DE": r"(?<![\d/])(\d{5})(?!\d)", "BE": r"(?<![\d/])(\d{4})(?!\d)"}
# the rail terminals and depots Sx0058x names (looked up 22 Oct 2026: the operators' own sites and registers).
# Matched on the printed name's first word (DKT, DUSS, D3T, MTD, ZIEL, KREUZTAL) or on TKN anywhere in it
TERMINALS = {
    "DKT": ("DKT Duisburg Kombiterminal", "Rotterdamer Str. 49", "47229", "Duisburg"),              # Bertschi, logport
    "DUSS": ("Rail Hub Duisburg (DUSS Terminal Duisburg-Ruhrort Hafen)", "Alte Ruhrorter Str. 11", "47119", "Duisburg"),
    "D3T": ("D3T Duisburg Trimodal Terminal", "Rotterdamer Str. 30", "47229", "Duisburg"),
    "MTD": ("MTD Multimodal Terminal Duisburg", "Dr.-Wilhelm-Roelen-Str. 30", "47179", "Duisburg"),  # logport VI, Walsum
    "ZIEL": ("Ziel Terminal Duisburg (Samskip, logport III)", "Dahlingstraße 200", "47229", "Duisburg"),
    "TKN": ("Terminal Köln Nord (TKN)", "Franz-Greiß-Straße 8", "50735", "Köln"),
    "KREUZTAL": ("Südwestfalen Container-Terminal Kreuztal", "Hüttenstraße 40", "57223", "Kreuztal"),
}
CONNECTORS = {"van", "de", "der", "den", "het", "'t", "aan", "op", "in", "te", "am", "an", "zur", "zum", "im", "auf"}
HOUSE_NUMBER = re.compile(r"^\d+[a-zA-Z]?(?:\s*[-/]\s*\d+[a-zA-Z]?)?$")
NOT_A_NAME = {"MORNING", "MORNİNG", "MORNING)", "AFTERNOON", "EVENING", "NIGHT", "JOB", "JOBS", "SABAH", "OGLE", "ÖĞLE",
              "OGLEDEN", "ÖĞLEDEN", "SONRA", "AKSAM", "AKŞAM", "AND", "Sx0018x", "Sx0062x", "MR", "MR."}


def is_schedule(sender, subject):
    return SENDER in (sender or "").lower() and SUBJECT.match(subject or "") is not None


def subject_parts(subject):
    """('Sx0060x', '23.10.2026') from the subject, or ('', '')"""
    m = SUBJECT.match(subject or "")
    if not m:
        return "", ""
    return m.group("driver").strip().upper(), f"{int(m.group('d')):02d}.{int(m.group('m')):02d}.{m.group('y')}"


def _cell(raw):
    t = re.sub(r"(?is)<br\s*/?>|</p>|</div>|</li>", " ", raw)
    t = re.sub(r"(?s)<[^>]+>", " ", t)
    return " ".join(html.unescape(t).replace("\xa0", " ").split())


def _column(name):
    return " ".join(re.sub(r"[^A-Z0-9 ]+", " ", name.upper()).split())


def _html(source):
    msg = email.message_from_string(source, policy=email.policy.default)
    for part in msg.walk():
        if part.get_content_type() == "text/html":
            try:
                return part.get_content()
            except Exception:
                payload = part.get_payload(decode=True) or b""
                return payload.decode(part.get_content_charset() or "utf-8", "replace")
    return ""


def _rows(table):
    """the rows of one HTML table that stand under a header row naming CONTAINER NO: [{column: cell}]"""
    rows = [[_cell(c) for c in re.findall(r"(?is)<t[dh][^>]*>(.*?)</t[dh]>", r)]
            for r in re.findall(r"(?is)<tr.*?</tr>", table)]
    out, names = [], None
    for r in rows:
        if any(_column(c) == "CONTAINER NO" for c in r):
            names = [_column(c) for c in r]
            continue
        if names is None:
            continue
        if len(r) < 2:
            break                                   # the signature under the table
        row = {names[i]: r[i] for i in range(min(len(names), len(r))) if names[i]}
        for i in range(len(names), len(r)):         # a cell without a column name is not dropped
            row[f"COLUMN {i + 1}"] = r[i]
        if any(v for v in row.values()):
            out.append(row)
    return out


def schedule_of(source):
    """the schedule rows of a raw mail. The mail's own part (before any quoted older mail) is read first; only when
    it has no table do the quoted tables count ("++ T1 + CMR" on top of the schedule). Returns
    {"rows": [...], "quoted": bool, "text": the own part's words (what a reply says)}."""
    page = _html(source)
    cuts = [m.start() for m in QUOTE.finditer(page)]
    bounds = [0] + cuts + [len(page)]
    segments = [page[bounds[i]:bounds[i + 1]] for i in range(len(bounds) - 1)]
    own = _cell(re.sub(r"(?is)<style.*?</style>|<table.*?</table>", " ", segments[0] if segments else ""))
    for i, seg in enumerate(segments):
        rows = [r for t in re.findall(r"(?is)<table.*?</table>", seg) for r in _rows(t)]
        if rows:
            return {"rows": rows, "quoted": i > 0, "text": own}
    return {"rows": [], "quoted": False, "text": own}


def rows_of(source):
    return schedule_of(source)["rows"]


def plain_text(s):
    """the text as the row PDF can carry it (cp1252): Turkish and other letters outside it lose their marks
    ('WAREHUSİNG' -> 'WAREHUSING', 'ZİEL' -> 'ZIEL'); 'Köln', 'straße' and '–' stay as they are"""
    out = []
    for ch in s:
        try:
            ch.encode("cp1252")
            out.append(ch)
        except UnicodeEncodeError:
            base = "".join(c for c in unicodedata.normalize("NFKD", ch) if not unicodedata.combining(c))
            out.append({"ı": "i", "İ": "I"}.get(ch, base if base and base != ch else "?"))
    return "".join(out)


def write_rows(rows, folder, received=None, subject="", attachments=()):
    """one PDF per row in folder: the row as 'LABEL: value' lines under the mail's subject, with the names of the
    CMR and T1 files attached for that container. Returns the paths."""
    from Sx0027x_mail import text_pdf
    driver, date = subject_parts(subject)
    folder = Path(folder)
    folder.mkdir(parents=True, exist_ok=True)
    paths = []
    for n, row in enumerate(rows, 1):
        bm = BOX.search(row.get("CONTAINER NO", ""))
        box = "".join(bm.groups()) if bm else ""
        lines = [f"{TITLE} {date}".strip(), f"Subject: {subject}".strip(), f"Driver: {driver}" if driver else ""]
        lines += [f"{k}: {v}" for k, v in row.items()]
        for a in attachments:
            name = os.path.basename(a)
            if box and box in name.upper().replace(" ", ""):
                lines.append(("T1: " if re.match(r"(?i)^t1[\s_-]", name) else "CMR: ") + name)
        p = folder / f"{TITLE} {date or 'x'} {box or n}.pdf"
        p.write_bytes(text_pdf([plain_text(l) for l in lines if l]))
        if received is not None:
            os.utime(p, (received.timestamp(), received.timestamp()))
        paths.append(p)
    return paths


def is_Sx0057x_text(text):
    return (text or "").lstrip().startswith(TITLE)


def _address(value):
    """'Sx0063x Transport Veenderveld 116, 2371 TX Roelofarendsveen, Hollanda', 'MSP GmbH Edsel-Ford-Str. 1-15 50769
    Köln (MSP1 - WQ )', 'Sx0064x Logistik GmbH & Co. KG - Edisonstraße 1, 41542 Dormagen, Germany' -> (location,
    remark) or (None, why). The name is what stands before the street; the street is the last word(s) before the
    house number. Only the postcode and the number pick a place in Qargo."""
    text = " ".join((value or "").split())
    remark = None
    m = re.search(r"\(([^()]*)\)\s*$", text)
    if m:
        remark, text = m.group(1).strip() or None, text[:m.start()].strip()
    country = None
    parts = [p.strip() for p in text.split(",") if p.strip()]
    if parts and parts[-1].lower() in COUNTRY:
        country, parts = COUNTRY[parts[-1].lower()], parts[:-1]
    text = ", ".join(parts)
    if country is None:
        words = text.split()
        if len(words) > 1 and words[-1].lower() in COUNTRY:
            country, text = COUNTRY[words[-1].lower()], " ".join(words[:-1])
    found = None
    for cc in ([country] if country else ["NL", "DE"]):
        m = re.search(PC_RE[cc], text)
        if m:
            found = (cc, m)
            break
    if not found:
        return None, f"no postcode read in {value!r}"
    cc, m = found
    postcode = "".join(m.groups())
    before = text[:m.start()].strip(" ,-")
    city_words = text[m.end():].split(",")[0].strip(" ,-").split()
    city = " ".join(w for i, w in enumerate(city_words) if i == 0 or w.lower() != city_words[i - 1].lower())
    if not city:
        return None, f"no city after the postcode in {value!r}"
    head, sep, tail = before.rpartition(" - ")
    words = (tail if sep else before).split()
    i = next((k for k in range(len(words) - 1, -1, -1) if HOUSE_NUMBER.match(words[k])), None)
    if i is None and len(words) >= 2 and HOUSE_NUMBER.match(" ".join(words[-2:])):
        i = len(words) - 2
    if i is None or i == 0:
        return None, f"no street with a house number before the postcode in {value!r}"
    j = i - 1                                             # the street's words: one before the number, more over connectors
    while j - 2 >= 0 and words[j - 1].lower() in CONNECTORS:
        j -= 2
    street = " ".join(words[j:i + 1])
    name = " ".join(x for x in (head if sep else "", " ".join(words[:j])) if x).strip(" ,-")
    loc = {"name": name or street, "street": street, "postcode": postcode, "city": city, "country": cc, "query": street}
    return loc, remark


def _terminal(place):
    """a rail terminal or depot printed by name: one of TERMINALS with its address (the bot picks the Qargo record by
    postcode and street, or makes it), else the name only: never matched on the name, the stop stays empty"""
    words = re.findall(r"[A-Z0-9]+", plain_text(place or "").upper())
    key = next((w for w in words[:1] + ["TKN"] if w in TERMINALS and (w != "TKN" or "TKN" in words)), None)
    if key:
        name, street, postcode, city = TERMINALS[key]
        return {"name": name, "street": street, "postcode": postcode, "city": city, "country": "DE", "query": street}
    return {"name": place, "street": "", "country": "DE", "query": place, "no_address": True}


def _stop(location, date, start=None, end=None, note=None, reference=None, activity=None):
    s = {"location": location, "date": date}
    if start: s["start"] = start
    if end: s["end"] = end
    if note: s["note"] = note
    if reference: s["reference"] = reference
    if activity: s["activity"] = activity
    return s


def _driver(cell):
    """'Sx0018x - Sx0060x' / 'Sx0065x (MORNING)' / 'Sx0018x Sx0060x - AFTERNOON' -> 'Sx0060x' / 'Sx0065x' / 'Sx0060x'"""
    t = re.sub(r"\([^)]*\)", " ", cell or "")
    words = [w for w in re.findall(r"[^\W\d_]+", t) if w.upper().replace("ı", "I") not in NOT_A_NAME]
    return " ".join(words)


def _when(cell):
    """'23.10.2026 - 07:00 150900643' -> ('23/10/2026', '07:00', '150900643'); the rest without its 'REF:' label"""
    m = WHEN.match(cell or "")
    if not m:
        return None, None, None
    try:
        date = datetime.date(int(m.group("y")), int(m.group("m")), int(m.group("d"))).strftime("%d/%m/%Y")
    except ValueError:
        return None, None, None
    time = m.group("t").replace(".", ":").zfill(5) if m.group("t") else None
    rest = REF_LABEL.sub("", m.group("rest") or "").strip() or None
    return date, time, rest


def _reference(ref, box, cell, review):
    """the Customer Reference: Sx0058x's job reference ('REF: 26-157832' in FULL PICK UP, the reference after the
    LOADING DATE), the same in every mail about the job; without one the container number"""
    ref = (ref or "").split()[0] if ref else ""
    if ref and not UNKNOWN.match(ref):
        return ref
    if box:
        review.append(f"{cell} prints no REF: the container number {box} is the Customer Reference")
        return box
    return None


def parse_text(text, source):
    """the order in one row PDF's text (write_rows). A row the parser cannot read whole is refused through
    `unread` (never filled); nothing printed is dropped: every cell is in the Instructions."""
    lines = [l.strip() for l in (text or "").replace("\f", "\n").splitlines() if l.strip()]
    unread, review, extra, notes = [], [], [], []
    fields, subject, driver, files = {}, "", "", {"CMR": [], "T1": []}
    for l in lines[1:]:
        m = re.match(r"^([A-Za-z][A-Za-z0-9 /().'*-]*?)\s*:\s*(.*)$", l)
        if not m:
            unread.append(f"line not read: {l}")
            continue
        label, value = m.group(1).strip(), m.group(2).strip()
        if label == "Subject": subject = value
        elif label == "Driver": driver = value
        elif label in ("CMR", "T1"): files[label].append(value)
        elif _column(label) in COLUMNS or label.startswith("COLUMN "): fields[_column(label)] = value
        elif label.isupper():
            extra.append(f"{label}: {value}")
            review.append(f"the field '{label}' is not one the parser knows; its value is kept in the Instructions")
        else:
            unread.append(f"line not read: {l}")
    kind = "delivery" if "DELIVERY DATE" in fields or "DELIVERY ADDRESS" in fields else \
           "loading" if "LOADING DATE" in fields or "LOADING ADDRESS" in fields else None
    if kind is None:
        unread.append(f"a table the parser does not know (columns: {', '.join(fields) or 'none'})")
    box_cell = fields.get("CONTAINER NO", "")
    bm = BOX.search(box_cell)
    box = "".join(bm.groups()) if bm else ""
    customs = fields.get("CUSTOMS ADDRESS", "")
    if fields.get("NOTES") and not DROP_TERMINAL.search(fields["NOTES"]):
        notes.append(fields["NOTES"])
    setup = teardown = None
    consignments, when_cell = [], ""
    if kind == "delivery":
        when_cell = fields.get("DELIVERY DATE", "")
        date, time, d_ref = _when(when_cell)
        if not date:
            unread.append(f"DELIVERY DATE not read as a date: {when_cell!r}")
        if not box:
            unread.append(f"CONTAINER NO not read as a container number: {box_cell!r}")
        place, remark = _address(fields.get("DELIVERY ADDRESS", ""))
        if place is None:
            unread.append(f"DELIVERY ADDRESS not read: {remark}")
        d_note = [remark] if remark else []
        if customs and CUSTOMS_AT_DELIVERY.match(customs):
            d_note.append("Customs at the delivery point")
        elif customs:
            unread.append(f"CUSTOMS ADDRESS is not 'CUSTOMS @DELIVERY POINT' but {customs!r}: a customs stop the parser "
                          f"does not know where to put")
        d_note += notes
        pick = fields.get("FULL PICK UP", "")
        pm = PICKUP.match(pick)
        p_place = (pm.group("place") if pm else pick).strip(" ,-:")
        p_ref = (pm.group("ref") or "").strip() or None if pm else None
        if not p_place:
            unread.append(f"FULL PICK UP names no place: {pick!r}")
        drop = fields.get("EMPTY DROP OFF", "")
        dm = DROP.match(drop)
        e_place = None
        if dm:
            e_place = dm.group("place").strip(" ,-")
            if box and dm.group("box").replace(" ", "") != box:
                unread.append(f"EMPTY DROP OFF names another container ({dm.group('box')}) than CONTAINER NO ({box})")
        elif drop:
            unread.append(f"EMPTY DROP OFF not read as '<place> -> <container>': {drop!r}")
        else:
            review.append("EMPTY DROP OFF is empty: the order has no end stop (Drop empty container)")
        # the terminal and the depot get the delivery's date (Sx0058x plans the pick-up on the delivery day, "driver
        # can pick up tomorrow around 06:00"); the empty box goes back from the delivery time on
        day = date or "00/00/0000"
        terminal = _stop(_terminal(p_place or "?"), day, note=pick or None, reference=p_ref, activity="Pickup full container")
        delivery = _stop(place or {"name": "?", "street": "?", "country": "NL", "query": "?"}, day, time, time,
                         note="\n".join(d_note) or None, reference=d_ref, activity="Delivery")
        if e_place:
            teardown = _stop(_terminal(e_place), day, time, note=drop, activity="Drop empty container")
        consignments = [{"pickup": terminal, "delivery": delivery}]
        scenario, job_ref, ref_cell = "Import", p_ref, "FULL PICK UP"
    elif kind == "loading":
        when_cell = fields.get("LOADING DATE", "")
        date, time, l_ref = _when(when_cell)
        if not date:
            unread.append(f"LOADING DATE not read as a date: {when_cell!r}")
        day = date or "00/00/0000"
        em = EMPTY_PICKUP.match(box_cell) if not box else None
        if em:                                        # 'PICK UP: MTD DUISBURG REF: TALAY2026B': an empty box from a depot first
            setup = _stop(_terminal(em.group("place").strip(" ,-")), day, note=box_cell,
                          reference=(em.group("ref") or "").strip() or None, activity="Pickup empty container")
            review.append(f"no container number yet: an empty container is picked up at {em.group('place').strip(' ,-')} "
                          f"(CONTAINER NO reads {box_cell!r}); fill the number in when Sx0058x sends it")
        elif not box:
            unread.append(f"CONTAINER NO not read as a container number: {box_cell!r}")
        place, remark = _address(fields.get("LOADING ADDRESS", ""))
        if place is None:
            unread.append(f"LOADING ADDRESS not read: {remark}")
        c_note = [remark] if remark else []
        if customs and CUSTOMS_AT_LOADING.match(customs):
            c_note.append("Customs documents are given at the loading address")
        elif customs:
            unread.append(f"CUSTOMS ADDRESS is not 'documents will be given from the loading address' but {customs!r}: "
                          f"a customs stop the parser does not know where to put")
        c_note += notes
        drop_cell = next((fields[k] for k in ("DROP OFF ADDRESS", "DROP OFF", "NOTES") if fields.get(k) and DROP_TERMINAL.search(fields[k])), "")
        dm = DROP_TERMINAL.search(drop_cell)
        t_place = dm.group("place").strip(" ,-") if dm else ""
        t_ref = (dm.group("ref") or "").strip(" ,-") if dm else ""
        if not dm or UNKNOWN.match(t_place):
            unread.append(f"the drop terminal for the loaded container is not known yet ({drop_cell or 'no DROP OFF printed'!r}): "
                          f"Qargo's Export form needs that stop, so this order has to wait until Sx0058x sends it")
        if re.fullmatch(r"(?i)container\s*(?:no|nr|number)\.?", t_ref):
            t_ref = box
        elif UNKNOWN.match(t_ref):
            t_ref = ""
        collect = _stop(place or {"name": "?", "street": "?", "country": "NL", "query": "?"}, day, time, time,
                        note="\n".join(c_note) or None, reference=l_ref, activity="Collect")
        drop = _stop(_terminal(t_place or "?"), day, time, note=drop_cell or None, reference=t_ref or None, activity="Drop full container")
        consignments = [{"pickup": collect, "delivery": drop}]
        scenario, job_ref, ref_cell = "Export", l_ref, "LOADING DATE"
    else:
        day = "00/00/0000"
        consignments = [{"pickup": _stop({"name": "?", "street": "?", "country": "NL", "query": "?"}, day),
                         "delivery": _stop({"name": "?", "street": "?", "country": "NL", "query": "?"}, day)}]
        scenario, job_ref, ref_cell = "Import", None, "the row"
    ref = _reference(job_ref, box, ref_cell, review)
    if not ref:
        unread.append(f"no reference for this row: no REF in {ref_cell} and no container number")
    who = _driver(fields.get("PLANNING", "")) or driver
    instructions = [who, f"Planning: {fields['PLANNING']}" if fields.get("PLANNING") else "",
                    *(f"{k.capitalize()}: {fields[k]}" for k in ("FULL PICK UP", "EMPTY DROP OFF", "CUSTOMS ADDRESS",
                                                                 "DELIVERY DATE", "LOADING DATE", "DROP OFF ADDRESS",
                                                                 "DROP OFF", "NOTES") if fields.get(k)),
                    *extra, f"Sx0058x mail: {REPLY.sub('', subject)}" if subject else lines[0]]
    for c in consignments:
        c.update({"reference": None, "instructions": None,
                  "goods": [{"quantity": 1, "description": f"Container {box}" if box else "Container"}]})
    o = {"customer": CUSTOMER, "customer_reference": ref or "?", "ritnummer": None,
         "instructions": "\n".join(x for x in instructions if x),
         "service": "Container import/export",
         "container": {"number": box, "scenario": scenario} if box else {"scenario": scenario},
         "vehicle_category": "Chassis", "setup": setup, "teardown": teardown,
         "consignments": consignments, "source": source, "key": f"{PREFIX}{ref or '?'}"}
    if review:
        o["review"] = list(dict.fromkeys(review))
    if unread:
        o["unread"] = list(dict.fromkeys(unread))
    return [o]
