"""The BAG register (PDOK Locatieserver, no key needed): the postcode of a Dutch address a document prints without
one (Sx0017x rit 1902841, 22 Oct 2026: "Sx0043x Jongenotter - Prinses Irenelaan 330 - - RIJSWIJK (Z.H.)").

Only an exact address hit (type "adres": the printed street and house number in the printed town) gives a
postcode; anything else is "not found" (None). No answer within ANSWER_S is its own outcome (BagNoAnswer), never
"not found": the caller refuses the order and the next check asks again.
"""
import json, re, unicodedata, urllib.error, urllib.parse, urllib.request

URL = "https://api.pdok.nl/bzk/locatieserver/search/v3_1/free"
ANSWER_S = 20


class BagNoAnswer(Exception):
    pass


def plain(s):
    """lower case, no accents, no bracketed part: 'RIJSWIJK (Z.H.)' -> 'rijswijk'"""
    t = unicodedata.normalize("NFKD", s or "").encode("ascii", "ignore").decode().lower()
    return " ".join(re.sub(r"\(.*?\)", " ", t).split())


def house(street):
    """'Prinses Irenelaan 330' -> ('prinses irenelaan', '330'); '... 330 b' / '330b' / '330-2' -> number '330b' / '330-2'"""
    m = re.match(r"^\s*(.*?\S)\s+(\d+)\s*([a-zA-Z]|-\d+)?\s*$", street or "")
    return (plain(m.group(1)), (m.group(2) + (m.group(3) or "")).lower()) if m else (None, None)


def fetch(street, town):
    """the register's address hits for the query, as PDOK returns them (a list of dicts)"""
    q = urllib.parse.urlencode({"q": f"{street} {town}", "fq": "type:adres", "rows": 10,
                                "fl": "straatnaam,huisnummer,huisletter,huisnummertoevoeging,postcode,woonplaatsnaam"})
    try:
        with urllib.request.urlopen(f"{URL}?{q}", timeout=ANSWER_S) as r:
            return json.loads(r.read().decode("utf-8"))["response"]["docs"]
    except (urllib.error.URLError, TimeoutError, OSError, ValueError, KeyError) as e:
        raise BagNoAnswer(f"NO ANSWER from the BAG register within {ANSWER_S} s (internet?): {e}")


def postcode(street, city, fetch=fetch):
    """'Prinses Irenelaan 330', 'RIJSWIJK (Z.H.)' -> '2285GD'; None when the register has no such address"""
    name, nr = house(street)
    town = plain(city)
    if not name or not nr or not town:
        return None
    for d in fetch(street, town):
        got = f"{d.get('huisnummer', '')}{d.get('huisletter') or ''}{d.get('huisnummertoevoeging') or ''}".lower()
        if plain(d.get("straatnaam")) == name and got == nr and plain(d.get("woonplaatsnaam")) == town and d.get("postcode"):
            return d["postcode"]
    return None
