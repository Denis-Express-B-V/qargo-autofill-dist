#!/usr/bin/env python3
"""Make Qargo orders from the trip documents that arrive in the planning mailboxes.

  .venv/bin/python mail_watch.py                # new mails since the last check -> orders in Qargo
  .venv/bin/python mail_watch.py --dry-run      # only show the new mails and what the parser reads them as
  .venv/bin/python mail_watch.py --since "2026-10-21 06:00"   # also mails from before the first check

- Reads planning@Sx0061x-express.nl and planning.containers@Sx0061x-express.nl through Apple Mail on this Mac
  (both accounts must be in Mail). Every folder counts (their mail is sorted into customer folders on arrival),
  except Sent, Drafts, Trash and Spam. It never sends, moves, deletes or marks a mail.
- The PDFs of a new mail go to documents/<day>/mail/<time>_<id>/ and are read by the parser, like run.py does with
  ~/Downloads. Orders without any warning are saved; the rest is listed with the command that opens it in a window.
- Qargo runs in a hidden browser on a copy of the login, so run.py or the app can be open at the same time.
- A document re-sent with the same order in it (Sx0013x sends a rit up to 7 times) is left alone. A re-sent
  order that differs from the one Qargo has is changed by the bot, as run.py --change does (decided 21 Oct 2026:
  an updated order is updated, nobody is asked). What it could not change is reported.
- Mails without a PDF and PDFs the parser does not know are listed, never skipped in silence. A Sx0020x day hire
  (Transport_order_D....pdf) makes no order: it is listed with its D-number, date, DC and driver (MAPPING.md).
- Sx0058x sends no PDF either: the drivers' container jobs are a table in a "Sx0018x | <DRIVER>'S SCHEDULE: <date>"
  mail, one order per row (Sx0057x_mail.py writes one small PDF per row; the CMR / T1 papers attached are kept in
  the folder, not read). A job gone from the driver's newer mail of the same day is reported, never cancelled.
- Sx0017x sends no PDF: its planning is an Sx0067x "Planning Dienst" mail text, one order per Rit (MAPPING.md).
  The check writes one small PDF per planned rit from the mail text (Sx0027x_mail.py) and reads it like any document;
  a rit not planned yet ("melden in Oss", no stops) is listed, no order. The Sx0053x ones ("Beste (Sx0015xxx)") are
  counted only.
- The first check starts from that moment; older mails only with --since. What was handled is kept in
  mail_watch.json (in the data folder), the report in logs: mail_log_<date>_<time>.txt.
- Mail or Qargo not answering, or a logged-out Qargo: nothing is concluded, the next check tries those mails again.
"""
import argparse, contextlib, datetime, email, email.policy, fcntl, hashlib, json, os, re, subprocess, sys, tempfile
from dataclasses import dataclass, field
from pathlib import Path
HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import messages
import paths
import Sx0027x_mail
import Sx0057x_mail
import Sx0022x_plan

ACCOUNTS = ("planning@Sx0061x-express.nl", "planning.containers@Sx0061x-express.nl")
SKIP_MAILBOXES = ("Sent", "Sent Messages", "Sent Items", "Sent Mail", "Drafts", "Trash", "Deleted Messages",
                  "Deleted Items", "Spam", "Junk", "Junk E-mail", "Notes", "Outbox")
OVERLAP = datetime.timedelta(hours=6)      # each check looks this far behind the last one: Mail can sync a mail late
MAX_TRIES = 3                              # a mail whose order keeps failing (ERROR) is given up after this many checks
KEEP = datetime.timedelta(days=21)         # how long mail_watch.json remembers a mail or an order
MAIL_ANSWER_S = 600                        # deadline for Mail's answer (a folder scan took 50 s, one mail up to 15 s)
EXCERPT = 300                              # characters of a mail without a document shown in the report

# Apple Mail, through its scripting interface (JavaScript for Automation). Each property is fetched for all
# matching mails of a folder in one request: one request per mail took 2.6 min for two days, this 50 s.
LIST_JS = r"""
function run(argv) {
  const addrs = JSON.parse(argv[0]), since = new Date(argv[1]), skip = JSON.parse(argv[2]);
  const Mail = Application("Mail"), out = [], accounts = [];
  for (const a of Mail.accounts()) {
    const em = a.emailAddresses().map(x => x.toLowerCase());
    const mine = em.filter(x => addrs.includes(x));
    if (!mine.length) continue;
    accounts.push(mine[0]);
    a.mailboxes.name().forEach((name, i) => {
      if (skip.includes(name)) return;
      const q = a.mailboxes[i].messages.whose({dateReceived: {_greaterThan: since}});
      const ids = q.messageId();
      if (!ids.length) return;
      const subj = q.subject(), snd = q.sender(), dr = q.dateReceived(), att = q.mailAttachments.name();
      ids.forEach((id, k) => out.push({account: mine[0], mailbox: name, id: id, subject: subj[k], sender: snd[k],
                                      received: dr[k].toISOString(), attachments: att[k]}));
    });
  }
  return JSON.stringify({accounts: accounts, mails: out});
}"""

# one mail, whole (its source fetches an attachment Mail has not downloaded yet), or only its text. Found among
# the mails received from its own arrival on: asking Mail for a message id scans the whole folder (45 s in
# Sx0013x's 1600 mails), a date is answered at once.
GET_JS = r"""
function run(argv) {
  const [addr, box, id, what, received] = argv;
  const Mail = Application("Mail");
  const a = Mail.accounts().find(x => x.emailAddresses().map(e => e.toLowerCase()).includes(addr));
  if (!a) return JSON.stringify({missing: "account"});
  const q = a.mailboxes.byName(box).messages.whose({dateReceived: {_greaterThan: new Date(received)}});
  const k = q.messageId().indexOf(id);
  if (k < 0) return JSON.stringify({missing: "mail"});
  const m = q()[k];
  return JSON.stringify({text: what === "source" ? m.source() : m.content()});
}"""


class MailNoAnswer(Exception):
    """Apple Mail did not answer, or refused: nothing about the mails may be concluded"""


def osascript(js, *args, timeout=MAIL_ANSWER_S):
    try:
        r = subprocess.run(["osascript", "-l", "JavaScript", "-e", js, *map(str, args)],
                           capture_output=True, text=True, timeout=timeout)
    except subprocess.TimeoutExpired:
        raise MailNoAnswer(f"MAIL DID NOT ANSWER within {timeout} s")
    except FileNotFoundError:
        raise MailNoAnswer("no osascript here: the mail check only runs on a Mac with Apple Mail")
    if r.returncode != 0:
        err = r.stderr.strip()
        if "-1712" in err:               # Mail's own 2-minute limit: busy (syncing), not a refusal
            raise MailNoAnswer(f"MAIL DID NOT ANSWER within 2 minutes (busy?): {err[:200]}")
        if "-1743" in err or "not allowed" in err.lower():
            err += (" - allow it in System Settings > Privacy & Security > Automation: the program that runs this "
                    "check must be allowed to control Mail")
        raise MailNoAnswer(f"MAIL REFUSED: {err[:500]}")
    return json.loads(r.stdout)


@dataclass
class Mail:
    account: str
    mailbox: str
    id: str
    subject: str
    sender: str
    received: datetime.datetime          # local time
    attachments: list

    @property
    def pdfs(self):
        return [a for a in self.attachments if a.lower().endswith(".pdf")]

    def label(self):
        return (f"mail {self.received:%d-%m %H:%M} \"{self.subject.strip()[:70]}\" from {self.sender[:60]} "
                f"({self.account.split('@')[0]} / {self.mailbox})")


def list_mails(accounts, since, run_js=osascript):
    """the mails received after `since` in every folder of the accounts, oldest first, each message id once"""
    d = run_js(LIST_JS, json.dumps([a.lower() for a in accounts]),
               since.astimezone(datetime.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"), json.dumps(SKIP_MAILBOXES))
    missing = [a for a in accounts if a.lower() not in d["accounts"]]
    if missing:
        raise MailNoAnswer(f"NOT IN APPLE MAIL: {missing}. Add the account in Mail (Mail > Add Account...)")
    out, seen = [], set()
    for m in d["mails"]:
        m["id"] = m["id"] or f"{m['account']}|{m['mailbox']}|{m['received']}|{m['subject']}"   # no Message-ID header
        if m["id"] in seen or m["sender"] and any(a.lower() in m["sender"].lower() for a in accounts):
            continue                     # in both mailboxes (cc), or one the planners sent themselves
        seen.add(m["id"])
        out.append(Mail(m["account"], m["mailbox"], m["id"], m["subject"] or "", m["sender"] or "",
                        datetime.datetime.fromisoformat(m["received"].replace("Z", "+00:00")).astimezone(),
                        list(m["attachments"] or [])))
    return sorted(out, key=lambda m: m.received)


def mail_part(mail, what, run_js=osascript):
    """'source' (the whole mail, as sent) or 'text' (what Mail shows as its text)"""
    since = (mail.received - datetime.timedelta(seconds=5)).astimezone(datetime.timezone.utc)
    d = run_js(GET_JS, mail.account, mail.mailbox, mail.id, what, since.strftime("%Y-%m-%dT%H:%M:%SZ"))
    if "missing" in d:
        raise MailNoAnswer(f"the {d['missing']} is no longer in Mail ({mail.label()}): moved or deleted meanwhile?")
    return d["text"] or ""


def safe_name(name):
    name = re.sub(r'[\\/:*?"<>|\x00-\x1f]', "_", name).strip(" .") or "document.pdf"
    return name if name.lower().endswith(".pdf") else name + ".pdf"


def save_pdfs(source, folder, received):
    """every PDF attachment of a raw mail (also inside a forwarded mail) into folder; returns the paths.
    Their modification time is the mail's arrival, so the parser's 'newest change counts' sees mail order."""
    msg = email.message_from_string(source, policy=email.policy.default)
    out = []
    for part in msg.walk():
        name = part.get_filename()
        if not name or not name.lower().endswith(".pdf") or part.is_multipart():
            continue
        data = part.get_payload(decode=True)
        if not data:
            continue
        folder.mkdir(parents=True, exist_ok=True)
        p = folder / safe_name(name)
        n = 2
        while p.exists():
            if p.read_bytes() == data:
                break
            p = folder / f"{Path(safe_name(name)).stem} ({n}).pdf"
            n += 1
        if not p.exists():
            p.write_bytes(data)
            os.utime(p, (received.timestamp(), received.timestamp()))
            out.append(p)
    return out


def fingerprint(order):
    """what makes two readings the same order: everything but the file name and its pages"""
    o = {k: v for k, v in order.items() if k not in ("source", "pages")}
    return hashlib.sha256(json.dumps(o, sort_keys=True, ensure_ascii=False).encode()).hexdigest()[:16]


def state_file():
    return paths.data_dir() / "mail_watch.json"


def load_state():
    f = state_file()
    s = json.loads(f.read_text(encoding="utf-8")) if f.exists() else {}
    s.setdefault("mails", {}); s.setdefault("orders", {})
    return s


def save_state(s, now):
    cut = (now - KEEP).isoformat()
    s["mails"] = {k: v for k, v in s["mails"].items() if v.get("received", "") >= cut}
    s["orders"] = {k: v for k, v in s["orders"].items() if v.get("at", "") >= cut}
    s["Sx0027x"] = {k: v for k, v in s.get("Sx0027x", {}).items() if v.get("received", "") >= cut}
    tmp = state_file().with_suffix(".tmp")
    tmp.write_text(json.dumps(s, indent=1, ensure_ascii=False), encoding="utf-8")
    tmp.replace(state_file())


@dataclass
class Job:
    """one order read from a mail, and what became of it"""
    order: dict
    mail: Mail
    folder: Path
    status: str = ""
    why: list = field(default_factory=list)
    notes: list = field(default_factory=list)
    qargo: str = ""                       # the Or-number, when known
    final: bool = True                    # False: try again at the next check

    @property
    def key(self):
        return self.order["key"]


def shown(p):
    return p.relative_to(HERE) if p.is_relative_to(HERE) else p


def in_qargo_as_document(job):
    """Qargo's duplicate check found this order, of this customer, and it is what the document says"""
    return job.status.startswith("UNCHANGED") or (
        job.status.startswith("DUPLICATE") and any("in Qargo is what the document says" in n for n in job.notes))


def open_cmd(job):
    """the command that opens this order in a Qargo window to check and save by hand"""
    flag = ""
    if job.order.get("change") or any("differs from the document" in w for w in job.why):
        flag = f" --change {job.key}"                   # the customer changed it: edit the order Qargo has
    elif job.status.startswith("DUPLICATE"):
        flag = f" --allow-duplicate {job.key}"          # the reference belongs to another customer's order
    return f"cd ~/my-programs/qargo-autofill && python3 run.py \"{shown(job.folder)}\" --only {job.key}{flag}"


def wait_or_number(tab, s=20):
    """the Or-number on the saved order's page (it loads after the URL changes), or ''"""
    for _ in range(s * 4):
        try:
            m = re.search(r"\bOr-\d{5,}\b", tab.title() + " " + tab.locator("body").inner_text(timeout=1000))
            if m:
                return m.group(0)
        except Exception:
            pass
        tab.wait_for_timeout(250)
    return ""


def fill(jobs, doc_warnings, report):
    """every job into Qargo, in a hidden browser on a copy of the login; sets job.status / why / qargo / final.
    Returns False when Qargo could not be used at all (logged out, no answer): then nothing was tried."""
    from playwright.sync_api import sync_playwright
    import qargo_fill as qf
    from cancel_overdue import Qargo, NoAnswer, copy_profile
    qf.LOG_LINES.clear()
    done_path = paths.done_file()
    done = json.loads(done_path.read_text(encoding="utf-8-sig")) if done_path.exists() else {}
    with tempfile.TemporaryDirectory(prefix="qargo-mail-") as tmp, sync_playwright() as pw:
        try:
            if not paths.profile_dir("chromium").is_dir():
                raise NoAnswer("NO QARGO LOGIN on this Mac yet: log in once with the bot (python3 run.py)")
            copy_profile(paths.profile_dir("chromium"), Path(tmp) / "profile")
            q = Qargo(pw, Path(tmp) / "profile")
        except Exception as e:       # NoAnswer, LOGGED OUT, or the page did not load: nothing may be concluded
            report.append(f"!! QARGO NOT OPENED: {str(e).splitlines()[0][:300]}. No order was filled.")
            for j in jobs:
                j.status, j.final = "NOT TRIED", False
            return False
        try:
            for j in jobs:
                one = lambda: qf.fill_one(q.ctx, j.order, [j.folder], save=True, done=done, done_path=done_path,
                                          doc_warnings=doc_warnings.get(j.key, []),
                                          create_locations=True)             # as run.py does by default
                try:
                    status, ctx, tab = one()
                    if status.startswith("DUPLICATE") and ctx.get("differs"):
                        # Qargo has this customer's order and the document differs: the customer changed it.
                        # Edit the order Qargo has, as run.py --change does ("If an order is updated it is
                        # updated, no need to ask me", 21 Oct 2026). The first try closed its own tab.
                        j.order["change"] = True
                        status, ctx, tab = one()
                except Exception as e:      # the browser itself failed: this order is tried again next time
                    j.status, j.why, j.final = "ERROR", [f"{type(e).__name__}: {str(e).splitlines()[0][:300]}"], False
                    continue
                j.status, j.notes = status, list(ctx.get("notes", []))
                if status.startswith("CHANGED"):             # a change knows which order it edited
                    j.qargo = (ctx.get("qargo") or {}).get("order") or ""
                elif status.startswith("SAVED"):             # a new order: its number is on the saved page
                    j.qargo = wait_or_number(tab) if tab else ""
                elif status.startswith(("UNCHANGED", "DUPLICATE", "EDITED", "EDIT INCOMPLETE")):
                    j.qargo = (ctx.get("qargo") or {}).get("order") or ""
                    m = re.search(r"\((Or-[^)]+)\)", status)
                    j.qargo = j.qargo or (m.group(1) if m else "")
                j.why = ([ctx["differs"]] if ctx.get("differs") else []) + \
                        [f"TO DO BY HAND: {t}" for t in ctx.get("by_hand", [])
                         if not any(t in w for w in ctx["warnings"])] + \
                        [w for w in ctx["warnings"] if w != ctx.get("differs")]      # a change lists them itself
                j.final = status != "ERROR"
                if tab and not tab.is_closed():
                    tab.close(run_before_unload=False)
        finally:
            q.close()
            (paths.logs_dir() / f"fill_log_{datetime.datetime.now():%Y%m%d_%H%M%S}.txt").write_text(
                "\n".join(qf.LOG_LINES), encoding="utf-8")
    return True


def check(*, since=None, dry_run=False, accounts=ACCOUNTS, run_js=osascript, fill_jobs=fill, now=None):
    """one check of the mailboxes. Returns (report lines, exit code)."""
    from parse_trips import parse_paths
    from validate_orders import validate
    now = now or datetime.datetime.now().astimezone()
    s = load_state()
    report = []
    first = "since" not in s
    if since:
        s["since"] = min(since, datetime.datetime.fromisoformat(s.get("since", since.isoformat()))).isoformat()
    elif first:
        s["since"] = now.isoformat()
        report.append(f"First check: from now on ({now:%d-%m-%Y %H:%M}) every new mail is read. Older mails only "
                      f"with --since \"YYYY-MM-DD HH:MM\".")
    start = datetime.datetime.fromisoformat(s["since"])
    if s.get("last_check") and not since:
        start = max(start, datetime.datetime.fromisoformat(s["last_check"]) - OVERLAP)
        waiting = [r["received"] for r in s["mails"].values() if not r.get("done")]
        if waiting:                              # a mail still to try again is looked at, however old
            start = min(start, datetime.datetime.fromisoformat(min(waiting)) - datetime.timedelta(minutes=1))

    try:
        mails = list_mails(accounts, start, run_js)
    except MailNoAnswer as e:
        return [f"!! {e}. Nothing was read; the next check tries again."], 1
    new = [m for m in mails if m.received >= datetime.datetime.fromisoformat(s["since"])
           and not s["mails"].get(m.id, {}).get("done")]
    report.insert(0, f"MAIL CHECK {now:%d-%m-%Y %H:%M}: {len(new)} new mail(s) in {', '.join(accounts)} "
                     f"(looked at mails since {start:%d-%m %H:%M})")

    day_dir = lambda m: paths.documents_dir() / f"{m.received:%Y-%m-%d}" / "mail"
    tmp = tempfile.TemporaryDirectory(prefix="qargo-mail-dry-") if dry_run else contextlib.nullcontext()
    with tmp as tmpdir:
        jobs, not_read, no_doc, failed_mails, day_hires, plans = [], [], [], [], [], []
        Sx0027x_mails, Sx0027x_not_planned, ah_plans = [], [], []     # Sx0067x planning mails (Sx0017x / Sx0053x)
        gl_replies = []                                       # Sx0058x replies whose table is the quoted schedule
        for m in new:
            if Sx0022x_plan.is_planning_mail(m.sender, m.subject, m.attachments):
                base = Path(tmpdir) / f"{m.received:%Y-%m-%d}" if dry_run else day_dir(m)
                folder = base / f"{m.received:%H%M%S}_{hashlib.sha1(m.id.encode()).hexdigest()[:8]}"
                try:
                    plans.append((m, Sx0022x_plan.save_planning(mail_part(m, "source", run_js), folder, m.received,
                                                                  m.subject, m.sender), folder))
                except MailNoAnswer as e:
                    failed_mails.append((m, str(e)))
                continue
            if Sx0027x_mail.is_planning_dienst(m.sender, m.subject):
                try:
                    text = mail_part(m, "text", run_js)
                except MailNoAnswer as e:
                    failed_mails.append((m, str(e)))
                    continue
                k = Sx0027x_mail.kind(text)
                if k == "ah":                           # Sx0054x's planning for a Sx0014x charter: no order of its own
                    ah_plans.append(m)
                    continue
                if k == "Sx0027x":
                    # one small PDF per planned rit, read like any document (parser, validator, filler, run.py)
                    base = Path(tmpdir) / f"{m.received:%Y-%m-%d}" if dry_run else day_dir(m)
                    folder = base / f"{m.received:%H%M%S}_{hashlib.sha1(m.id.encode()).hexdigest()[:8]}"
                    folder.mkdir(parents=True, exist_ok=True)
                    (folder / "mail.txt").write_text(text, encoding="utf-8")
                    saved, not_planned = Sx0027x_mail.write_rits(text, folder, m.received)
                    Sx0027x_not_planned += [(m, r) for r in not_planned]
                    orders, skipped = parse_paths([str(folder)]) if saved else ([], [])
                    if skipped:
                        not_read.append((m, skipped))
                    jobs += [Job(o, m, folder) for o in orders]
                    driver, date, _ = Sx0027x_mail.header(text)
                    Sx0027x_mails.append((m, f"{driver} {date}", [o["key"] for o in orders]))
                    s["mails"].setdefault(m.id, {"received": m.received.isoformat(), "subject": m.subject, "tries": 0})
                    continue
                # another Sx0067x layout: listed under MAILS WITHOUT A PDF like any mail text
            if Sx0057x_mail.is_schedule(m.sender, m.subject):
                # Sx0058x's schedule: a table in the mail text, one order per row (the CMR / T1 PDFs attached are
                # the container's papers, kept in the folder, not read). One small PDF per row is read like any document
                base = Path(tmpdir) / f"{m.received:%Y-%m-%d}" if dry_run else day_dir(m)
                folder = base / f"{m.received:%H%M%S}_{hashlib.sha1(m.id.encode()).hexdigest()[:8]}"
                try:
                    source = mail_part(m, "source", run_js)
                except MailNoAnswer as e:
                    failed_mails.append((m, str(e)))
                    continue
                sched = Sx0057x_mail.schedule_of(source)
                s["mails"].setdefault(m.id, {"received": m.received.isoformat(), "subject": m.subject, "tries": 0})
                if not sched["rows"]:
                    not_read.append((m, ["(no schedule table with a CONTAINER NO column in the mail text)"]))
                    continue
                if sched["quoted"]:                     # a reply on top of the schedule: its own words are for a person
                    gl_replies.append((m, sched["text"]))
                folder.mkdir(parents=True, exist_ok=True)
                if m.pdfs:
                    save_pdfs(source, folder, m.received)
                written = Sx0057x_mail.write_rows(sched["rows"], folder, m.received, m.subject, m.pdfs)
                orders, skipped = parse_paths([str(p) for p in written])
                if skipped:
                    not_read.append((m, skipped))
                jobs += [Job(o, m, folder) for o in orders]
                driver, date = Sx0057x_mail.subject_parts(m.subject)
                Sx0027x_mails.append((m, f"Sx0058x {driver} {date}", [o["key"] for o in orders]))
                continue
            if not m.pdfs:
                no_doc.append(m)
                continue
            base = Path(tmpdir) / f"{m.received:%Y-%m-%d}" if dry_run else day_dir(m)
            folder = base / f"{m.received:%H%M%S}_{hashlib.sha1(m.id.encode()).hexdigest()[:8]}"
            try:
                saved = save_pdfs(mail_part(m, "source", run_js), folder, m.received) if not folder.exists() else \
                        sorted(f for f in folder.iterdir() if f.suffix.lower() == ".pdf")
            except MailNoAnswer as e:
                failed_mails.append((m, str(e)))
                continue
            hires = []                              # Sx0020x day hires: no order of their own
            orders, skipped = parse_paths([str(folder)], no_order=hires) if saved else ([], [])
            day_hires += [(m, r) for r in hires]
            if not saved:
                not_read.append((m, ["(no PDF could be taken out of the mail)"]))
            if skipped:
                not_read.append((m, skipped))
            jobs += [Job(o, m, folder) for o in orders]
            s["mails"].setdefault(m.id, {"received": m.received.isoformat(), "subject": m.subject, "tries": 0})

        # an Sx0017x rit (or a Sx0058x row) that a driver's newer planning mail of the same day no longer has: reported,
        # never cancelled by the bot (the mail is per driver: the job may have moved to another one)
        Sx0027x_gone, Sx0027x_dropped = [], []
        for m, who, keys in Sx0027x_mails:                   # in mail order: the newest mail of a driver counts
            prev = s.setdefault("Sx0027x", {}).get(who)
            if prev and prev.get("mail") != m.id:
                for k in prev.get("keys", []):
                    if k in keys:
                        continue
                    if s["orders"].get(k, {}).get("qargo"):
                        Sx0027x_gone.append((m, k, s["orders"][k]["qargo"], who))
                    elif prev.get("check") == now.isoformat():       # an earlier mail of this check: not made
                        Sx0027x_dropped.append((m, k, who))
                        jobs = [j for j in jobs if not (j.key == k and j.mail.id == prev["mail"])]
            s["Sx0027x"][who] = {"mail": m.id, "keys": keys, "received": m.received.isoformat(), "check": now.isoformat()}

        # which orders to fill: the newest reading of each, and only when it is new or differs from the last one
        newest = {}
        for j in jobs:
            newest[j.key] = j                       # jobs are in mail order: the last one is the newest
        todo, resent, replaced = [], [], []
        for j in jobs:
            known = s["orders"].get(j.key)
            if newest[j.key] is not j:
                replaced.append(j)
            elif known and known.get("fp") == fingerprint(j.order) and known.get("final", True):
                resent.append(j)
            else:
                todo.append(j)

        errors, warnings = validate([j.order for j in todo], [j.folder for j in todo]) if todo else ([], [])
        bad = {}
        for k, msg in errors:
            bad.setdefault(k, []).append(msg)
        doc_warnings = {}
        for k, msg in warnings:
            doc_warnings.setdefault(k, []).append(msg)
        for j in todo:
            if j.key in bad:
                j.status, j.why = "NOT FILLED", bad[j.key]
        to_fill = [j for j in todo if j.key not in bad]

        qargo_ok = True
        if dry_run:
            for j in to_fill:
                j.status = "WOULD FILL"
                j.why = [m for m in doc_warnings.get(j.key, []) if not messages.saves_anyway(m)]
        elif to_fill:
            qargo_ok = fill_jobs(to_fill, doc_warnings, report)

        # ---- the report
        sec = lambda title: report.append(f"\n{title}")
        saved = [j for j in todo if j.status.startswith(("SAVED", "CHANGED"))]
        same = [j for j in todo if in_qargo_as_document(j)]
        later = [j for j in todo if not j.final]
        # a saved change with a warning (a consignment the bot could not cancel) is listed under NEEDS YOU too
        needs = [j for j in todo if (j not in saved or j.why) and j not in same + later and j.status != "WOULD FILL"]
        if dry_run and to_fill:
            sec("WOULD BE FILLED (dry run: Qargo not opened)")
            for j in to_fill:
                report.append(f"   {j.key:20} {j.order['customer']:12} ref {j.order.get('customer_reference') or '-':20} "
                              f"{j.mail.label()}" + (f"  [{len(j.why)} warning(s): not saved]" if j.why else ""))
        if saved:
            sec("SAVED IN QARGO")
            for j in saved:
                report.append(f"   {j.key:20} {j.qargo or '(Or-number not read)':12} {j.status:8} {j.order['customer']:12} "
                              f"ref {j.order.get('customer_reference') or '-':20} {j.mail.label()}")
                for n in j.notes:                  # what the bot decided on its own: a paired load, a new location,
                    if messages.saves_anyway(n) or n.startswith("change in "):     # what it changed in the order
                        report.append(f"      {n}")
        if needs:
            sec("!! NEEDS YOU: not saved by the bot (check it and save it yourself)")
            for j in needs:
                report.append(f"!! {j.key:20} {j.qargo or '':12} {j.status}  ({j.order['customer']}, {j.mail.label()})")
                for w in j.why[:8] + [n for n in j.notes if "another customer" in n]:
                    report.append(f"!!     {w}")
                if j in saved:
                    report.append(f"!!     saved as {j.qargo}; do the rest on its order page")
                elif j.status != "NOT FILLED":
                    report.append(f"!!     open it: {open_cmd(j)}")
                else:
                    report.append(f"!!     enter it by hand; document: {shown(j.folder / j.order['source'])}")
        if same:
            sec("ALREADY IN QARGO, as the document says")
            for j in same:
                report.append(f"   {j.key:20} {j.qargo:12} {j.mail.label()}")
        if later:
            sec("!! NOT DONE YET: the next check tries again")
            for j in later:
                report.append(f"!! {j.key:20} {j.status}  {'; '.join(j.why[:2])}  ({j.mail.label()})")
        if not_read:
            sec("!! DOCUMENTS NOT READ: not a layout the bot knows (if it is an order, enter it by hand)")
            read_from = {j.mail.id for j in jobs}
            for m, files in not_read:
                also = "  (the order in this mail was read: these are its other PDFs)" if m.id in read_from else ""
                report.append(f"!! {m.label()}: {', '.join(files)}{also}")
        if failed_mails:
            sec("!! MAILS NOT READ: Mail did not hand them over; the next check tries again")
            for m, why in failed_mails:
                report.append(f"!! {m.label()}: {why}")
        if day_hires:
            sec("Sx0068x DAY HIRES: no order of their own, the trips come with the Sx0021x route lists")
            for m, r in day_hires:
                report.append(f"   {r['summary']}  ({m.label()})")
        if Sx0027x_not_planned:
            sec("Sx0017x RITS NOT PLANNED YET: no order (only 'melden in Oss', no stops or times); the planned rit comes in a later mail")
            for m, r in Sx0027x_not_planned:
                report.append(f"   {r['summary']}  ({m.label()})")
        is_gl = lambda who: who.startswith("Sx0058x ")
        if any(not is_gl(who) for *_, who in Sx0027x_gone):
            sec("!! Sx0017x RITS NO LONGER IN THE PLANNING MAIL: not cancelled by the bot (the rit may have moved to another "
                "driver); check with Sx0043x Oss and cancel it yourself if it is gone")
            for m, k, orn, who in Sx0027x_gone:
                if not is_gl(who):
                    report.append(f"!! {k:20} {orn:12} was in the earlier mail for {who}  ({m.label()})")
        if any(is_gl(who) for *_, who in Sx0027x_gone):
            sec("!! Sx0069x JOBS NO LONGER IN THE NEWER SCHEDULE MAIL: not cancelled by the bot (the job may have moved "
                "to the other driver); check with Sx0058x and cancel it yourself if it is gone")
            for m, k, orn, who in Sx0027x_gone:
                if is_gl(who):
                    report.append(f"!! {k:20} {orn:12} was in the earlier mail for {who}  ({m.label()})")
        if any(not is_gl(who) for *_, who in Sx0027x_dropped):
            sec("Sx0017x RITS DROPPED: in an earlier mail of this check, not in the driver's newer one: no order made")
            for m, k, who in Sx0027x_dropped:
                if not is_gl(who):
                    report.append(f"   {k:20} {who}  ({m.label()})")
        if any(is_gl(who) for *_, who in Sx0027x_dropped):
            sec("Sx0069x JOBS DROPPED: in an earlier mail of this check, not in the driver's newer one: no order made")
            for m, k, who in Sx0027x_dropped:
                if is_gl(who):
                    report.append(f"   {k:20} {who}  ({m.label()})")
        if gl_replies:
            sec("Sx0069x REPLIES: the schedule under the reply was read; the reply itself is for you")
            for m, text in gl_replies:
                report.append(f"   {m.label()}\n      | {(text or '(no text)')[:300]}")
        if ah_plans:
            report.append(f"\nALERTMYDRIVER Sx0053x PLANNING: {len(ah_plans)} mail(s) for Sx0014x charters (Beste (Sx0015xxx)), "
                          f"nothing to do")
        if resent or replaced:
            sec("RE-SENT, the order unchanged or replaced by a newer mail: nothing to do")
            for j in resent + replaced:
                report.append(f"   {j.key:20} {j.mail.label()}")
        if plans:
            sec("Sx0070x PLANNING MAIL: the pictures are to be read into plan.json (see Sx0022x_plan.PLAN_FORMAT)")
            for m, man, folder in plans:
                day = man.get("date") or "?"
                report.append(f"   for {day}: {shown(folder / 'manifest.json')}  ({m.label()})")
                for w in man["wagens"]:
                    report.append(f"      Wagen {w['wagen']}: {', '.join(w['pictures']) or '(no picture)'}"
                                  + (f"  note: {w['note']}" if w["note"] else "")
                                  + (f"  !! pictures missing from the mail: {w['missing_pictures']}" if w["missing_pictures"] else ""))
                if not man.get("date"):
                    report.append("!!     the planned date is not in the mail: no stop order is taken from it")
        if no_doc:
            sec("MAILS WITHOUT A PDF (no order was made from these; if one is an order, enter it by hand)")
            for m in no_doc:
                try:
                    text = " ".join(mail_part(m, "text", run_js).split())[:EXCERPT]
                except MailNoAnswer:
                    text = "(text not available)"
                report.append(f"   {m.label()}" + (f" [attachments: {', '.join(m.attachments)}]" if m.attachments else ""))
                report.append(f"      | {text}")
        if not new:
            report.append("Nothing new.")

        if dry_run:
            return report, 0
        # ---- remember what was handled
        for j in todo:
            if j.final:
                s["orders"][j.key] = {"fp": fingerprint(j.order), "status": j.status, "qargo": j.qargo,
                                      "at": now.isoformat(), "mail": j.mail.id}
        retry = {j.mail.id for j in later} | {m.id for m, _ in failed_mails}
        given_up = []
        for m in new:
            rec = s["mails"].setdefault(m.id, {"received": m.received.isoformat(), "subject": m.subject, "tries": 0})
            if m.id in retry:
                if qargo_ok:               # a logged-out or silent Qargo is no fault of the mail
                    rec["tries"] = rec.get("tries", 0) + 1
                if rec["tries"] >= MAX_TRIES:
                    rec["done"] = True; given_up.append(m)
            else:
                rec["done"] = True
        for m in given_up:
            report.append(f"!! GIVEN UP after {MAX_TRIES} checks: {m.label()} - enter its orders by hand")
        if qargo_ok:
            s["last_check"] = now.isoformat()
        save_state(s, now)
    bad_run = not qargo_ok or failed_mails or later
    return report, 1 if bad_run else 0


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--dry-run", action="store_true",
                    help="only list the new mails and what the parser reads; Qargo, documents/ and mail_watch.json untouched")
    ap.add_argument("--since", help='also read mails from this moment on, e.g. "2026-10-21 06:00" (local time)')
    ap.add_argument("--account", nargs="*", default=list(ACCOUNTS), help="the mailboxes to read (default: both planning ones)")
    a = ap.parse_args(argv)
    since = datetime.datetime.fromisoformat(a.since).astimezone() if a.since else None
    lock = open(paths.data_dir() / "mail_watch.lock", "w")
    try:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    except BlockingIOError:
        print("Another mail check is still running: this one stops (nothing done).")
        return 0
    if not a.dry_run:
        import housekeeping
        housekeeping.tidy(housekeeping.KEEP_DAYS)
    report, code = check(since=since, dry_run=a.dry_run, accounts=a.account)
    text = "\n".join(report)
    print(text)
    if not a.dry_run:
        log = paths.logs_dir() / f"mail_log_{datetime.datetime.now():%Y%m%d_%H%M%S}.txt"
        log.write_text(text + "\n", encoding="utf-8")
        print(f"\nlog: {log}")
    return code


if __name__ == "__main__":
    sys.exit(main())
