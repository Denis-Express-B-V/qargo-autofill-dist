"""Where things live. One rule keeps the developer's command line exactly as it always was:

    no QARGO_DATA_DIR in the environment  ->  everything stays next to the code, the browser profile in ./.qargo-profile
    QARGO_DATA_DIR=<folder>               ->  all data goes there (the installed app's launcher always sets it)

Every function looks at the environment when it is called, never at import time, so a test can set the
variable after importing. Nothing here creates a folder outside QARGO_DATA_DIR.
"""
import contextlib, os, re, sys
from pathlib import Path

ENV_DATA, ENV_BROWSER = "QARGO_DATA_DIR", "QARGO_BROWSER"


def code_dir():
    """the folder of the .py files (read-only in an installed app: never write here when QARGO_DATA_DIR is set)"""
    return Path(__file__).resolve().parent


def data_dir():
    """done.json, location_overrides.json, missing_locations.json, orders_*.json, documents/, logs/ and the browser profile"""
    env = os.environ.get(ENV_DATA)
    if not env:
        return code_dir()
    d = Path(os.path.abspath(os.path.expanduser(env)))      # absolute: the app's working directory is the code folder
    d.mkdir(parents=True, exist_ok=True)
    return d


def documents_dir():
    """the trip PDFs, one folder per day (documents/<YYYY-MM-DD>/)"""
    return data_dir() / "documents"


def profile_dir(browser=None):
    """the browser's own folder; the Qargo login lives in it. Next to the code: .qargo-profile, as always.
    In the data folder: one per browser (profile-chromium, profile-chrome, profile-msedge), because a profile
    made by one browser must not be opened by another. browser=None: the one the launcher chose (QARGO_BROWSER)."""
    if not os.environ.get(ENV_DATA):
        return code_dir() / ".qargo-profile"
    name = re.sub(r"[^a-z0-9-]", "", (browser or os.environ.get(ENV_BROWSER) or "chromium").lower()) or "chromium"
    return data_dir() / f"profile-{name}"


def done_file():
    """orders the bot saved itself: {order key: Qargo URL}"""
    return data_dir() / "done.json"


def overrides_file():
    """optional {"<query>|<postcode>": "<exact Qargo name>"}"""
    return data_dir() / "location_overrides.json"


def missing_locations_file():
    """places the bot did not find in Qargo, so the next order does not run every search again"""
    return data_dir() / "missing_locations.json"


def api_file():
    """the bot's Qargo API clients (client_id / client_secret, master_data: {...}); git-ignored, mode 600, never
    in the repo (API_PLAN.md, "The bot's own client")"""
    return data_dir() / "qargo_api.json"


def api_token_file(role):
    """the cached token of one API client ("order" / "master_data"): Qargo gives one per client per hour"""
    return data_dir() / f".qargo_api_token_{role}.json"


def locations_cache_file():
    """every Qargo location record, paged once a day from the API (the API has no text search)"""
    return data_dir() / "qargo_locations.json"


def api_uploads_file():
    """the API path's uploads per order key: upload id, its last status, the order once Qargo made it"""
    return data_dir() / "api_uploads.json"


@contextlib.contextmanager
def shared_lock(name):
    """one process at a time for `name` (mail_watch fills orders in several browsers at once, 26 Oct 2026). On
    Windows (no fcntl) the bot runs one browser, so nothing to lock"""
    try:
        import fcntl
    except ImportError:
        yield
        return
    with open(data_dir() / f".{name}.lock", "w") as f:
        fcntl.flock(f, fcntl.LOCK_EX)
        try:
            yield
        finally:
            fcntl.flock(f, fcntl.LOCK_UN)


def logs_dir():
    """fill_log_*.txt and error_*.png: next to the code as always, or <data>/logs (where the launcher's app.log is)"""
    if not os.environ.get(ENV_DATA):
        return code_dir()
    d = data_dir() / "logs"
    d.mkdir(exist_ok=True)
    return d


def downloads_dir():
    """the user's Downloads folder (it may not exist, or not be readable: the caller says so)"""
    if sys.platform == "win32":      # the folder can be moved or renamed there: ask Windows (FOLDERID_Downloads)
        try:
            import ctypes, uuid
            guid = uuid.UUID("{374DE290-123F-4565-9164-39C4925E467B}").bytes_le
            out = ctypes.c_wchar_p()
            if ctypes.windll.shell32.SHGetKnownFolderPath(ctypes.c_char_p(guid), 0, None, ctypes.byref(out)) == 0:
                path = out.value
                ctypes.windll.ole32.CoTaskMemFree(ctypes.cast(out, ctypes.c_void_p))
                if path:
                    return Path(path)
        except Exception:
            pass
    return Path.home() / "Downloads"
