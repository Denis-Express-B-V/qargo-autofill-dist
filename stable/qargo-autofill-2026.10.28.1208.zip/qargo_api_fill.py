#!/usr/bin/env python3
"""The API path: a parsed order (SCHEMA.md) goes to Qargo as POST /v1/orders/order/upload instead of the
Create order form. Started by `run.py --api` and `mail_watch.py --api`; the browser path (qargo_fill.py) stays
the default.

  python3 qargo_api_fill.py orders.json [--only KEY ...] [--skip KEY ...] [--customer X] [--create-locations]
  python3 qargo_api_fill.py --pending          # only: which earlier uploads became orders (Create order clicked)

What happens per order (API_PLAN.md "How the API path works"):
 1. the stops' locations are picked from the location list (every record, paged from the API once a day) with
    the same rules as the form's search (qargo_fill.pick_candidates, CLAUDE.md "Locations"): a doubt = an empty
    stop = the order is NOT uploaded (the form would leave the field empty for a person; the API has no field).
    A record the rules allow is made first (POST /v1/locations/location), then used.
 2. the stop is sent as the record's exact name, address, postal_code, city, country: the import matches a
    location on that text only (location.id is ignored, another spelling = a second record; 27 Oct 2026).
 3. the upload is watched until it leaves IN_PROGRESS: READY_TO_UPSERT = it sits on Orders > Order imports as
    "Ready to create order" until a planner clicks Create order (accepted for now); ERROR = refused by Qargo
    (it gives no reason); DUPLICATE = an older upload of the same order was superseded.
 4. api_uploads.json remembers the upload per order key; done.json gets the key at once (a rerun never uploads it
    twice); `--pending` / the next run reads which uploads are COMPLETED and records the order's URL.
No PDF goes on the order (the API has no order-document endpoint; accepted 27 Oct 2026): the document is named in
the log and in Qargo's input_source. An order with a warning that holds it (a doubt a person must settle) is not
uploaded: there is no tab to leave it in.
"""
import argparse, datetime, json, re, sys, time
from pathlib import Path
HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import paths, messages, qargo_api
import qargo_fill as qf                     # the location rules (pick_candidates, can_create ...) and the log
from validate_orders import validate

UPLOAD_ANSWER_S = 60                        # the upload's status is watched this long for leaving IN_PROGRESS
PENDING = ("TODO", "IN_PROGRESS", "UPSERT_IN_PROGRESS", "READY_TO_UPSERT")
SCENARIO = {"Import": "IMPORT", "Export": "EXPORT"}
IMPORTS_PAGE = "Orders > Order imports"


# ------------------------------------------------------------------ the location list as the form shows it
def option_name(rec):
    """the dropdown's text for a record: the display name, with the record's own name after it when they differ
    ("Sx0054x Distributiecentrum Zaandam (DCZ) (Hoofdtocht 1)"), as PREFERRED and the tests expect"""
    name, disp = (rec.get("name") or "").strip(), (rec.get("display_name") or "").strip()
    return f"{disp} ({name})" if disp and name and disp != name else (disp or name)


def option_address(rec):
    """"Hoofdtocht 1, NL-1507 CJ Zaandam": the address line the form's dropdown shows under the name"""
    cc, pc, city = (rec.get("country") or "").strip(), (rec.get("postal_code") or "").strip(), (rec.get("city") or "").strip()
    tail = " ".join(x for x in ((f"{cc}-{pc}" if cc and pc else pc or cc), city) if x)
    return ", ".join(x for x in ((rec.get("address") or "").strip(), tail) if x)


def record_option(rec):
    """one record in the shape qargo_fill.pick_candidates reads (what read_options gives for a dropdown row)"""
    return {"name": option_name(rec), "address": option_address(rec), "recent": False, "id": rec.get("id") or "",
            "idx": 0, "text": option_name(rec), "record": rec}


def search(options, q):
    """the records the form's search would list for q: name or address holding it (accents, spaces, case aside)"""
    nq = qf.norm(q)
    return [o for o in options if nq and nq in qf.norm(o["name"] + " " + o["address"])] if nq else []


def queries(loc):
    """what the form would be asked, in order (qargo_fill.choose_location): the parser's query, the street up to
    its number, the printed name, the name without numbers, the postcode as Qargo writes it"""
    out = [loc["query"]]
    mq = re.match(r"^(.*?\d+)", loc.get("street") or "")
    street_q = mq.group(1) if mq else loc.get("street")
    street_q = re.sub(r"\bProf\.?(?=\s)", "Professor", street_q or "") or street_q
    bare = "" if loc.get("store") else re.sub(r"\s+", " ", re.sub(r"\b\d+\b", " ", loc.get("name") or "")).strip()
    pc = qf.norm(loc.get("postcode"))
    pc_q = f"{pc[:4]} {pc[4:]}" if re.fullmatch(r"\d{4}[A-Z]{2}", pc) else pc
    for q in (street_q, loc.get("name"), bare, pc_q):
        if q and q not in out:
            out.append(q)
    return out


def place(loc):
    return f"{loc.get('name')!r} ({loc.get('street')}, {loc.get('postcode')} {loc.get('city')})"


def find_record(loc, options, ctx, master):
    """the record for one printed place, by the form's rules on the full list, or None with the warning in ctx.
    master: the master_data Client (to make a record the rules allow); options: record_option() of every record"""
    seen, doubts, tried = [], [], []
    for q in queries(loc):
        if q in tried:
            continue
        tried.append(q)
        opts = search(options, q)
        seen += [o["name"] + " / " + o["address"] for o in opts][:4]
        cands, note = qf.pick_candidates(opts, loc)
        if not cands:
            continue
        if note and note[0] == "check" and note[1].startswith("postcode differs for"):
            try:
                same = qf.same_place_by_map(cands, loc)
            except qf.MapNoAnswer as e:
                same, note = None, ("check", f"{note[1]} ({e})")           # the doubt stays: never "not the same"
            if same:
                note = ("note", same)
        if note and note[0] == "check":
            doubts.append(note[1])                  # any doubt: never a guess (a wrong place beats nothing, 13 Oct 2026)
            continue
        if note:
            ctx["notes"].append(note[1])
        hints = qf.hint_tokens(loc.get("name"))
        score = lambda o: sum(1 for h in hints if qf.norm(h) in qf.norm(o["name"] + " " + o["address"]))
        cands.sort(key=score, reverse=True)
        best = cands[0]
        if len(cands) > 1 and score(cands[0]) == score(cands[1]) and cands[0]["name"] != cands[1]["name"]:
            doubts.append(f"several records fit '{q}': {[c['name'] for c in cands[:4]]}")
            continue
        lacks = record_lacks(best["record"])
        if lacks:
            # the import matches a record on its text and place: one without a postcode or coordinates gets a second
            # record instead (Or-0000093 / Or-0000094, "Loven" = Retourencentrum Tilburg, postcode empty, 27 Oct 2026).
            # The form path can pick such a record; the API path cannot send it: a doubt, with what to fix in Qargo
            doubts.append(f"the record {best['name']!r} has no {lacks} in Qargo: the import would make a second record "
                          f"for it; add the {lacks} to the record in Qargo")
            continue
        return best
    own = qf.own_record(loc)
    if own:
        doubts.append(f"Qargo's own record for this place, {own!r}, is not in the search results")
    from_bag = None
    if (not doubts and ctx.get("create_locations") and loc.get("unverified") and not loc.get("postcode")
            and loc.get("country", "NL") == "NL" and qf.street_parts(loc.get("street"))[1] and loc.get("city")):
        try:        # a one-line depot the BAG register knows exactly gets its postcode and is made (26 Oct 2026)
            from_bag = qf.map_postcode(loc["street"].strip(), loc["city"].strip(), "NL")[0]
        except qf.MapNoAnswer as e:
            ctx["warnings"].append(f"NO ANSWER FROM THE MAP for {loc.get('name')!r} ({loc.get('street')}, "
                                   f"{loc.get('city')}): {e}; location left empty, pick it by hand")
            return None
        if from_bag:
            loc.update(postcode=from_bag, bag_postcode=True)
    if not doubts and qf.can_create(loc, ctx):
        made = create_record(master, loc, ctx, options)
        if made:
            if loc.get("second_record"):
                ctx["notes"].append(loc["second_record"])
            if from_bag:
                ctx["notes"].append(f"postcode {from_bag} for '{loc['street']}, {loc['city']}' taken from the BAG "
                                    f"register (printed without one)")
            return made
    ctx["warnings"].append(f"NO LOCATION for {place(loc)}; tried {tried}; seen: {seen[:6]}"
                           + (f"; not filled: {list(dict.fromkeys(doubts))}" if doubts else ""))
    return None


def create_record(master, loc, ctx, options):
    """a new record through the API, as the form's "Add location manually" would make it; the option made, or
    None (the warning says why). Never twice for one address in a run (CREATED / QARGO_CREATED_FILE)"""
    key = (qf.norm(loc["street"]), qf.norm(loc["postcode"]))
    with qf.shared_lock("create_location"):
        earlier = qf.created_in_run(key)
        if earlier:                                  # another process of this run made it: use that record
            mine = [o for o in options if o["name"].startswith(earlier) and qf.norm(loc["postcode"]) in qf.norm(o["address"])]
            if mine:
                return mine[0]
            ctx["warnings"].append(f"location {place(loc)} was created earlier in this run as {earlier!r} but the "
                                   f"search does not show it yet: pick it by hand")
            return None
        addr = qf.drawer_address(loc)
        try:
            rec = master.create_location(qf.record_name(loc), addr["address"], addr["postal_code"], addr["city"],
                                         loc.get("country", "NL"))
        except qargo_api.NoAnswer as e:
            ctx["warnings"].append(f"location {place(loc)} NOT created: {e}. Create it by hand")
            return None
        except qargo_api.ApiError as e:
            ctx["warnings"].append(f"location {place(loc)} NOT created ({type(e).__name__}: {str(e)[:120]}). Create it by hand")
            return None
        if not (rec.get("latitude") and rec.get("longitude")):
            # Qargo saved it without coordinates: the driver's app cannot route to it. Say so; the record exists
            ctx["warnings"].append(f"location {place(loc)} NOT created: Qargo found no coordinates for the address "
                                   f"(record {rec.get('id')} saved without them). Create it by hand")
            return None
        qf.remember_created(key, qf.record_name(loc))
    made = f"{qf.record_name(loc)} / {rec.get('address')}, {rec.get('postal_code')} {rec.get('city')}"
    ctx["notes"].append(f"CREATED location {made} ({rec['latitude']}, {rec['longitude']}) - new in Qargo, check it")
    opt = record_option(rec)
    options.append(opt)
    return opt


def record_lacks(rec):
    """what a record misses that the import needs to match it: 'postcode', 'coordinates', or '' (nothing)"""
    if not (rec.get("postal_code") or "").strip():
        return "postcode"
    if not (rec.get("latitude") and rec.get("longitude")):
        return "coordinates"
    return ""


def location_fields(rec):
    """what goes on the stop: the record's own text, exactly as stored (the import matches on it, 27 Oct 2026),
    the display name included when the record has one: Or-0000093 got second records for the two stops whose
    record has a display name ("Sx0053x 3101" / name "Conservenweg 8") when only the name was sent"""
    return {k: rec[k] for k in ("name", "display_name", "address", "postal_code", "city", "country")
            if rec.get(k) is not None and (k != "display_name" or rec[k])}


# ------------------------------------------------------------------ the payload
def api_date(d):
    """DD/MM/YYYY -> YYYY-MM-DD"""
    return datetime.datetime.strptime(d, "%d/%m/%Y").strftime("%Y-%m-%d")


def api_stop(st, rec):
    s = {"location": location_fields(rec), "date": api_date(st["date"])}
    if st.get("start") or st.get("end"):
        # the time window as printed; Enforce on when either is set, as the form path does. Only what is printed
        # goes in: a start alone stays a start alone
        w = {"is_enforced": True}
        if st.get("start"):
            w["start_time"] = st["start"]
        if st.get("end"):
            w["end_time"] = st["end"]
        s["time_window"] = w
    if st.get("duration"):
        h, m = st["duration"].split(":")
        s["duration"] = int(h) * 3600 + int(m) * 60
    if st.get("note"):
        s["note"] = st["note"]
    if st.get("reference"):
        s["reference_number"] = st["reference"]
    if st.get("phone"):
        s["phone_number"] = st["phone"]
    if st.get("activity"):
        s["activity_label"] = st["activity"]
    return s


def api_goods(g):
    out = {}
    if g.get("quantity") is not None:
        out["quantity"] = g["quantity"]
    if g.get("description"):
        out["description"] = g["description"]
    if g.get("weight_kg") is not None:
        out["total_weight_kg"] = g["weight_kg"]
    if g.get("temperature_c") is not None:
        out["ordered_transport_temperature_degrees"] = g["temperature_c"]
    return out


def not_on_api_path(o):
    """what the upload cannot carry: an extra stop of a container consignment (the form's "Add stop"; the
    import has no stop between pickup and delivery). Such an order goes through the browser"""
    out = []
    for i, c in enumerate(o["consignments"], 1):
        if c.get("stops"):
            out.append(f"c{i} extra stop (the import has no stop between pickup and delivery)")
    return out


def payload(o, picked, operation="CREATE"):
    """the upload for order o; picked: {"start stop" | "end stop" | "c1 collect" | "c1 deliver": record}"""
    p = {"operation": operation, "order_identifier": o["key"], "order_status": "TO_PLAN",
         "customer": {"name": o["customer"]}, "transport_service": {"name": o.get("service") or "Transport"},
         "customer_reference_number": o.get("customer_reference") or "",
         "input_source": f"qargo-autofill {o.get('source') or ''}".strip(), "consignments": []}
    if o.get("instructions"):
        p["planning_instructions"] = o["instructions"]
    if o.get("ritnummer") is not None:
        p["custom_fields"] = {"ritnummer": o["ritnummer"]}
    if o.get("vehicle_category"):
        p["vehicle_category"] = {"name": o["vehicle_category"]}
    if o.get("container"):
        c = o["container"]
        box = {k: v for k, v in (("container_number", c.get("number")), ("seal_number", c.get("seal")),
                                 ("ocean_liner_name", c.get("liner")), ("container_scenario", SCENARIO.get(c.get("scenario"))))
               if v}
        if box:
            p["container"] = box
    if o.get("setup"):
        p["setup_stops"] = [api_stop(o["setup"], picked["start stop"])]
    if o.get("teardown"):
        p["teardown_stops"] = [api_stop(o["teardown"], picked["end stop"])]
    for i, c in enumerate(o["consignments"], 1):
        cons = {"pickup_stop": api_stop(c["pickup"], picked[f"c{i} collect"]),
                "delivery_stop": api_stop(c["delivery"], picked[f"c{i} deliver"])}
        if c.get("reference"):
            cons["consignment_reference_number"] = c["reference"]
        if c.get("instructions"):
            cons["planning_instructions"] = c["instructions"]
        goods = [g for g in (api_goods(g) for g in c.get("goods") or []) if g]
        if goods:
            cons["goods"] = goods
        p["consignments"].append(cons)
    return p


def delete_payload(key):
    """operation DELETE: cancels the order (the Or-number stays); it waits for the click like a create"""
    return {"operation": "DELETE", "order_identifier": key, "consignments": [], "customer": {}}


def stops_of(o):
    """(label, stop) for every stop of the order, in the form's order"""
    out = []
    if o.get("setup"):
        out.append(("start stop", o["setup"]))
    for i, c in enumerate(o["consignments"], 1):
        out += [(f"c{i} collect", c["pickup"]), (f"c{i} deliver", c["delivery"])]
    if o.get("teardown"):
        out.append(("end stop", o["teardown"]))
    return out


# ------------------------------------------------------------------ what was uploaded
def load_uploads():
    return qargo_api._read_json(paths.api_uploads_file(), {})


def remember_upload(key, **fields):
    with paths.shared_lock("api_uploads"):
        known = load_uploads()
        known[key] = {**known.get(key, {}), **fields, "at": datetime.datetime.now().isoformat(timespec="seconds")}
        paths.api_uploads_file().write_text(json.dumps(known, indent=1, ensure_ascii=False), encoding="utf-8")
        return known[key]


def order_number(order):
    """the Or-number: Qargo puts it in the order's `order_identifier` once the order exists (Or-0000093, 27 Oct
    2026: the bot's key is not kept there), else wherever a top-level text carries one, else ''"""
    for v in [order.get("order_identifier") or ""] + list(order.values()):
        if isinstance(v, str):
            m = re.search(r"\bOr-\d{5,}\b", v)
            if m:
                return m.group(0)
    return ""


def new_records(order, picked):
    """the stops the import did NOT put on the record the bot picked (picked: {label: record id}): the import
    made a new record instead (Or-0000093: "Conservenweg 8", "Loven"). [(label, record the order has, picked id)]"""
    out = []
    stops = []
    for i, c in enumerate(order.get("consignments") or [], 1):
        stops += [(f"c{i} collect", c.get("pickup_stop")), (f"c{i} deliver", c.get("delivery_stop"))]
    stops += [("start stop", order.get("start_stop")), ("end stop", order.get("end_stop"))]
    for label, st in stops:
        loc = (st or {}).get("location") or {}
        want = picked.get(label)
        if want and loc.get("id") and loc["id"] != want:
            out.append((label, loc, want))
    return out


def record_completed(key, status, api, done, done_path, picked=None):
    """an upload that became an order: its URL and Or-number into api_uploads.json and done.json, and a check
    that every stop is on the record the bot picked (picked: {label: record id}; the import makes a new record
    for a text it does not match). Returns (url, or_number, [warnings])"""
    oid = status.get("order_id")
    url = qargo_api.order_url(oid) if oid else ""
    orn, warnings = "", []
    if oid:
        try:
            order = api.order(oid)
            orn = order_number(order)
            for label, loc, want in new_records(order, picked or {}):
                warnings.append(f"IMPORT MADE A NEW RECORD for {label} of {orn or key}: {loc.get('name')!r} "
                                f"({loc.get('address')}, {loc.get('postal_code')} {loc.get('city')}; {loc.get('id')}) instead "
                                f"of the record the bot picked ({want}); put the stop on the right record and delete "
                                f"the new one in Qargo")
        except (qargo_api.NoAnswer, qargo_api.ApiError) as e:
            warnings.append(f"NO ANSWER from the Qargo API for order {oid}: {e}; the stops' records were not checked")
    remember_upload(key, status=status.get("upload_status"), order_id=oid, order_url=url, order=orn, checked=warnings)
    if url:
        qf.remember_done(done, done_path, key, url)
    return url, orn, warnings


def resolve_pending(api, done=None, done_path=None):
    """which earlier uploads left the queue since: [(key, old status, new status, url, Or-number, [warnings])].
    Called at the start of every API run and by --pending; no answer for one upload leaves it as it is"""
    done_path = done_path or paths.done_file()
    if done is None:
        done = qargo_api._read_json(done_path, {})
    out = []
    for key, rec in sorted(load_uploads().items()):
        if rec.get("status") not in PENDING or not rec.get("upload_id"):
            continue
        try:
            st = api.upload_status(rec["upload_id"])
        except (qargo_api.NoAnswer, qargo_api.ApiError) as e:
            qf.log(f"    {key}: upload {rec['upload_id']}: {e}")
            continue
        new = st.get("upload_status")
        if new == rec.get("status"):
            continue
        url = orn = ""
        warnings = []
        if new == "COMPLETED":
            url, orn, warnings = record_completed(key, st, api, done, done_path, rec.get("records"))
        else:
            remember_upload(key, status=new)
        out.append((key, rec.get("status"), new, url, orn, warnings))
    return out


# ------------------------------------------------------------------ one order
def upload_one(api, master, o, options, *, doc_warnings=(), done=None, done_path=None, create_locations=False,
               operation=None, answer_s=UPLOAD_ANSWER_S, sleep=time.sleep):
    """one order through the API. Returns (status, ctx) like qargo_fill.fill_one: status UPLOADED (waits for the
    click), CREATED (an order already), REFUSED, NOT UPLOADED (a doubt or a warning holds it), UPLOAD? (sent, no
    answer), NO ANSWER, ERROR. operation: CREATE / UPDATE (default: UPDATE when the bot uploaded this key before
    or the order is marked as a change)"""
    done_path = done_path or paths.done_file()
    if done is None:
        done = qargo_api._read_json(done_path, {})
    ctx = {"warnings": [f"JSON: {m}" for m in doc_warnings if not messages.saves_anyway(m)], "chosen": [],
           "notes": [m for m in doc_warnings if messages.saves_anyway(m)], "by_hand": [],
           "create_locations": create_locations, "order": o["key"]}
    earlier = load_uploads().get(o["key"])
    if operation is None:
        # UPDATE only for an order Qargo made from the bot's upload (or marked as a change): a refused or still
        # waiting upload is simply sent again as CREATE (the waiting one turns DUPLICATE: newest wins)
        operation = "UPDATE" if (o.get("change") or (earlier or {}).get("status") == "COMPLETED") else "CREATE"
    qf.log(f"--- {o['key']} ({o['customer']} {o['customer_reference']}, {len(o['consignments'])} consignments) "
           f"-> API {operation}" + (f", replaces upload {earlier['upload_id']} ({earlier.get('status')})" if earlier else ""))
    status = "NOT UPLOADED"
    try:
        unsupported = not_on_api_path(o)
        ctx["warnings"] += [f"not on the API path: {what}; fill it in the browser" for what in unsupported]
        picked = {}
        for label, st in (stops_of(o) if not unsupported else []):
            rec = find_record(st["location"], options, ctx, master)
            if rec:
                picked[label] = rec["record"]
                ctx["chosen"].append(f"{label}: {rec['name']} / {rec['address']}")
            else:
                ctx["chosen"].append(f"{label}: NO LOCATION")
        if ctx["warnings"]:
            # a doubt or a warning that holds the order: nothing is uploaded (there is no tab to leave it in)
            status = "NOT UPLOADED"
        else:
            p = payload(o, picked, operation)
            try:
                first = api.upload(p)
            except qargo_api.NoAnswer as e:
                # the upload may or may not have reached Qargo: never "not uploaded", never sent again blindly
                ctx["warnings"].append(f"NO ANSWER from the Qargo API after sending the upload: {e}; look at "
                                       f"{IMPORTS_PAGE} before sending it again")
                qf.log("    " + ctx["warnings"][-1])
                return "UPLOAD?", ctx
            uid = first.get("upload_id")
            remember_upload(o["key"], upload_id=uid, status=first.get("upload_status"), operation=operation,
                            source=o.get("source"), consignments=len(o["consignments"]),
                            records={label: r.get("id") for label, r in picked.items()})
            st = first
            deadline = time.time() + answer_s
            while st.get("upload_status") in ("TODO", "IN_PROGRESS", "UPSERT_IN_PROGRESS") and time.time() < deadline:
                sleep(2)
                try:
                    st = api.upload_status(uid)
                except qargo_api.NoAnswer as e:
                    ctx["warnings"].append(f"NO ANSWER from the Qargo API: {e}; the upload {uid} was sent, its state "
                                           f"is read at the next run")
                    break
            up = st.get("upload_status")
            remember_upload(o["key"], status=up)
            if up == "READY_TO_UPSERT":
                status = "UPLOADED"
                ctx["notes"].append(f"UPLOADED to Qargo (upload {uid}): waits for Create order on {IMPORTS_PAGE}")
                qf.remember_done(done, done_path, o["key"], f"upload:{uid}")
            elif up == "COMPLETED":
                url, orn, checked = record_completed(o["key"], st, api, done, done_path,
                                                     {label: r.get("id") for label, r in picked.items()})
                status = f"CREATED ({orn or url})"
                ctx["qargo"] = {"order": orn, "url": url}
                ctx["warnings"] += checked
            elif up == "ERROR":
                status = "REFUSED"
                ctx["warnings"].append(f"REFUSED by Qargo's import (upload {uid}): Qargo gives no reason; look at "
                                       f"the row on {IMPORTS_PAGE}, then enter the order in the browser")
            elif up == "DUPLICATE":
                status = "REFUSED"
                ctx["warnings"].append(f"REFUSED by Qargo's import (upload {uid}): superseded by a newer upload "
                                       f"of {o['key']} (DUPLICATE); look at {IMPORTS_PAGE}")
            elif up in ("TODO", "IN_PROGRESS", "UPSERT_IN_PROGRESS"):
                status = "UPLOADED"
                ctx["warnings"].append(f"upload {uid} still {up} after {answer_s} s (internet?); its state is read "
                                       f"at the next run; look at {IMPORTS_PAGE}")
                qf.remember_done(done, done_path, o["key"], f"upload:{uid}")
            else:
                status = "ERROR"
                ctx["warnings"].append(f"upload {uid}: unknown state {up!r}; look at {IMPORTS_PAGE}")
    except qargo_api.RateLimited as e:
        status = "NO ANSWER"
        ctx["warnings"].append(f"NO TOKEN from the Qargo API: {e}; not uploaded, the next run tries again")
    except qargo_api.NoAnswer as e:
        status = "NO ANSWER"
        ctx["warnings"].append(f"NO ANSWER from the Qargo API: {e}; not uploaded, the next run tries again")
    except qargo_api.ApiError as e:
        status = "ERROR"
        ctx["warnings"].append(f"QARGO API {e}")
    except Exception as e:
        status = "ERROR"
        ctx["warnings"].append(f"{type(e).__name__}: {str(e).splitlines()[0][:300]}")
    for c in ctx["chosen"]:
        qf.log(f"    {c}")
    for n in ctx["notes"]:
        qf.log(f"    note: {n}")
    for w in ctx["warnings"]:
        qf.log(f"    !! {w}")
    qf.log(f"    => {status}")
    return status, ctx


# ------------------------------------------------------------------ a whole orders file
def clients(max_wait_s=3600):
    """(order client, master_data client)"""
    return qargo_api.Client("order", max_wait_s=max_wait_s), qargo_api.Client("master_data", max_wait_s=max_wait_s)


def location_options(master):
    """every record as the form would show it; NoAnswer / RateLimited / ApiError go up to the caller"""
    return [record_option(r) for r in master.locations()]


def log_resolved(resolved):
    for key, old, new, url, orn, warnings in resolved:
        qf.log(f"{key:20} upload {old} -> {new}" + (f": order {orn or url}" if url else ""))
        for w in warnings:
            qf.log(f"    !! {w}")


def run_api(orders_path, *, only=None, customer=None, skip=(), create_locations=False, not_read=(), change=(),
            pdf_dir=None, max_wait_s=3600):
    """What `python3 qargo_api_fill.py orders.json ...` does. Returns [(key, status, number of warnings)]"""
    qf.LOG_LINES.clear()
    orders = json.loads(Path(orders_path).read_text(encoding="utf-8-sig"))
    for o in orders:
        if o.get("key") in change:
            o["change"] = True
    pdf_dir = [Path(d).expanduser().resolve() for d in (pdf_dir or [paths.documents_dir(), paths.downloads_dir()])]
    done_path = paths.done_file()
    done = qargo_api._read_json(done_path, {})
    sel = [o for o in orders
           if (not only or o["key"] in only) and (not customer or o["customer"].lower() == customer.lower())
           and o["key"] not in skip and (o["key"] not in done or o.get("change"))]
    errors, warnings = validate(sel, pdf_dir)
    bad = sorted({k for k, _ in errors})
    for k, m in errors:
        qf.log(f"INVALID {k}: {m}")
    if bad:
        qf.log(f"not uploading {len(bad)} invalid order(s): {bad} - fix the JSON or the parser first")
        sel = [o for o in sel if o.get("key") not in bad]
    results = [(k, "NOT UPLOADED", 0, "; ".join(m for kk, m in errors if kk == k)) for k in bad]
    qf.log(f"{len(sel)} orders to upload through the API (skipping {len(done)} already done per done.json)")
    doc_warnings = {}
    for k, m in warnings:
        doc_warnings.setdefault(k, []).append(m)
    try:
        api, master = clients(max_wait_s)
        log_resolved(resolve_pending(api, done, done_path))
        options = location_options(master) if sel else []
        if sel:
            qf.log(f"{len(options)} location records in the list")
    except (qargo_api.NoCredentials, qargo_api.NoAnswer, qargo_api.ApiError) as e:
        qf.log(f"!! QARGO API NOT USABLE: {e}. Nothing was uploaded.")
        results += [(o["key"], "NO ANSWER", 1, f"QARGO API NOT USABLE: {e}") for o in sel]
        sel = []
    for o in sel:
        status, ctx = upload_one(api, master, o, options, doc_warnings=doc_warnings.get(o["key"], []), done=done,
                                 done_path=done_path, create_locations=create_locations)
        why = "" if not ctx["warnings"] else ctx["warnings"][0]
        results.append((o["key"], status, len(ctx["warnings"]), why))
    source = {o.get("key"): o.get("source") or "" for o in orders}
    summary(results, source, not_read)
    (paths.logs_dir() / f"api_log_{datetime.datetime.now():%Y%m%d_%H%M%S}.txt").write_text("\n".join(qf.LOG_LINES), encoding="utf-8")
    return [r[:3] for r in results]


def summary(results, source, not_read=()):
    """the last thing on screen: what waits on Orders > Order imports, then everything that is not in Qargo"""
    ok = [r for r in results if r[1].startswith(("UPLOADED", "CREATED"))]
    failed = [r for r in results if r not in ok]
    qf.log("==== summary")
    for k, s, w, _ in ok:
        qf.log(f"{k:20} {s:28} warnings={w}  {source.get(k, '')}")
    for k, s, _, why in failed:
        qf.log(f"!! {k:17} {s:28} {source.get(k, '')}")
        qf.log(f"!!     {why}")
    for f in not_read:
        qf.log(f"!! {f}: NOT READ - no order was made from this document; enter it by hand")
    n = len(failed) + len(not_read)
    qf.log(f"{len(ok)} uploaded (they wait for Create order on {IMPORTS_PAGE}), {n} NOT in Qargo"
           + (" <<<<<< look at the !! lines" if n else ""))
    return n


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("orders", nargs="?")
    ap.add_argument("--only", nargs="*")
    ap.add_argument("--customer")
    ap.add_argument("--skip", nargs="*", default=[])
    ap.add_argument("--change", nargs="*", default=[], metavar="KEY", help="these orders change one Qargo has: operation UPDATE")
    ap.add_argument("--create-locations", action="store_true",
                    help="an address Qargo has no location for gets a new record through the API (the form's rules)")
    ap.add_argument("--pdf-dir", action="append", help="folder with the source documents (repeatable)")
    ap.add_argument("--not-read", nargs="*", default=[], metavar="FILE")
    ap.add_argument("--pending", action="store_true", help="only read which earlier uploads became orders")
    ap.add_argument("--max-wait", type=int, default=3600, metavar="S",
                    help="the longest Retry-After the token request waits out (default 3600; Qargo gives one token per hour)")
    a = ap.parse_args(argv)
    if a.pending:
        api = qargo_api.Client("order", max_wait_s=a.max_wait)
        resolved = resolve_pending(api)
        log_resolved(resolved)
        pending = {k: r for k, r in load_uploads().items() if r.get("status") in PENDING}
        qf.log(f"{len(resolved)} upload(s) changed; {len(pending)} still waiting for Create order on {IMPORTS_PAGE}: "
               f"{sorted(pending)}")
        return 0
    if not a.orders:
        ap.error("an orders file, or --pending")
    results = run_api(a.orders, only=a.only, customer=a.customer, skip=a.skip, create_locations=a.create_locations,
                      not_read=a.not_read, change=a.change, pdf_dir=a.pdf_dir, max_wait_s=a.max_wait)
    return 1 if any(not s.startswith(("UPLOADED", "CREATED")) for _, s, _ in results) or a.not_read else 0


if __name__ == "__main__":
    sys.exit(main())
