"""Qargo's external API (api.qargo.com) for the bot: tokens, master data, order uploads. No browser.

Two API clients, both in qargo_api.json in the data folder (paths.api_file(); git-ignored, mode 600):
    {"client_id": ..., "client_secret": ...,                       # the API_ORDER client: orders
     "master_data": {"client_id": ..., "client_secret": ...}}      # the API_MASTER_DATA client: locations, companies ...
A client's role cannot be changed afterwards, so each role has its own client (API_PLAN.md, 27 Oct 2026).

    Client("order").upload(payload)            POST /v1/orders/order/upload
    Client("master_data").locations()          every record, from a local cache refreshed once a day

Rules (CLAUDE.md "Anything that goes over the internet"; API_PLAN.md "The bot's own client"):
  * Qargo gives ONE token per client per hour: the token is cached in a file under a shared lock and reused until it
    is about to expire; on 429 the bot waits Retry-After once, never retries in a loop (seven quick requests cost a
    one-hour lockout on 27 Oct 2026).
  * Every request waits for Qargo's answer with a deadline; no answer raises NoAnswer, which is its own outcome,
    never "no" (never "not in Qargo", never "not uploaded").
  * A secret or a token is never printed, logged or put in an exception.
"""
import base64, datetime, json, os, time, urllib.error, urllib.parse, urllib.request
import paths

API_URL = (os.environ.get("QARGO_API_URL") or "https://api.qargo.com").rstrip("/")
ANSWER_S = 30            # deadline for one answer (API_PLAN: the upload answers within seconds; the location list is 100 per page)
TOKEN_ANSWER_S = 20
MARGIN_S = 120           # a token this close to its end is not used: a new one is asked for
RETRY_429_S = 60         # a request (not the token) answered 429 with a shorter Retry-After is sent once more
CACHE_AGE_S = 24 * 3600  # the location list is paged again when older than this


class NoAnswer(Exception):
    """the API did not answer in time, or the line is down (internet?): says nothing about Qargo's data"""


class NoCredentials(Exception):
    """no qargo_api.json, or a client missing from it"""


class ApiError(Exception):
    """Qargo answered with an error status; .status and .body (never the request's headers)"""
    def __init__(self, status, body, what=""):
        self.status, self.body = status, (body or "")[:300]
        super().__init__(f"{what + ': ' if what else ''}HTTP {status}" + (f": {self.body}" if self.body else ""))


class RateLimited(ApiError):
    """429: Qargo gives one token per client per hour; .until = when the next one may be asked for (epoch seconds)"""
    def __init__(self, until, what="token"):
        self.until = until
        when = datetime.datetime.fromtimestamp(until).strftime("%H:%M")
        super().__init__(429, "", f"{what}: Qargo gives one token per client per hour, the next one at {when}")


def credentials(role="order"):
    """(client_id, client_secret) of the "order" or "master_data" client"""
    f = paths.api_file()
    if not f.exists():
        raise NoCredentials(f"no {f.name} in {f.parent}: the bot's API clients are missing (API_PLAN.md, Access)")
    try:
        d = json.loads(f.read_text(encoding="utf-8-sig"))
    except ValueError as e:
        raise NoCredentials(f"{f.name} is not valid JSON: {e}")
    c = d if role == "order" else (d.get(role) or {})
    if not isinstance(c, dict) or not c.get("client_id") or not c.get("client_secret"):
        raise NoCredentials(f"{f.name} has no client_id / client_secret for the {role} client")
    return c["client_id"], c["client_secret"]


def _write_private(path, data):
    """a JSON file nobody else on the machine may read (a token, a secret)"""
    tmp = path.with_name(path.name + ".tmp")
    tmp.write_text(json.dumps(data), encoding="utf-8")
    os.chmod(tmp, 0o600)
    os.replace(tmp, path)


def _read_json(path, default):
    try:
        return json.loads(path.read_text(encoding="utf-8-sig")) if path.exists() else default
    except ValueError:
        return default


class Client:
    """one API client ("order" or "master_data"), its cached token and the requests its role allows.
    sleep / now can be replaced in tests; max_wait_s: the longest Retry-After the token request waits out
    (longer = RateLimited at once, so a scheduled check is not blocked for an hour)"""

    def __init__(self, role="order", *, answer_s=ANSWER_S, max_wait_s=3600, sleep=time.sleep, now=time.time):
        self.role, self.answer_s, self.max_wait_s, self.sleep, self.now = role, answer_s, max_wait_s, sleep, now
        self.client_id, self._secret = credentials(role)
        self.requests = []          # (method, path, status) of every request sent, for the log and the tests

    # ---------------------------------------------------------------- the token
    def _token_file(self):
        return paths.api_token_file(self.role)

    def token(self):
        """the cached token while it is good; else one from Qargo (one per hour: cached for every process)"""
        with paths.shared_lock(f"api_token_{self.role}"):
            c = _read_json(self._token_file(), {})
            if c.get("access_token") and c.get("client_id") == self.client_id and c.get("expires_at", 0) - self.now() > MARGIN_S:
                return c["access_token"]
            if c.get("locked_until", 0) > self.now():
                raise RateLimited(c["locked_until"])
            return self._request_token(c)

    def forget_token(self):
        """the token was refused (401): the next request asks for a new one"""
        with paths.shared_lock(f"api_token_{self.role}"):
            c = _read_json(self._token_file(), {})
            c.pop("access_token", None)
            _write_private(self._token_file(), c)

    def _request_token(self, cache, retried=False):
        basic = base64.b64encode(f"{self.client_id}:{self._secret}".encode()).decode()
        req = urllib.request.Request(f"{API_URL}/v1/auth/token", data=b"", method="POST",
                                     headers={"Authorization": f"Basic {basic}", "Content-Type": "application/json",
                                              "Accept": "application/json"})
        status, headers, body = self._send(req, TOKEN_ANSWER_S)
        self.requests.append(("POST", "/v1/auth/token", status))
        if status == 429:
            wait = _retry_after(headers, 3600)
            cache = {**cache, "locked_until": self.now() + wait, "client_id": self.client_id}
            _write_private(self._token_file(), cache)
            if retried or wait > self.max_wait_s:
                raise RateLimited(cache["locked_until"])
            self.sleep(wait + 1)                      # once, as Qargo asks; never a loop on this endpoint
            return self._request_token(cache, retried=True)
        if status != 200:
            raise ApiError(status, "" if status == 401 else body, "token")     # 401's body could echo the client
        try:
            d = json.loads(body)
            token, expires_in = d["access_token"], int(d.get("expires_in") or 3300)
        except (ValueError, KeyError, TypeError):
            raise ApiError(status, "", "token: no access_token in the answer")
        _write_private(self._token_file(), {"access_token": token, "expires_at": self.now() + expires_in,
                                            "client_id": self.client_id, "got": datetime.datetime.now().isoformat(timespec="seconds")})
        return token

    # ---------------------------------------------------------------- requests
    def _send(self, req, answer_s):
        """(status, headers, body text); NoAnswer when the line gives nothing in answer_s"""
        try:
            with urllib.request.urlopen(req, timeout=answer_s) as r:
                return r.status, r.headers, r.read().decode("utf-8", "replace")
        except urllib.error.HTTPError as e:
            return e.code, e.headers, e.read().decode("utf-8", "replace")
        except (urllib.error.URLError, TimeoutError, OSError) as e:
            reason = getattr(e, "reason", e)
            raise NoAnswer(f"no answer from the Qargo API within {answer_s} s (internet?): {type(reason).__name__}: {reason}")

    def request(self, method, path, *, body=None, params=None, expect=(200, 201), retried=False):
        """one call with the client's token; the JSON answer. 401 once: a new token and the call again.
        429 with a short Retry-After: waits once. Anything else that is not in `expect` raises ApiError."""
        url = f"{API_URL}{path}" + (f"?{urllib.parse.urlencode(params)}" if params else "")
        data = json.dumps(body).encode() if body is not None else None
        req = urllib.request.Request(url, data=data, method=method,
                                     headers={"Authorization": f"Bearer {self.token()}", "Accept": "application/json",
                                              **({"Content-Type": "application/json"} if data is not None else {})})
        status, headers, text = self._send(req, self.answer_s)
        self.requests.append((method, path, status))
        if status == 401 and not retried:
            self.forget_token()
            return self.request(method, path, body=body, params=params, expect=expect, retried=True)
        if status == 429:
            wait = _retry_after(headers, RETRY_429_S + 1)
            if retried or wait > RETRY_429_S:
                raise RateLimited(self.now() + wait, f"{method} {path}")
            self.sleep(wait + 1)
            return self.request(method, path, body=body, params=params, expect=expect, retried=True)
        if status not in expect:
            raise ApiError(status, text, f"{method} {path}")
        try:
            return json.loads(text) if text.strip() else {}
        except ValueError:
            raise ApiError(status, text, f"{method} {path}: not JSON")

    def pages(self, path, params=None):
        """every item of a cursor-paged list (100 per page): the cursor goes alone, as the API demands"""
        items, cursor = [], None
        for _ in range(10000):
            d = self.request("GET", path, params={"cursor": cursor} if cursor else params)
            items += d.get("items") or []
            cursor = d.get("next_cursor")
            if not cursor:
                return items
        raise ApiError(200, "", f"GET {path}: the list never ends (next_cursor keeps coming)")

    # ---------------------------------------------------------------- master data (the master_data client)
    def locations(self, *, refresh=False, max_age_s=CACHE_AGE_S):
        """every location record, from qargo_locations.json when that is younger than a day; else paged from the
        API and written there. No answer from the API raises NoAnswer: a stale list is never used in its place
        (a record made since could get a second one)"""
        f = paths.locations_cache_file()
        cache = _read_json(f, {})
        age = self.now() - cache.get("fetched_at", 0)
        if cache.get("items") is not None and not refresh and age < max_age_s:
            return cache["items"]
        items = self.pages("/v1/locations/location")
        with paths.shared_lock("locations_cache"):
            f.write_text(json.dumps({"fetched_at": self.now(), "fetched": datetime.datetime.now().isoformat(timespec="seconds"),
                                     "items": items}, ensure_ascii=False), encoding="utf-8")
        return items

    def location(self, location_id):
        return self.request("GET", f"/v1/locations/location/{location_id}")

    def create_location(self, name, address, postal_code, city, country):
        """a new record; Qargo geocodes it (201). Qargo does not check for an existing record: the caller's rules
        (qargo_fill.can_create, no doubt left) decide. The record goes into the local cache as well"""
        body = {"name": name, "address": address, "postal_code": postal_code, "city": city, "country": country}
        rec = self.request("POST", "/v1/locations/location", body=body, expect=(201,))
        f = paths.locations_cache_file()
        with paths.shared_lock("locations_cache"):
            cache = _read_json(f, {})
            if cache.get("items") is not None:
                cache["items"].append(rec)
                f.write_text(json.dumps(cache, ensure_ascii=False), encoding="utf-8")
        return rec

    def transport_services(self):
        return self.pages("/v1/transport-services/transport-service")

    def companies(self):
        return self.pages("/v1/companies/company")

    def resources(self, resource_type=None):
        return self.pages("/v1/resources/resource", {"resource_type": resource_type} if resource_type else None)

    # ---------------------------------------------------------------- orders (the order client)
    def upload(self, payload):
        """POST /v1/orders/order/upload: {upload_id, upload_status, upload_url, order_id?, order_url?}"""
        return self.request("POST", "/v1/orders/order/upload", body=payload)

    def upload_status(self, upload_id):
        return self.request("GET", f"/v1/orders/order/upload/{upload_id}")

    def order(self, order_id):
        return self.request("GET", f"/v1/orders/order/{order_id}")

    def order_status(self, order_id):
        return self.request("GET", f"/v1/orders/order/{order_id}/status")


def _retry_after(headers, default):
    try:
        return max(1, int(float(headers.get("Retry-After") or default)))
    except (TypeError, ValueError):
        return default


def order_url(order_id, tenant="Sx0061x-express"):
    """the web app's page of an order, as done.json stores it"""
    base = (os.environ.get("QARGO_TENANT_URL") or f"https://app.qargo.com/{tenant}").rstrip("/")
    return f"{base}/orders/{order_id}"
