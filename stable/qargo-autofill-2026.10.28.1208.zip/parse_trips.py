#!/usr/bin/env python3
"""Turn customer trip PDFs (Sx0013x, Sx0014x, Sx0016x route sheets, Sx0019x, Sx0010x and Sx0002x, Sx0017x rit PDFs
container orders, Sx0066x Carrier Instructions) into orders.json for the Qargo autofill script. Sx0020x's Transport_order PDFs (a truck for a
day) are recognised and listed, and make no order (MAPPING.md).

Usage:  python3 parse_trips.py <pdf or folder> [...] -o orders.json
Needs the pip package pdfminer.six (pdf_layout.py reads the PDFs with it), or else `pdftotext` (poppler;
on macOS: brew install poppler).
"""
import json, re, shutil, subprocess, sys, argparse
import Sx0027x_mail
import Sx0057x_mail
from datetime import datetime, timedelta
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent))
from validate_orders import validate, report

# ---------------------------------------------------------------- helpers
class PdfToolMissing(RuntimeError):
    """no PDF can be read on this machine: neither pdfminer.six nor poppler's pdftotext is there"""

def pdftext(path, max_pages=None):
    """the text of the PDF exactly as `pdftotext -layout <pdf> -` prints it (every page ends with a form feed),
    less the text the PDF clips away (not printed: Sx0003x's 'Voorgaand ADR'), which pdftotext keeps.
    Made by pdf_layout.py (pdfminer.six + a port of poppler's layout rules): the same on Windows and macOS,
    no poppler needed. Only a Python without pdfminer.six still runs poppler's pdftotext itself (hidden text and all).
    max_pages=1 reads only the first page (enough for detect())."""
    try:
        import pdfminer.pdfinterp        # brings in every pdfminer module pdf_layout.py uses
    except ImportError as e:
        exe = shutil.which("pdftotext")
        if not exe:
            raise PdfToolMissing(f"no PDF reader: pdfminer.six cannot be imported ({e}) and pdftotext (poppler) "
                                 f"is not on the PATH") from None
        # UTF-8 and \n whatever the system's settings are (Windows: ANSI code page, CRLF); bytes, so nothing is translated
        cmd = [exe, "-layout", "-enc", "UTF-8", "-eol", "unix"] + (["-l", str(max_pages)] if max_pages else [])
        return subprocess.run(cmd + [str(path), "-"], capture_output=True, check=True).stdout.decode("utf-8")
    from pdf_layout import pdf_layout_text
    return pdf_layout_text(path, max_pages)

def segs(line):
    """split a layout line into (start_col, text) segments separated by 2+ spaces"""
    return [(m.start(), m.group().strip()) for m in re.finditer(r"\S+(?: \S+)*", line)]

PC_RE = re.compile(r"^(\d{4})\s?([A-Z]{2})\b\s*(.*)$")          # NL postcode
BE_PC_RE = re.compile(r"^(\d{4})\s+([A-Z][\w' -]+)$")           # BE postcode + city

def norm_pc(pc):
    return re.sub(r"\s+", "", pc or "").upper()

def dmy(d):
    """'10/9/2026' (M/D/YYYY, Sx0013x) handled by caller; this takes D-M-YYYY or D/M/YYYY"""
    d_, m_, y_ = re.split(r"[-/]", d)
    return f"{int(d_):02d}/{int(m_):02d}/{y_}"

def mdy(d):
    m_, d_, y_ = d.split("/")
    return f"{int(d_):02d}/{int(m_):02d}/{y_}"

def loc(name, street, postcode=None, city=None, country="NL", query=None):
    street = (street or "").replace("<<NoData>>", "").strip()
    name = (name or "").strip()
    # Sx0054x stores: "Sx0054x 2266" (Sx0014x) or just "4149" / "3002 De Koel" (Sx0013x).
    # In Qargo they are stored as "Sx0053x Winkel <nr>" (+ "Sx0053x Winkel <nr> unloading adress").
    m = re.match(r"^(?:Sx0054x\s+)?(\d{4})(?:\s|$)", name)
    store = m.group(1) if m else None
    if not query:
        mq = re.match(r"^(.*?\d+)", street)          # "Doornepol 11 -13" -> "Doornepol 11"
        query = mq.group(1) if mq else (street or name)
    d = {
        "name": name,
        "street": street,
        "postcode": norm_pc(postcode),
        "city": (city or "").strip(),
        "country": country,
        "query": query.strip(),
    }
    if store:
        d["store"] = store
        d["query"] = f"Winkel {store}"
    return d

def with_unread(order, unread):
    """the order, with the printed stops / shipments the parser knows are NOT in it: the validator makes each an
    error, so such an order is never filled (a warning is not enough: nobody reads those)"""
    if unread:
        order["unread"] = list(dict.fromkeys(unread))
    return order

def nl_join(*xs):
    """the non-empty texts, one per line (None when there are none)"""
    return "\n".join(x for x in xs if x) or None

def stop(location, date, start=None, end=None, duration=None, note=None, reference=None):
    s = {"location": location, "date": date}
    if start: s["start"] = start
    if end: s["end"] = end
    if duration: s["duration"] = duration
    if note: s["note"] = note
    if reference: s["reference"] = reference
    return s

# ------------------------------------------------------------- Sx0013x
KEEP_UNCOUPLE = True    # Afkoppelen = end stop (decided 9 Oct); --uncouple-as-note puts it in Instructions instead
CT_KEYS = ["Aankoppelen", "Afkoppelen", "Laden", "Lossen", "Sx0053x Stop", "Rust", "Wachten"]
CT_HEAD = re.compile(r"^\s*(" + "|".join(CT_KEYS) + r")\s+(\d{1,2}/\d{1,2}/\d{4})\s*(.*)$")
CT_PAGE = re.compile(r"^\d{1,2}/\d{1,2}/\d{4} \d{1,2}:\d{2}:\d{2} [AP]M\s+\d+\s*$")
TIME_RE = re.compile(r"^\d{2}:\d{2}$")
CT_GOODS = re.compile(r"\s*(\d+(?:\.\d+)?)\s+(.+?)\s{2,}[\d.]+\s+ldm")
CT_ROUTE_REF = re.compile(r"\b[A-Z]{2,6}\|\d{4}\|[\d-]+\b")    # "DCT|2026|41-6-620", "NOTE|2026|41-5-595724" (Referentie)

def ct_remarks(body):
    """Remark lines after the 'Opmerkingen' line, verbatim (route directions, 'VOORKANT', 'Niet op navigatie!').
    The page's 'Referentie DCT|2026|...' line can be printed over a remark line; pdftotext then gives
    'Referentie Verkeerslichten' + 'DCT|2026|41-6-620  links,' -> rebuilt as 'Verkeerslichten links,'.
    Returns (text or None, problem or None)."""
    i = next((k for k, x in enumerate(body) if x.strip().startswith("Opmerkingen")), None)
    if i is None:
        return None, None
    out, start, problem = [], None, None
    for x in body[i + 1:]:
        s = x.strip()
        if not s or CT_GOODS.match(x):
            continue
        if s.startswith("Referentie"):
            rest = s[len("Referentie"):].strip()
            if rest and not CT_ROUTE_REF.fullmatch(rest):
                start = rest                     # the start of a remark line that is printed over
            continue
        if CT_ROUTE_REF.search(s):
            s = re.sub(r"\s+", " ", CT_ROUTE_REF.sub("", s)).strip()
            if start is None:
                problem = f"a remark line is printed over by the route number: {x.strip()!r}"
            if not s:
                continue                         # the rest of the line follows on the next line
        if start is not None:
            s, start = f"{start} {s}", None
        out.append(s)
    if start is not None:
        out.append(start)
    return "\n".join(out) or None, problem

def parse_Sx0073x(text, src):
    lines = [l for l in text.splitlines() if not CT_PAGE.match(l.strip())]
    rit = re.search(r"Ritnr\s+(\d+)", text).group(1)
    ma = re.search(r"Auto\s+T?(\S+)", text)
    charter = ma.group(1) if ma else None
    # an empty 'Klant Route nr' is followed on the same line by the 'Klant kilometers' label
    mr = re.search(r"Klant Route nr[ \t]+(?!Klant\b)(\S+)", text)
    route = mr.group(1) if mr else ""
    blocks, cur = [], None
    for l in lines:
        m = CT_HEAD.match(l)
        if m:
            cur = {"kind": m.group(1), "date": mdy(m.group(2)), "rest": m.group(3), "lines": []}
            blocks.append(cur)
        elif cur is not None:
            cur["lines"].append(l)
    loads, unloads, events, setup, teardown, header_note = {}, [], [], None, None, None
    load_recs, review, unread = [], [], []      # every Laden in document order (two with the same dossier would overwrite in `loads`)
    # a Laden / Lossen with its date that is printed anywhere but did not start a block of its own
    printed = len(re.findall(r"\b(?:Laden|Lossen)\b\s*\d{1,2}/\d{1,2}/\d{4}", "\n".join(lines)))
    read = sum(b["kind"] in ("Laden", "Lossen") for b in blocks)
    if printed != read:
        unread.append(f"the document prints {printed} Laden / Lossen, {read} were read - a stop was not read")
    if not route:
        review.append("'Klant Route nr' is empty on the document: customer reference left empty")
    if not any(b["kind"] in ("Laden", "Lossen") for b in blocks):
        review.append("the document prints no Laden or Lossen (only: "
                      + ", ".join(f"{b['kind']} {b['rest'].strip()}".strip() for b in blocks)
                      + "): there is nothing to make a consignment from, so this rit cannot be filled")
    for b in blocks:
        body = [x for x in b["lines"] if x.strip()]
        notes = [x.strip()[len("Opmerkingen"):].strip() for x in body if x.strip().startswith("Opmerkingen")]
        # address, time and dossier columns end at the goods line (or the remarks): remarks can run on
        # for many lines (route directions) and must not be read as address lines
        end = next((i for i, x in enumerate(body) if CT_GOODS.match(x)
                    or x.strip().startswith(("Opmerkingen", "Referentie"))), len(body))
        body_wo = body[:end] + [x for x in body[end:] if CT_GOODS.match(x)]
        time = None
        for x in body_wo:
            for _, t in segs(x):
                t2 = t.replace("•> Dock:", "").strip()
                mm = re.search(r"(\d{2}:\d{2})$", t2)
                if mm and (TIME_RE.match(t) or t.startswith("•>")):
                    time = time or mm.group(1)
        dock = None
        for x in body_wo:
            md = re.search(r"Dock:\s*(\S+)", x)
            if md: dock = md.group(1)
        remarks, problem = ct_remarks(body)
        if problem:
            review.append(f"{b['kind']} {b['date'][:5]} {time}: {problem}; check the PDF")
        if b["kind"] in ("Aankoppelen", "Afkoppelen"):
            # "DCT Pegasusweg 1 Tilburg" -> no postcode on the document
            place = b["rest"].strip()
            st = stop({"raw": place}, b["date"], time, time, note=nl_join(f"Dock: {dock}" if dock else None, remarks))
            if b["kind"] == "Aankoppelen":
                setup = st
                if notes and notes[0] and notes[0] != route.replace("|2026|", "|2026|"):
                    header_note = notes[0]
            elif KEEP_UNCOUPLE:
                teardown = st
            else:
                # Afkoppelen is often followed right away by the next rit's Aankoppelen at the same
                # place (overlapping times in Qargo) - keep it as a note, not as a stop
                events.append(nl_join(f"Afkoppelen {b['date'][:5]} {time} {place}", remarks))
            continue
        if b["kind"] in ("Sx0053x Stop", "Rust", "Wachten"):
            extra = f" ({notes[0]})" if notes and notes[0] else ""
            events.append(nl_join(f"{b['kind']} {b['date'][:5]} {time}{extra}", remarks))
            continue
        # Laden / Lossen: name on head line (before 'Klant'), address column = first segment per line
        name = re.split(r"\s{2,}Klant\b", b["rest"])[0].strip()
        addr, dossier, goods = [], None, None
        for x in body_wo:
            sg = segs(x)
            for _, t in sg:
                md = re.match(r"Dossier\s+(\S+)", t)
                if md: dossier = md.group(1)
            mg = CT_GOODS.match(x)
            if mg:
                goods = {"quantity": int(float(mg.group(1))), "description": mg.group(2).strip()}
                continue
            first = [t for _, t in sg if not TIME_RE.match(t) and not t.startswith("•>")
                     and not t.startswith("Dossier") and not t.startswith("Klant")
                     and not t.startswith("Laadplaats") and not t.startswith("Referentie")]
            if first and sg and sg[0][0] < 60:
                addr.append(first[0])
        # addr: [name-continuation..., street, postcode city, country]
        country = "NL"
        if addr and addr[-1] in ("Nederland", "België", "Belgie", "Duitsland"):
            country = {"Nederland": "NL", "België": "BE", "Belgie": "BE", "Duitsland": "DE"}[addr.pop()]
        pc = city = None
        if addr:
            m1 = PC_RE.match(addr[-1]) or BE_PC_RE.match(addr[-1])
            if m1:
                pc_line = addr.pop()
                if PC_RE.match(pc_line):
                    mm = PC_RE.match(pc_line); pc, city = mm.group(1) + mm.group(2), mm.group(3)
                else:
                    mm = BE_PC_RE.match(pc_line); pc, city = mm.group(1), mm.group(2)
        street = addr.pop() if addr else ""
        street = street.replace("Losadres:", "").strip()
        if addr: name = (name + " " + " ".join(addr)).strip()
        n = {"duration": None, "dock": dock, "text": [], "remarks": remarks}
        for nt in notes:
            md = re.search(r"(Lostijd|Laadtijd)\s+(\d{2}:\d{2})#?", nt)
            if md: n["duration"] = md.group(2); nt = nt.replace(md.group(0), "")
            nt = re.sub(r"Dock\s+\S+#", "", nt)
            parts = [p.strip(" #") for p in nt.split("|") if p.strip(" #")]
            n["text"] += parts
        if remarks:
            n["remarks"] = nl_join(" | ".join(n["text"]), remarks)
        rec = {"kind": b["kind"], "date": b["date"], "time": time, "dossier": dossier, "seq": len(load_recs) + len(unloads),
               "loc": loc(name, street, pc, city, country), "goods": goods, "notes": n}
        if b["kind"] == "Laden":
            loads[dossier] = rec
            load_recs.append(rec)
        else:
            unloads.append(rec)
    # registry to resolve coupling places (no postcode printed)
    consignments = []
    for u in unloads:
        l = loads.get(u["dossier"])
        if not l:
            raise ValueError(f"{src}: unload dossier {u['dossier']} has no load")
        instr = list(dict.fromkeys(l["notes"]["text"] + u["notes"]["text"]))
        consignments.append({
            "reference": u["dossier"],
            "instructions": "\n".join(instr) or None,
            "pickup": stop(l["loc"], l["date"], l["time"], l["time"], l["notes"]["duration"],
                           note=nl_join(f"Dock: {l['notes']['dock']}" if l["notes"]["dock"] else None, l["notes"]["remarks"])),
            "delivery": stop(u["loc"], u["date"], u["time"], u["time"], u["notes"]["duration"],
                             note=u["notes"]["remarks"]),
            "goods": [l["goods"] or u["goods"] or {"quantity": 1}],
        })
    # a Laden no Lossen uses still gets its own collection stop (nothing printed may disappear),
    # paired with the first unload after it
    used = {id(loads[u["dossier"]]) for u in unloads if u["dossier"] in loads}
    for l in load_recs:
        if id(l) in used: continue
        u = next((u for u in unloads if u["seq"] > l["seq"]), None)
        if u is None:
            events.append(f"Laden {l['date'][:5]} {l['time']} {l['loc']['name']} {l['loc']['street']} (dossier {l['dossier']})")
            unread.append(f"load {l['loc']['name']} {l['time']} (dossier {l['dossier']}) comes after the last unload: "
                          f"NOT a stop in the order")
            continue
        review.append(f"load {l['loc']['name']} {l['time']} (dossier {l['dossier']}) has no unload of its own; "
                      f"paired with the first unload after it ({u['loc']['name']} {u['time']}, dossier {u['dossier']})")
        consignments.append({
            "reference": l["dossier"], "instructions": "\n".join(l["notes"]["text"]) or None,
            "pickup": stop(l["loc"], l["date"], l["time"], l["time"], l["notes"]["duration"],
                           note=nl_join(f"Dock: {l['notes']['dock']}" if l["notes"]["dock"] else None, l["notes"]["remarks"])),
            "delivery": stop(u["loc"], u["date"], u["time"], u["time"], u["notes"]["duration"],
                             note=u["notes"]["remarks"]),
            "goods": [l["goods"] or {"quantity": 1}],
        })
    # In the order the stops are driven: by unload time, then load time. The loads are printed (and loaded) last
    # drop first, so load order would put the deliveries in Qargo the wrong way round (CT-3994523: unloads
    # 17:59, 16:30, 15:08). Same times: the document's load order.
    order_idx = {d: i for i, d in enumerate(loads)}
    when = lambda s: datetime.strptime(f"{s['date']} {s.get('start') or s.get('end') or '00:00'}", "%d/%m/%Y %H:%M")
    consignments.sort(key=lambda c: (when(c["delivery"]), when(c["pickup"]), order_idx.get(c["reference"], 99)))
    instr = ([charter] if charter else []) + ([header_note] if header_note else []) + events
    # every Dossier number printed anywhere is a shipment and must be a consignment
    have = {c["reference"] for c in consignments}
    for d in dict.fromkeys(re.findall(r"\bDossier\s+(\S+)", text)):
        if d not in have:
            unread.append(f"Dossier {d} is printed on the document but is not a consignment in the order - a "
                          f"shipment was not read")
    return with_unread({
        "customer": "Sx0013x", "customer_reference": route, "ritnummer": int(rit),
        "instructions": "\n".join(instr) or None,
        "setup": setup, "teardown": teardown, "consignments": consignments,
        "source": src, "key": f"CT-{rit}",
        **({"review": review} if review else {}),
    }, unread)

# -------------------------------------------------------------- Sx0014x
# "10-10-2026 13:10-13:27 Hoofdtocht 1"; in a narrow column the end time is on the next line ("12-10-2026 09:15-")
SL_WHEN = re.compile(r"(\d{1,2}-\d{1,2}-\d{4})\s+(\d{2}:\d{2})\s?-\s?(\d{2}:\d{2})?\s+(.*)")
def sl_header(part, label):
    """the value of a header field ("Ritomschrijving:   DCT koppel 3314 - ... -" / "   België"): a long value
    wraps onto indented lines under it, up to the next label or blank line. "-" alone is an empty field"""
    m = re.search(rf"^[ \t]*{label}:[ \t]*(.*(?:\n[ \t]{{2,}}\S.*)*)", part, re.M)
    value = " ".join(m.group(1).split()) if m else ""
    return "" if value == "-" else value

def parse_Sx0047x(text, src):
    out = []
    for part in text.split("TRANSPORTOPDRACHT")[1:]:
        if "REFERENTIENUMMER" not in part:
            if re.search(r"^\s*(?:LADEN|LOSSEN)\b", part, re.M):
                raise ValueError(f"{src}: a TRANSPORTOPDRACHT with LADEN / LOSSEN but no REFERENTIENUMMER")
            continue
        ref = re.search(r"REFERENTIENUMMER:\s*(\d+)", part).group(1)
        desc = sl_header(part, "Ritomschrijving").rstrip(" -")
        remark = sl_header(part, "Opmerking")
        # every Ordernummer and every "Ritnr. 183" in the stop remarks, in printed order: a "koppel" rit
        # ("DCZ koppel 2311 - route 183/231") is two trips under one REFERENTIENUMMER
        ordnrs = list(dict.fromkeys(re.findall(r"Ordernummer:\s*(\d+)", part)))
        md = re.search(r"Ritnr\.?\s+(\d+)", desc)
        ritnrs = [md.group(1)] if md else list(dict.fromkeys(re.findall(r"Ritnr\.?\s+(\d+)", part)))
        mt = re.search(r"Getrokken eenheid:\s*\S*?/(\S+)", part)
        charter = mt.group(1) if mt else None
        body = part.split("OVEREENGEKOMEN PRIJS")[0]
        lines = [l for l in body.splitlines()
                 if l.strip() and not re.match(r"^\s*Pagina \d+ van \d+", l) and not l.strip().startswith("---")
                 and "Aantal palletplaatsen" not in l]
        stops, cur = [], None
        for l in lines:
            # "LADEN   DCZ   Referentie:". On a Sx0043x rit the Referentie has a value ("RDC-12-825042-202610121130|1"),
            # and a long name or value runs on in its own column on the next line
            m = re.match(r"^(LADEN|LOSSEN)\s+(.*?)\s*Referentie:\s*(.*?)\s*$", l)
            if m:
                cur = {"kind": m.group(1), "name": m.group(2).strip(), "ref": m.group(3),
                       "refcol": l.index("Referentie:"), "lines": []}
                stops.append(cur); continue
            if cur is None:
                continue
            if not cur["lines"] and not SL_WHEN.match(l.strip()):      # the heading runs on, above the date line
                for col, t in segs(l):
                    if col >= cur["refcol"] - 3: cur["ref"] += t
                    else: cur["name"] = f"{cur['name']} {t}".strip()
                continue
            cur["lines"].append(l.strip())
        parsed = []
        for s in stops:
            L = s["lines"]
            if not L:
                raise ValueError(f"{src} {ref}: no date and time window under {s['kind']} {s['name']}")
            m = SL_WHEN.match(L[0])
            date, t1, t2, street = dmy(m.group(1)), m.group(2), m.group(3), m.group(4)
            iop = L.index("Opmerkingen:") if "Opmerkingen:" in L else len(L)
            A = L[1:iop]                                 # the address lines; a wrapped end time ("09:15-" / "09:45")
            if t2 is None:
                t2 = next((x for x in A if TIME_RE.match(x)), None)
                if t2 is None:
                    raise ValueError(f"{src} {ref}: no end of the time window after {L[:4]}")
                A.remove(t2)
            # "5342 LP OSS", or postcode and town on two lines ("5642RK" / "EINDHOVEN")
            i = next((k for k, x in enumerate(A[:4]) if PC_RE.match(x) or BE_PC_RE.match(x) or re.fullmatch(r"\d{4}", x)), None)
            if i is None:
                raise ValueError(f"{src} {ref}: no postcode line after {L[:4]}")
            under = A[i + 1] if i + 1 < len(A) else ""
            country, mp = "NL", PC_RE.match(A[i])
            if mp:
                pc, city = mp.group(1) + mp.group(2), (mp.group(3) or under).title()
            else:
                mb = BE_PC_RE.match(A[i])
                pc, city, country = (mb.group(1), mb.group(2).title(), "BE") if mb else (A[i], under.title(), "BE")
            street = " ".join([street] + A[:i]).strip()
            notes = []
            for x in L[iop + 1:]:                        # up to the stop's own "Ordernummer: 12615144"
                if re.fullmatch(r"Ordernummer:\s*\d+", x):
                    break
                notes.append(x)
            parsed.append({"kind": s["kind"], "loc": loc(s["name"], street, pc, city, country),
                           "date": date, "start": t1, "end": t2, "note": " ".join(notes) or None,
                           "ref": s["ref"] or None})
        load, load_used = None, False
        consignments, review, pending, unread = [], [], [], []
        # a LADEN / LOSSEN line or a time window ("9-10-2026 13:10-13:27") that did not become a stop
        printed = max(sum(bool(re.match(r"\s*(?:LADEN|LOSSEN)\b", l)) for l in lines),
                      sum(bool(re.match(r"\s*\d{1,2}-\d{1,2}-\d{4}\s+\d{2}:\d{2}\s?-", l)) for l in lines))
        if printed != len(parsed):
            unread.append(f"the document prints {printed} LADEN / LOSSEN, {len(parsed)} were read - a stop was not read")
        # several trip numbers (a koppel rit, "route 558/220/271"): Qargo's one Ritnummer cannot hold them, and
        # nobody can pick the right one either, so the field stays empty without a note. The numbers stay
        # in the instructions (the Ritomschrijving) and in each pickup's note.
        if not ritnrs:
            review.append(f"no 'Ritnr' anywhere in the PDF (Ritomschrijving {desc!r}): ritnummer left empty - "
                          f"fill it in by hand")
        teardown = None
        sl_stop = lambda x: stop(x["loc"], x["date"], x["start"], x["end"], note=x["note"], reference=x["ref"])
        for p in parsed:
            if p["kind"] == "LADEN":
                # LADEN right after LADEN (e.g. DCZ dock 429, DCZ dock 134, then DCM): the earlier one has no
                # LOSSEN of its own. It still gets its own collection stop (nothing printed may disappear),
                # paired with the first delivery after it.
                if load is not None and not load_used:
                    pending.append(load)
                load, load_used = p, False
                continue
            for u in pending:
                consignments.append({"reference": None, "instructions": None, "pickup": sl_stop(u),
                                     "delivery": sl_stop(p), "goods": [{"quantity": 1}]})
                review.append(f"load {u['loc']['name']} {u['start']}-{u['end']} ({u['note'] or 'no dock'}) has no "
                              f"unload of its own in the PDF; paired with the first delivery after it "
                              f"({p['loc']['name']} {p['start']})")
            pending = []
            consignments.append({
                "reference": None, "instructions": None,
                "pickup": sl_stop(load), "delivery": sl_stop(p),
                "goods": [{"quantity": 1}],
            })
            load_used = True
        extra = []
        for u in pending + ([load] if load is not None and not load_used else []):
            # a load after the last delivery: no printed stop to pair it with - say so loudly
            extra.append(f"Ook laden: {u['loc']['name']} {u['loc']['street']} {u['date'][:5]} {u['start']}-{u['end']}"
                         + (f" {u['note']}" if u["note"] else ""))
            unread.append(f"load {u['loc']['name']} {u['start']}-{u['end']} comes after the last delivery: "
                          f"NOT a stop in the order")
        out.append(with_unread({
            "customer": "Sx0014x", "customer_reference": ref,
            "ritnummer": int(ritnrs[0]) if len(ritnrs) == 1 else None,
            "instructions": "\n".join(([charter] if charter else []) + [desc]
                                      + ([f"Opmerking: {remark}"] if remark else [])
                                      + ([f"Ordernummer: {', '.join(ordnrs)}"] if ordnrs else []) + extra),
            "setup": None, "teardown": teardown, "consignments": consignments,
            "source": src, "key": f"SL-{ref}",
            **({"review": review} if review else {}),
        }, unread))
    return out

# ------------------------------------------------------------------ Sx0016x
PN_ACTIONS = ["Startactie's", "Eindactie's", "Start", "Einde", "Pauze", "Laden", "Lossen", "Wachten"]
PN_HEAD = re.compile(r"^\s?(" + "|".join(re.escape(a) for a in PN_ACTIONS) + r")(\s{2,}|$)")
PN_SKIP = re.compile(r"^\s*(Routenaam|Route-inhoud|Back-up middel|Kilometers|Pauze \(min\)|Startlocatie|Actie\s+Adres|starttijd|Pagina \d|Bij calamiteiten|nemen met|E-mail|CRTS|Telefoon)")
TD = re.compile(r"(\d{2}:\d{2}) (\d{2}-\d{2}-\d{4})")
PN_HEADER_TIME = re.compile(r"\b(Starttijd|Eindtijd)\s+(\d{2}:\d{2})\b")      # the route header; the rows print "starttijd"

def pn_when(date, time):
    """'12/10/2026', '07:05' -> datetime"""
    return datetime.strptime(f"{date} {time}", "%d/%m/%Y %H:%M")

def pn_header_when(hhmm, near):
    """The header's Starttijd / Eindtijd prints no date: it is the date of the nearest row (the Start / Einde row),
    or the day before / after when that would put it more than 12 hours away (a route that ends round midnight)"""
    w = datetime.combine(near.date(), datetime.strptime(hhmm, "%H:%M").time())
    if w - near > timedelta(hours=12): w -= timedelta(days=1)
    elif near - w > timedelta(hours=12): w += timedelta(days=1)
    return w

def pn_outer(recs, header):
    """The outer times of a route: the earliest and the latest moment printed on the sheet, over every row with a
    time and the header's Starttijd / Eindtijd. The real sheets print the Eindtijd one minute after the Einde row
    (Einde 19:15, Eindtijd 19:16): the day ends at 19:16. Returns (first, last) datetimes, or (None, None)"""
    whens = [pn_when(rc[d], rc[t]) for rc in recs for d, t in (("sdate", "start"), ("edate", "end")) if rc[t] and rc[d]]
    if not whens: return None, None
    first, last = min(whens), max(whens)
    if header.get("Starttijd"): first = min(first, pn_header_when(header["Starttijd"], first))
    if header.get("Eindtijd"): last = max(last, pn_header_when(header["Eindtijd"], last))
    return first, last

def pn_day_stop(rc, when, activity):
    """the Start / Einde row as a stop at `when` (a datetime: the outer time of the route); no time when the sheet has none"""
    st = stop(rc["loc"], when.strftime("%d/%m/%Y"), when.strftime("%H:%M"), when.strftime("%H:%M")) if when else stop(rc["loc"], rc["sdate"])
    st["activity"] = activity
    return st

def parse_Sx0026x(text, src):
    out = []
    # each route = pages sharing the same Dienstnummer
    routes = {}
    for page in text.split("\f"):
        m = re.search(r"Dienstnummer\s+(\S+)", page)
        if not m:
            if re.search(r"^\s*(?:Laden|Lossen)\b.*\d{2}:\d{2} \d{2}-\d{2}-\d{4}", page, re.M):
                raise ValueError(f"{src}: a page with Laden / Lossen but no Dienstnummer")
            continue
        r = routes.setdefault(m.group(1), {"name": re.search(r"Routenaam\s+(\S+)", page).group(1), "pages": [], "header": {}})
        r["pages"].append(page)
        for k, v in PN_HEADER_TIME.findall(page): r["header"].setdefault(k, v)
    for dienst, r in routes.items():
        cols = None; rows = []; cur = None; printed = 0
        for page in r["pages"]:
            for l in page.splitlines():
                printed += bool(re.match(r"\s*(?:Laden|Lossen)\b.*\d{2}:\d{2} \d{2}-\d{2}-\d{4}", l))
                if re.match(r"^\s*Actie\s+Adres", l):
                    cols = {"mid": l.index("Geplande"), "goods": l.index("Ladingdragers")}
                if not l.strip() or PN_SKIP.match(l): continue
                m = PN_HEAD.match(l)
                if m:
                    cur = {"action": m.group(1), "first": l, "cont": []}; rows.append(cur)
                elif cur is not None:
                    cur["cont"].append(l)
        recs = []
        for row in rows:
            sg = segs(row["first"])
            name = sg[1][1] if len(sg) > 1 and not TD.match(sg[1][1]) else ""
            tds = TD.findall(row["first"])
            goods = [t for c, t in sg if c >= cols["goods"] - 3]
            addr, mid = [], []
            for l in row["cont"]:
                for c, t in segs(l):
                    if c >= cols["goods"] - 3: goods.append(t)
                    elif c >= cols["mid"] - 3: mid.append(t)
                    else: addr.append(t)
            pc = city = None; country = "NL"; street = addr[0] if addr else ""
            for i, a in enumerate(addr[1:], 1):
                mm = re.match(r"^(\d{4})\s?([A-Z]{2})\s+(.*)$", a)
                if mm: pc, city = mm.group(1) + mm.group(2), mm.group(3).title()
                mb = re.match(r"^(\d{4})\s+(.+?)\s+BE$", a)
                if mb: pc, city, country = mb.group(1), mb.group(2), "BE"
                # the street is the line above the postcode. Lines above that are the rest of a long name:
                # "FEDEX EXPRESS OPERATIONS FIC" / "VELDHOVEN" / "De Run 4255" / "5503LM VELDHOVEN" (B-009196-0026)
                if (mm or mb) and i > 1 and street == addr[0]:
                    name, street = " ".join([name] + addr[:i - 1]).strip(), addr[i - 1]
            code = mid[-1] if mid else None
            notes = [x for x in mid[:-1]] if mid else []
            # "OVP EINDHOVEN (CONTROLEER KLEP)": a hint inside the stop name (check the tail lift). The Qargo location
            # is just "OVP Eindhoven", so keep the hint as a stop note too
            if re.search(r"\([^)]+\)", name):
                notes.append(f"Printed: {name}")
            g = []
            for t in goods:
                mg = re.match(r"(\d+)\s+(.+)", t)
                if mg: g.append({"quantity": int(mg.group(1)), "description": mg.group(2)})
            recs.append({"action": row["action"], "name": name,
                         "loc": loc(name, street, pc, city, country),
                         "start": tds[0][0] if tds else None, "sdate": dmy(tds[0][1]) if tds else None,
                         "end": tds[1][0] if len(tds) > 1 else None, "edate": dmy(tds[1][1]) if len(tds) > 1 else None,
                         "code": code, "notes": notes, "goods": g, "raw_mid": mid})
        setup = teardown = None; events = []; loads = []; consignments = []; used = set(); review = []; unread = []
        read = sum(rc["action"] in ("Laden", "Lossen") for rc in recs)
        if printed != read:      # a Laden / Lossen line with its time that did not start a row of its own
            unread.append(f"the document prints {printed} Laden / Lossen, {read} were read - a stop was not read")
        pn_pair = lambda l, u: {
            "reference": u["code"], "instructions": None,
            "pickup": stop(l["loc"], l["sdate"], l["start"], l["end"],
                           note="\n".join(l["notes"]) or None, reference=l["code"]),
            "delivery": stop(u["loc"], u["sdate"], u["start"], u["end"],
                             note="\n".join(u["notes"]) or None, reference=u["code"]),
            "goods": l["goods"] or u["goods"] or [{"quantity": 1}],
        }
        # Start of day / End of day get the outer times of the route (decided 13 Oct): the Start row at the earliest
        # time on the sheet, the Einde row at the latest - the header's Eindtijd when that is later than the Einde row
        first, last = pn_outer(recs, r["header"])
        for rc in recs:
            a = rc["action"]
            if a == "Start":
                setup = pn_day_stop(rc, first, "Start of day")
            elif a == "Einde":
                teardown = pn_day_stop(rc, last, "End of day")
            elif a in ("Pauze", "Wachten"):
                if a == "Pauze":
                    events.append(f"Pauze {rc['start']}-{rc['end']} {rc['loc']['street']} {rc['loc']['city']}".strip())
                else:
                    events.append(f"Wachten: {rc['name']}")
            elif a == "Laden":
                loads.append(rc)
            elif a == "Lossen":
                match = [l for l in loads if l["code"] == rc["code"]]
                l = match[-1] if match else (loads[-1] if loads else None)
                if l is None: raise ValueError(f"{src} {dienst}: unload without load")
                if not match:
                    print(f"WARNING {dienst}: unload {rc['name']} code {rc['code']} paired with previous load {l['name']}", file=sys.stderr)
                    review.append(f"unload {rc['name']} {rc['start']} (code {rc['code']}) has no load with that code; "
                                  f"paired with the previous load {l['name']} {l['start']}")
                used.add(id(l))
                consignments.append(pn_pair(l, rc))
        # a Laden no Lossen uses still gets its own collection stop, paired with the first Lossen after it
        for i, l in enumerate(recs):
            if l["action"] != "Laden" or id(l) in used: continue
            u = next((u for u in recs[i + 1:] if u["action"] == "Lossen"), None)
            if u is None:
                events.append(f"Laden {l['start']} {l['name']} (code {l['code']})")
                unread.append(f"load {l['name']} {l['start']} (code {l['code']}) comes after the last unload: "
                              f"NOT a stop in the order")
                continue
            review.append(f"load {l['name']} {l['start']} (code {l['code']}) has no unload with that code; "
                          f"paired with the first unload after it ({u['name']} {u['start']})")
            consignments.append(pn_pair(l, u))
        # only when nothing else is carried: a real load next to the day's "Auto met chauffeur" leg is a normal order
        # (B-009196-0027: SCB / Crossdock loads plus the Depot Tilburg dagspoed leg)
        is_hired_truck = lambda good: re.search(r"auto met chauffeur", good.get("description") or "", re.I)
        all_goods = [good for consignment in consignments for good in consignment["goods"]]
        hired = sorted({good["description"] for good in all_goods if is_hired_truck(good)})
        if hired and all(is_hired_truck(good) for good in all_goods):
            review.append(f"goods are {hired[0]!r} ('dagspoed'): Sx0016x books the truck with driver for the day, "
                          f"not a load - check what this order should be")
        out.append(with_unread({
            "customer": "Sx0016x", "customer_reference": dienst, "ritnummer": None,
            "instructions": "\n".join([r["name"]] + events),
            "setup": setup, "teardown": teardown, "consignments": consignments,
            "source": src, "key": f"PN-{dienst}",
            **({"review": review} if review else {}),
        }, unread))
    return out

# --------------------------------------------------------------- Sx0019x
Sx0048x_COLS = re.compile(r"^\s*Laden\s+Lossen\s+Gewicht\s*$")
# load date, load name, unload date, unload name. The unload name can be one line lower (rit 222387, 21 Oct 2026):
# the PDF prints it next to the date, but when the unload address runs under the Gewicht column the reader
# (pdftotext -layout, and pdf_layout.py) takes it and the goods line under it as one block that starts left of
# the unload date, and then prints the name on a line of its own
Sx0048x_ROW = re.compile(r"^\s*(\d{2}-\d{2}-\d{4})\s+(\S.*?)\s+(\d{2}-\d{2}-\d{4})(?:\s+(\S.*?))?\s*$")
# the ton figure is left empty for a few kg ("       ton   Beton produkten   VO-1272826   3 kg")
Sx0048x_GOODS = re.compile(r"^\s*(?:[\d.,]+\s?)?ton\s+(.*?)\s{2,}(\S+)\s+([\d.,]+)\s?kg\s*$")
Sx0048x_TOTAL = re.compile(r"^\s*(Subtotaal|Totaal Gewicht)\s+([\d.,]+)\s?kg\s*$")
# a row's own Laadreferentie, printed under its goods lines when the rows of a rit do not share one (rit 221603,
# 15 Oct 2026); the Subtotaal can share the line: " Laadreferentie: 558079          Subtotaal   2.468 kg"
Sx0048x_LAADREF = re.compile(r"^\s*Laadreferentie:\s*(\S+)\s*(.*)$")
Sx0048x_PC = re.compile(r"^(\d{4}\s?[A-Z]{2}|\d{4,5})\s+(.+?),\s*(\S.*)$")      # "6651 KD Druten, Nederland"
# "0600u leveren", "lossen om 0600 uur", "0600 lossen": the delivery time, printed left under a row
Sx0048x_TIME = re.compile(r"^(?:(?:lossen|leveren)\s+om\s+)?(\d{2})[:.]?(\d{2})"
                      r"(?:\s?u(?:ur)?(?:\s+(?:leveren|lossen))?|\s+(?:leveren|lossen))$", re.I)
# "tussen 0800-1700u huif" (rit 222303), "1130 - 1230 lossen" (221487), "lossen tussen 1500/1600 uur" (220904):
# a delivery window, printed in the same place
Sx0048x_SPAN = r"(\d{1,2})[:.]?(\d{2})\s*(?:u(?:ur)?)?\s*(?:-|/|tot|en)\s*(\d{1,2})[:.]?(\d{2})\s*(?:u(?:ur)?\b)?"
Sx0048x_RANGE = re.compile(r"^(?:(?:lossen|leveren)\s+)?(?:(?:tussen|van)\s+)?" + Sx0048x_SPAN + r"(.*)$", re.I)
Sx0048x_NOTE_RANGE = re.compile(r"\btussen\s+" + Sx0048x_SPAN, re.I)    # "tussen 8:30 en 18:00 leveren" in a note (220931)
Sx0048x_AFTER = re.compile(r"\bna\s+(\d{1,2})[.:](\d{2})\s*(?:u(?:ur)?\s+)?leveren\b", re.I)   # "Na 09.00 leveren" in a note
# "Altijd voor 12:00 lossen" / "lossen voor 1200 uur" in a note: the end time (rit 222647, decided 22 Oct 2026).
# "bellen voor 10.00" is not one: lossen / leveren must stand next to the time
Sx0048x_BEFORE = re.compile(r"\b(?:(?:lossen|leveren)\s+voor\s+(\d{1,2})[.:]?(\d{2})\b"
                        r"|voor\s+(\d{1,2})[.:]?(\d{2})\s*(?:u(?:ur)?\s+)?(?:lossen|leveren)\b)", re.I)
Sx0048x_CLOCK = re.compile(r"\b\d{1,2}[.:]\d{2}\b|\b\d{4}\s?u(?:ur)?\b", re.I)
Sx0048x_COUNTRY = {"nederland": "NL", "belgië": "BE", "belgie": "BE", "duitsland": "DE"}
Sx0048x_ZE = re.compile(r"zero.?emissie", re.I)

def Sx0072x_window(x):
    """a line printed left under a row -> (start, end, the rest of the line) when it is a delivery time, else None.
    One time ("1330u leveren") is both start and end (decided 19 Oct 2026); a range ("tussen 0800-1700u huif")
    is start and end; the rest ("huif") is what else that line says"""
    m = Sx0048x_TIME.match(x)
    if m:
        t = f"{m.group(1)}:{m.group(2)}"
        return t, t, ""
    m = Sx0048x_RANGE.match(x)
    if m and Sx0072x_span(m):
        rest = m.group(5).strip()
        return (*Sx0072x_span(m), "" if re.fullmatch(r"(?:lossen|leveren|uur|u)?", rest, re.I) else rest)
    return None

def Sx0072x_span(m):
    """the first four groups of a Sx0048x_SPAN match -> ("08:00", "17:00"), or None when it is not a clock time"""
    h1, m1, h2, m2 = (int(m.group(i)) for i in range(1, 5))
    if h1 < 24 and h2 < 24 and m1 < 60 and m2 < 60:
        return f"{h1:02d}:{m1:02d}", f"{h2:02d}:{m2:02d}"
    return None

def Sx0072x_before(m):
    """a Sx0048x_BEFORE match -> (None, "12:00"): an end time only, or None when it is not a clock time"""
    h, mi = (int(g) for g in (m.group(1) or m.group(3), m.group(2) or m.group(4)))
    return (None, f"{h:02d}:{mi:02d}") if h < 24 and mi < 60 else None

def Sx0072x_kg(s):
    """'31.815' -> 31815, '84' -> 84, '1.234,5' -> 1234.5 (the dot is the thousands separator)"""
    kg = float(s.replace(".", "").replace(",", "."))
    return int(kg) if kg == int(kg) else kg

def Sx0072x_address(lines, src, name_below=False):
    """address lines of one side of a row (name, street, 'postcode city, country', anything printed under it)
    -> (location, extra lines). name_below: the name was not on the row line but the first line under it; then
    a street must follow, or the 'name' may be a street whose name line was lost (a wrong place)"""
    if not lines:
        raise ValueError(f"{src}: a row without an address on one side")
    i = next((k for k, x in enumerate(lines) if k and Sx0048x_PC.match(x)), None)
    if i is None:
        raise ValueError(f"{src}: no 'postcode city, country' line under {lines[0]!r}: {lines[1:]}")
    if name_below and i < 2:
        raise ValueError(f"{src}: no name next to the date of the row with {lines[0]!r}, {lines[1]!r}: "
                         f"the name of that place is not read")
    m = Sx0048x_PC.match(lines[i])
    country = Sx0048x_COUNTRY.get(m.group(3).strip().lower())
    if not country:
        raise ValueError(f"{src}: unknown country {m.group(3)!r} under {lines[0]!r}")
    return loc(lines[0], " ".join(lines[1:i]), m.group(1), m.group(2), country), lines[i + 1:]

def parse_Sx0022x(text, src):
    """'Transportopdracht' of Sx0074x: one trip per PDF. Mapping as decided on 8 Oct 2026:
    Laadreferentie -> Customer Reference, Rit nr. -> Ritnummer, Opmerking -> Instructions, one consignment per
    VO-number (also when one row lists several), the kg column -> Total weight, the notes under a row ('Tel:' text,
    'i.c.m. VO-...') -> consignment instructions, '0600u leveren' / 'lossen om 0600 uur' -> delivery start and end
    time, 'tussen 0800-1700u' / '1130 - 1230 lossen' (also in a note) -> delivery start / end time, a note
    'Na 09.00 leveren' -> delivery start time, a note 'Altijd voor 12:00 lossen' -> delivery end time."""
    if len(set(re.findall(r"Rit nr\.\s+(\d+)", text))) > 1 or len(re.findall(r"Totaal Gewicht", text)) > 1:
        raise ValueError(f"{src}: several trips in one PDF; only one per PDF is read")
    body = []
    for page in text.split("\f"):                    # per page: what is between the letterhead and the footer
        L = page.splitlines()
        a = next((i for i, x in enumerate(L) if "K.v.K.-nr." in x), None)
        if a is None:
            if page.strip():
                raise ValueError(f"{src}: a page without the Sx0019x letterhead")
            continue
        b = next((i for i, x in enumerate(L) if "GRAAG BEVESTIGING" in x), len(L))
        if body:     # a later page prints the header lines again (rit 221765): not a line of the last row
            body += [x for x in L[a + 1:b] if not re.match(r"\s*(Rit nr\.|Datum\s|Crediteur nr\.)", x)]
        else:
            body += L[a + 1:b]
    k = next((i for i, x in enumerate(body) if x.strip().startswith("Kosten Omschrijving")), len(body))
    body = [x for x in body[:k] if x.strip()]        # the cost table and the signature are not part of the order
    head = "\n".join(body)
    rits = set(re.findall(r"Rit nr\.\s+(\d+)", head))
    c0 = next((i for i, x in enumerate(body) if Sx0048x_COLS.match(x)), None)
    if c0 is None:
        raise ValueError(f"{src}: no 'Laden / Lossen / Gewicht' header")
    # the Laadreferentie is printed above the rows when the whole rit has one. When the rows carry different ones
    # (rit 221603 of 15 Oct 2026: a row moved in from another rit keeps that rit's Laadreferentie) the box above
    # the rows is empty and every row prints its own; see Sx0072x_laadreferentie
    head_refs = set(re.findall(r"Laadreferentie[ \t]+(\S(?:.*\S)?)[ \t]*$", "\n".join(body[:c0]), re.M))
    if len(rits) != 1 or len(head_refs) > 1:
        raise ValueError(f"{src}: expected one Rit nr. and at most one Laadreferentie above the rows, "
                         f"found {sorted(rits)} / {sorted(head_refs)}")
    rit = rits.pop()
    o0 = next((i for i, x in enumerate(body[:c0]) if "Opmerking:" in x), None)
    review, unread, remark = [], [], None      # unread: the PDF's own totals show a line is missing -> not filled
    for x in body[:c0 if o0 is None else o0 + 1]:    # the header fields; anything else printed there is reported
        x = x.split("Opmerking:")[0].strip()
        if x and not re.match(r"(Rit nr\.|Datum\s|Crediteur nr\.)", x):
            review.append(f"line above the rows is not in the order: {x!r}")
    if o0 is not None:                               # the trip remark, e.g. "KOOIAAP"; usually empty
        remark = nl_join(*[re.sub(r"\s+", " ", x).strip()
                           for x in [body[o0].split("Opmerking:", 1)[1]] + body[o0 + 1:c0]])
    blocks, cur, total = [], None, None
    for l in body[c0 + 1:]:
        if Sx0048x_COLS.match(l):
            continue
        m = Sx0048x_ROW.match(l)
        if m:       # no unload name on the row line: the first text right of the unload date under it is the name
            cur = {"dates": (dmy(m.group(1)), dmy(m.group(3))), "split": m.start(3),
                   "addr": ([m.group(2)], [m.group(4)] if m.group(4) else []), "name_below": not m.group(4),
                   "goods": [], "subtotal": None, "left": [], "notes": []}
            blocks.append(cur); continue
        m = Sx0048x_LAADREF.match(l)
        if m and cur is not None:
            if cur.get("laadref") not in (None, m.group(1)):
                review.append(f"{cur['addr'][0][0]} -> {cur['addr'][1][0]}: two Laadreferenties printed under this "
                              f"row ({cur['laadref']}, {m.group(1)}); the last one is used")
            cur["laadref"] = m.group(1)
            l = m.group(2)                           # what shares the line, usually the Subtotaal
            if not l.strip():
                continue
        m = Sx0048x_TOTAL.match(l)
        if m and m.group(1) == "Totaal Gewicht":
            total = Sx0072x_kg(m.group(2)); continue
        if cur is None:
            review.append(f"line above the first load is not in the order: {l.strip()!r}"); continue
        if m:
            cur["subtotal"] = Sx0072x_kg(m.group(2)); continue
        m = Sx0048x_GOODS.match(l)
        if m:
            cur["goods"].append((m.group(1).strip(), m.group(2), Sx0072x_kg(m.group(3)))); continue
        if not cur["goods"]:                         # still in the address: left of the unload date = load side
            for col, t in segs(l):
                cur["addr"][0 if col < cur["split"] else 1].append(t)
            continue
        # under the goods lines: left a delivery time ("0600u leveren"), right the notes. 'Tel:' starts a note,
        # a line without it continues the note above (a wrapped line), or is a note of its own ("i.c.m. VO-...")
        (col, first), rest = segs(l)[0], l.strip()
        if col < cur["split"] // 2:
            cur["left"].append(first)
            rest = l[col + len(first):].strip()
        rest = re.sub(r"\s+", " ", rest)
        if rest.startswith("Tel:"):
            cur["notes"].append(rest[4:].strip())
        elif rest and cur["notes"]:
            cur["notes"][-1] = f"{cur['notes'][-1]} {rest}".strip()
        elif rest:
            cur["notes"].append(rest)
    if not blocks:
        raise ValueError(f"{src}: no load / unload rows found")
    for b in blocks:            # first: the messages below name a row by its two names
        b["sides"] = [Sx0072x_address(b["addr"][0], src), Sx0072x_address(b["addr"][1], src, b["name_below"])]
    ref, laadref_lines = Sx0072x_laadreferentie(blocks, head_refs, review, src)
    consignments, zero_emission, timed = [], [], set()
    for b in blocks:
        if any(Sx0072x_window(x) for x in b["left"]):
            timed.add(json.dumps(b["sides"][1][0], sort_keys=True))
    for b in blocks:
        where = f"{b['addr'][0][0]} -> {b['addr'][1][0]}"
        sides = []
        for L, extra in b["sides"]:
            note = []
            for x in extra:                          # printed under the address, e.g. "Let op: ZERO-emissiezone!"
                if Sx0048x_ZE.search(x):
                    note.append("!!! LET OP: ZERO-EMISSIEZONE !!!")
                    line = f"!!! LET OP: ZERO-EMISSIEZONE bij {L['name']} ({L['street']}) !!!"
                    if line not in zero_emission:
                        zero_emission.append(line)
                    if re.sub(r"let op:?|zero.?emissie\s?zone|\W", "", x, flags=re.I):
                        note.append(x)               # more than the usual sentence on that line: keep it as printed
                else:
                    note.append(x)
                    review.append(f"{where}: {x!r} is printed under the address of {L['name']}; kept as that "
                                  f"stop's note")
            sides.append((L, nl_join(*note)))
        times, texts = [], []
        odd_left = []
        for x in b["left"]:
            w = Sx0072x_window(x)
            if w:
                times.append(w[:2])
                if w[2]: texts.append(x)             # "tussen 0800-1700u huif": the line stays, it says more
            else:
                texts.append(x); odd_left.append(x)
        if odd_left:
            review.append(f"{where}: {odd_left} is printed where the delivery time usually is; kept in the instructions")
        if len(set(times)) > 1:
            review.append(f"{where}: several delivery times printed {times}; the first one is used")
        # the row's notes go to every consignment of the row; a note that is part of another one is not repeated
        notes = list(dict.fromkeys(n for n in b["notes"] if n))
        notes = [n for n in notes if not any(n != other and n in other for other in notes)]
        # "Na 09.00 leveren" in a note is a delivery time like "0900u leveren" (decided 12 Oct); the note stays too
        if not times:
            times = [(f"{int(m.group(1)):02d}:{m.group(2)}", None) for n in notes for m in Sx0048x_AFTER.finditer(n)][:1]
        # "Altijd voor 12:00 lossen" in a note is the end time (decided 22 Oct 2026); the note stays too
        if not times:
            times = [Sx0072x_before(m) for n in notes for m in Sx0048x_BEFORE.finditer(n) if Sx0072x_before(m)][:1]
        # "tussen 8:30 en 18:00 leveren" in a note is the delivery window; the note stays too. Not on a return from
        # a place that has its delivery time: there the remark printed again is that place's window, not this one's
        is_return = json.dumps(sides[0][0], sort_keys=True) in timed
        if not times and not is_return:
            times = [Sx0072x_span(m) for n in notes if not re.search(r"\b(laden|ophalen)\b", n, re.I)
                     for m in Sx0048x_NOTE_RANGE.finditer(n) if Sx0072x_span(m)][:1]
        # any other note with a time stays a note: someone must decide whether it is a time window
        if not times and any(Sx0048x_CLOCK.search(n) for n in notes) and not is_return:
            review.append(f"{where}: the note {' / '.join(notes)!r} names a time, but no time window is set "
                          f"(only '0600u leveren' / 'tussen 0800-1700u' / 'Na 09.00 leveren' / 'voor 12:00 lossen' set one)")
        if not b["goods"]:
            review.append(f"{where}: no goods line (VO-number, weight) under this row")
        odd = [vo for _, vo, _ in b["goods"] if not re.fullmatch(r"VO-\d+", vo)]
        if odd:
            review.append(f"{where}: {odd} does not look like a VO-number; check the goods line")
        if datetime.strptime(b["dates"][1], "%d/%m/%Y") < datetime.strptime(b["dates"][0], "%d/%m/%Y"):
            review.append(f"{where}: the PDF prints the unload date {b['dates'][1]} before the load date "
                          f"{b['dates'][0]}; ask Sx0019x which is right")
        weights = [kg for _, _, kg in b["goods"]]
        if b["subtotal"] is not None and abs(sum(weights) - b["subtotal"]) > 0.5:
            unread.append(f"{where}: the goods lines add up to {sum(weights):g} kg, the PDF prints Subtotaal "
                          f"{b['subtotal']:g} kg - a line was not read")
        # a row with another Laadreferentie than the order's: the driver loads it under that number at Sx0075x
        laadref = f"Laadreferentie {b['laadref']}" if b.get("laadref") and b["laadref"] != ref else None
        for desc, vo, kg in b["goods"] or [(None, None, None)]:
            g = {"quantity": 1}
            if desc: g["description"] = desc
            if kg is not None: g["weight_kg"] = kg
            consignments.append({
                "reference": vo, "instructions": nl_join(laadref, *texts, *notes),
                "pickup": stop(sides[0][0], b["dates"][0], note=sides[0][1]),
                "delivery": stop(sides[1][0], b["dates"][1], start=times[0][0] if times else None,
                                 end=times[0][1] if times else None, note=sides[1][1]),
                "goods": [g],
            })
    # every VO-number printed anywhere on the document (goods lines, notes, the cost table) is a shipment and
    # must be a consignment; one that is not means a shipment is missing from the order
    have = {c["reference"] for c in consignments}
    for vo in dict.fromkeys(re.findall(r"\bVO-\d+\b", text)):
        if vo not in have:
            unread.append(f"{vo} is printed on the document but is not a consignment in the order - a shipment "
                          f"was not read")
    weights = [g["weight_kg"] for c in consignments for g in c["goods"] if "weight_kg" in g]
    if total is None:
        review.append("no 'Totaal Gewicht' line found: check that every row of the PDF is in the order")
    elif abs(sum(weights) - total) > 0.5:
        unread.append(f"the consignments add up to {sum(weights):g} kg, the PDF prints Totaal Gewicht {total:g} kg "
                      f"- a row was not read")
    return {
        "customer": "Sx0019x", "customer_reference": ref, "ritnummer": int(rit),
        "instructions": nl_join(remark, *zero_emission, *laadref_lines),
        "setup": None, "teardown": None, "consignments": consignments,
        "source": src, "key": f"Sx0048x-{rit}",
        **({"review": review} if review else {}),
        **({"unread": unread} if unread else {}),
    }

def Sx0072x_laadreferentie(blocks, head_refs, review, src):
    """The Customer Reference of a Sx0019x rit, and the Instructions lines that list every Laadreferentie
    when the rit prints several. Sx0019x's planning mail names a truck's trip by its Laadreferentie, so the
    Customer Reference stays the Laadreferentie (decided 8 Oct 2026). A Laadreferentie is Sx0075x's loading
    list, and a row moved to this rit after the lists were made keeps the other rit's number (rit 221603 of
    15 Oct 2026: Sx0076x Alkmaar printed 558079, the Laadreferentie of rit 221604; the other four rows 558078).
    Rule: the one above the rows, else the one on most rows, is the Customer Reference; every other one stays
    with its rows (first line of their consignments' instructions, see the caller) and the order Instructions
    list each Laadreferentie with its VO-numbers. No majority: all of them, 'A / B', so Qargo's duplicate
    check (an exact match) still finds a re-sent rit. Returns (customer reference, instructions lines)."""
    rows = [b.get("laadref") for b in blocks]
    printed = list(dict.fromkeys(r for r in rows if r))          # distinct, in printed order
    counts = {r: rows.count(r) for r in printed}
    desc = lambda r: f"{r} ({'above the rows' if r in head_refs else f'{counts[r]} row' + 's' * (counts[r] != 1)})"
    if head_refs:
        ref = next(iter(head_refs))
        if ref not in printed:
            printed.insert(0, ref)
        others = [r for r in printed if r != ref]
    elif printed:
        best = [r for r in printed if counts[r] == max(counts.values())]
        ref = best[0] if len(best) == 1 else " / ".join(printed)
        others = [r for r in printed if r != ref]
    else:
        raise ValueError(f"{src}: no Laadreferentie printed, neither above the rows nor under them")
    if len(printed) < 2:
        return ref, []
    descs = ", ".join(desc(r) for r in printed)
    if ref in printed:
        review.append(f"{len(printed)} Laadreferenties printed ({descs}): {ref} is the Customer Reference; the "
                      f"other(s) are in the instructions of their consignments and in the order Instructions")
    else:
        review.append(f"{len(printed)} Laadreferenties printed ({descs}), none on most rows: all of them are the "
                      f"Customer Reference ({ref}); each is in the instructions of its consignments and in the "
                      f"order Instructions")
    for b in blocks:
        if not b.get("laadref"):
            review.append(f"{b['addr'][0][0]} -> {b['addr'][1][0]}: no Laadreferentie printed under this row, "
                          f"the other rows have one; check which one it belongs to")
    lines = []
    for r in ([ref] if ref in printed else []) + others:
        parts = [f"{', '.join(vo for _, vo, _ in b['goods'])} ({b['addr'][1][0]})"
                 for b in blocks if b.get("laadref") == r and b["goods"]]
        lines.append(f"Laadreferentie {r}: {', '.join(parts)}")
    return ref, lines

def Sx0072x_laadreferenties(o):
    """every Laadreferentie of a Sx0019x order: the Customer Reference (all of them when it is 'A / B') and
    the ones Sx0072x_laadreferentie listed in the Instructions"""
    refs = re.split(r"\s*/\s*", o["customer_reference"])
    return list(dict.fromkeys(refs + re.findall(r"^Laadreferentie (\S+):", o.get("instructions") or "", re.M)))

def Sx0072x_cross_check(orders):
    """A Laadreferentie that one rit prints under some rows and another rit of the same run prints above its
    rows: those rows were moved between the rits (221603 / 221604, 15 Oct 2026). The order with the extra
    number gets a review note that names the other rit, so nobody has to work that out by hand."""
    Sx0072x = [o for o in orders if o.get("customer") == "Sx0019x"]
    owner = {}
    for o in Sx0072x:
        refs = Sx0072x_laadreferenties(o)
        if len(refs) == 1:
            owner.setdefault(refs[0], o)
    for o in Sx0072x:
        refs = Sx0072x_laadreferenties(o)
        if len(refs) < 2:
            continue
        for r in refs:
            other = owner.get(r)
            if other is not None and other is not o:
                o.setdefault("review", []).append(f"Laadreferentie {r} is also the Laadreferentie of rit "
                                                  f"{other['ritnummer']} ({other['source']}) in this run")

# --------------------------------------------------------------------- Sx0010x
# "Truckopdracht" of Sx0077x: a form of "Label : value" lines. The address of a stop runs on
# in the lines under its label; a second field can be printed at the right of a line ("TAR nr. : 3562").
Sx0010x_FIELD = re.compile(r"^(\S[^:]*?)\s+:\s*(.*)$")           # "Uithalen bij          :     CETEM ..."
Sx0010x_RIGHT = re.compile(r"\s{2,}(\S[^:]*?)\s*:\s*(.*)$")       # "... CETEM          TAR nr. : 3562"
Sx0010x_STOPS = ("Uithalen bij", "Container bestemd voor", "Inleveren bij")
Sx0010x_KNOWN = {
    "head": ("Vervoerder", "Truck", "Sx0010x boekingsnr.", "Opdrachtreferentie", "Containernummer", "Containertype",
             "Rederij", "Brutogewicht (kg)", "Gevaargoed details", "Lading"),
    "Uithalen bij": ("TAR nr.", "Tijdslot", "Uithaalreferentie", "Uithalen vanaf datum", "Zeeschip", "Herkomst"),
    "Container bestemd voor": ("Laad-/losdatum / tijd", "Laad-/losreferentie"),
    "Inleveren bij": ("Inleverreferentie", "Zeeschip", "Bestemming", "Uiterlijke inleverdatum", "Let op"),
}
Sx0010x_DATE = re.compile(r"\b(\d{1,2}-\d{1,2}-\d{4})\b")
Sx0010x_TIME = re.compile(r"\b(\d{2}:\d{2})\b")
Sx0010x_DE_PC = re.compile(r"^(\d{5})\s+(\S.*)$")
Sx0010x_COUNTRY = {"nederland": "NL", "netherlands": "NL", "belgië": "BE", "belgie": "BE", "belgium": "BE",
               "duitsland": "DE", "deutschland": "DE", "germany": "DE"}

def Sx0071x_fields(text, src):
    """the form's fields in printed order: [(label, [value lines])], plus the lines printed outside any field.
    Only what is between the 'Truckopdracht' title and the closing text ('Wij vertrouwen op ...') is a field."""
    lines = text.splitlines()
    a = next((i for i, x in enumerate(lines) if "Truckopdracht" in x), None)
    if a is None:
        raise ValueError(f"{src}: no 'Truckopdracht' title")
    b = next((i for i, x in enumerate(lines) if x.strip().startswith("Wij vertrouwen op")), len(lines))
    fields, stray, cur = [], [], None
    for l in lines[a + 1:b]:
        s = l.strip()
        if not s:
            cur = None                                   # a value never runs on across an empty line
            continue
        m = Sx0010x_FIELD.match(l) if not l[0].isspace() else None
        if m is None and Sx0010x_FIELD.match(s) and not re.search(r"\s{2,}", Sx0010x_FIELD.match(s).group(1)):
            m = Sx0010x_FIELD.match(s)                       # a line with only a right-hand field on it
        if m:
            label, rest = m.group(1).strip(), m.group(2)
            right = Sx0010x_RIGHT.search(rest)
            if right:
                rest = rest[:right.start()]
            cur = (label, [rest.strip()] if rest.strip() else [])
            fields.append(cur)
            if right:
                fields.append((right.group(1).strip(), [right.group(2).strip()] if right.group(2).strip() else []))
            continue
        right = Sx0010x_RIGHT.search(s)
        if right:
            s = s[:right.start()].strip()
        if s and cur is not None:
            cur[1].append(s)
        elif s:
            stray.append(s)
        if right:
            fields.append((right.group(1).strip(), [right.group(2).strip()] if right.group(2).strip() else []))
    return fields, stray

def Sx0071x_address(lines, label, src):
    """the lines under 'Uithalen bij' etc.: name (one or more lines), street, 'postcode city', maybe a country"""
    lines = [x for x in lines if x]
    country = None
    if lines and lines[-1].strip().lower() in Sx0010x_COUNTRY:
        country = Sx0010x_COUNTRY[lines.pop().strip().lower()]
    i = next((k for k in range(len(lines) - 1, 0, -1)
              if PC_RE.match(lines[k]) or BE_PC_RE.match(lines[k]) or Sx0010x_DE_PC.match(lines[k])), None)
    if i is None:
        raise ValueError(f"{src}: no 'postcode city' line under '{label}': {lines}")
    if PC_RE.match(lines[i]):
        m = PC_RE.match(lines[i]); pc, city, cc = m.group(1) + m.group(2), m.group(3), "NL"
    elif Sx0010x_DE_PC.match(lines[i]):
        m = Sx0010x_DE_PC.match(lines[i]); pc, city, cc = m.group(1), m.group(2), "DE"
    else:
        m = BE_PC_RE.match(lines[i]); pc, city, cc = m.group(1), m.group(2), "BE"
    street = lines[i - 1]
    name = " ".join(lines[:i - 1]) or street
    return loc(name, street, pc, city, country or cc)

def Sx0071x_when(value):
    """'13-10-2026 06:00 / 13-10-2026 20:30' -> (date, start, end, dates): the first date, the first and second
    time; dates = every date printed, so the caller can see a slot that runs into another day"""
    dates = [dmy(d) for d in Sx0010x_DATE.findall(value or "")]
    times = Sx0010x_TIME.findall(value or "")
    return (dates[0] if dates else None, times[0] if times else None, times[1] if len(times) > 1 else None, dates)

def parse_Sx0071x(text, src):
    """'Truckopdracht' of Sx0077x (Sx0010x), one container per form. Sx0010x boekingsnr. -> Customer
    Reference, Truck -> first line of Instructions, Opdrachtreferentie -> Instructions, the container (type, number,
    Brutogewicht) -> the goods, Containernummer / Rederij -> Qargo's container fields. Uithalen bij -> the first
    stop (Tijdslot -> its window, Uithaalreferentie -> its reference, TAR nr. -> its note), Inleveren bij -> the
    last stop (Inleverreferentie, Uiterlijke inleverdatum -> its date; without one, the date of the stop before it).
    Every other printed value goes to the Instructions.
    Opdrachtreferentie is also the consignment reference. Transport service: always 'Container import/export'
    (decided 14 Oct 2026). Without 'Container bestemd voor' the box goes depot/terminal -> depot/terminal: Export with
    the form's start stop removed, Pickup container -> Drop full container. With a client address: Import (Pickup
    full container -> Delivery at the client -> end stop Drop empty container) or Export (start stop Pickup empty
    container -> Collect at the client -> Drop full container), decided by the Zeeschip lines, else by the
    Containernummer / Lading; undecidable -> no scenario, and the validator refuses the order."""
    out = []
    pages = [p for p in text.split("\f") if p.strip()]
    forms = []
    for p in pages:
        if "Sx0010x boekingsnr." in p and "Truckopdracht" in p:
            forms.append([p])
        elif forms:
            forms[-1].append(p)
        else:
            raise ValueError(f"{src}: a page before the first Truckopdracht")
    for form in forms:
        fields, stray = Sx0071x_fields("\n".join(form), src)
        blocks, name = {"head": {}}, "head"
        dup = []
        for label, lines in fields:
            if label in Sx0010x_STOPS:
                name = label
                blocks[name] = {label: lines}
                continue
            if label in blocks[name]:
                dup.append(label)
                blocks[name][label] += lines
            else:
                blocks[name][label] = lines
        value = lambda block, label: " ".join(blocks.get(block, {}).get(label, [])).strip()
        head = blocks["head"]
        ref = value("head", "Sx0010x boekingsnr.")
        if not ref:
            raise ValueError(f"{src}: no 'Sx0010x boekingsnr.' on the form")
        review, extra = [], []
        for block, labels in blocks.items():
            for label, lines in labels.items():
                if label in Sx0010x_STOPS or label in Sx0010x_KNOWN[block]:
                    continue
                if " ".join(lines).strip():
                    extra.append(f"{label}: {' '.join(lines).strip()}")
                    review.append(f"the field '{label}' is not one the parser knows; its value is kept in the "
                                  f"Instructions")
        for s in stray:
            extra.append(s)
            review.append(f"a line printed outside the fields is kept in the Instructions: {s!r}")
        for label in dict.fromkeys(dup):
            review.append(f"the field '{label}' is printed twice on the form; both values are kept")
        # the container is the goods; its number and shipping line go to Qargo's container fields
        container = " ".join(x for x in (value("head", "Containertype"), value("head", "Containernummer")) if x)
        goods = {"quantity": 1, "description": container or "Container"}
        box = {k: v for k, v in (("number", value("head", "Containernummer")), ("liner", value("head", "Rederij"))) if v}
        kg = value("head", "Brutogewicht (kg)")
        if kg:
            goods["weight_kg"] = Sx0072x_kg(kg)
        c_instr = nl_join(f"Lading: {value('head', 'Lading')}" if value("head", "Lading") else None,
                          f"Gevaargoed: {value('head', 'Gevaargoed details')}" if value("head", "Gevaargoed details") else None)
        # the stops
        stops = {}
        for label in Sx0010x_STOPS:
            if label in blocks and any(x for x in blocks[label][label]):
                stops[label] = Sx0071x_address(blocks[label][label], label, src)
        if "Uithalen bij" not in stops or "Inleveren bij" not in stops:
            raise ValueError(f"{src}: the form needs both 'Uithalen bij' and 'Inleveren bij'; found {sorted(stops)}")
        if "Container bestemd voor" not in stops:
            # no client address, but something filled in under it: that still has to reach the order
            for label, v in blocks.get("Container bestemd voor", {}).items():
                if label != "Container bestemd voor" and " ".join(v).strip():
                    extra.append(f"{label}: {' '.join(v).strip()}")
                    review.append(f"the field '{label}' is filled in, but 'Container bestemd voor' has no address: "
                                  f"its value is kept in the Instructions")
        pick_note = []
        date, start, end, dates = Sx0071x_when(value("Uithalen bij", "Tijdslot"))
        if len(set(dates)) > 1:
            review.append(f"Tijdslot runs from {dates[0]} to {dates[-1]}: Qargo has one date per stop, so the window "
                          f"is kept on the first day")
        since = value("Uithalen bij", "Uithalen vanaf datum")
        if not date and since:
            date = Sx0071x_when(since)[0]
        elif since:
            pick_note.append(f"Uithalen vanaf {since}")
        if not date:
            raise ValueError(f"{src}: no date for the collection (no Tijdslot, no 'Uithalen vanaf datum')")
        if value("Uithalen bij", "TAR nr."):
            pick_note.insert(0, f"TAR nr. {value('Uithalen bij', 'TAR nr.')}")
        for label in ("Zeeschip", "Herkomst"):
            if value("Uithalen bij", label):
                pick_note.append(f"{label}: {value('Uithalen bij', label)}")
        pickup = stop(stops["Uithalen bij"], date, start, end, note=nl_join(*pick_note),
                      reference=value("Uithalen bij", "Uithaalreferentie") or None)
        # the stop at a client in between (Container bestemd voor), if the form has one
        client = None
        if "Container bestemd voor" in stops:
            d2, s2, e2, dates2 = Sx0071x_when(value("Container bestemd voor", "Laad-/losdatum / tijd"))
            if len(set(dates2)) > 1:
                review.append(f"Laad-/losdatum / tijd runs from {dates2[0]} to {dates2[-1]}: Qargo has one date per "
                              f"stop, so the window is kept on the first day")
            if not d2:
                d2 = pickup["date"]
                review.append(f"no date for the stop at {stops['Container bestemd voor']['name']} (Laad-/losdatum / "
                              f"tijd empty): the date of the stop before it, {d2}, is used")
            client = stop(stops["Container bestemd voor"], d2, s2, e2,
                          reference=value("Container bestemd voor", "Laad-/losreferentie") or None)
        d3, s3, e3, _ = Sx0071x_when(value("Inleveren bij", "Uiterlijke inleverdatum"))
        if not d3:
            d3 = (client or pickup)["date"]
            review.append(f"no delivery date on the document (Uiterlijke inleverdatum empty): the date of the stop "
                          f"before it, {d3}, is used")
        del_note = [f"{label}: {value('Inleveren bij', label)}" for label in ("Zeeschip", "Bestemming", "Let op")
                    if value("Inleveren bij", label)]
        delivery = stop(stops["Inleveren bij"], d3, end=e3 or s3, note=nl_join(*del_note),
                        reference=value("Inleveren bij", "Inleverreferentie") or None)
        opdracht = value("head", "Opdrachtreferentie") or None
        cons = lambda p, d: {"reference": opdracht, "instructions": c_instr, "pickup": p, "delivery": d, "goods": [dict(goods)]}
        setup = teardown = None
        # Which of Qargo's container services, and which stops it shows (read off the Create order page, 13 Oct 2026):
        #   Container shunt:            Pickup container -> Drop container (two stops); cargo type "Owned container",
        #                               which Qargo's help defines as containers under the carrier's own control
        #   Container import/export:    cargo type "Seacontainer (import/export)": containers collected full or empty
        #                               on behalf of a client and dropped full or empty (Qargo's help) - every Sx0010x job
        #     Import: Pickup full container -> Delivery (unload at a client) -> end stop Drop empty container
        #     Export: start stop Pickup empty container -> Collect (load at a client) -> Drop full container
        # Import/export is required there; the start/end stop can be removed with its trash icon, which the bot does
        # when the order has no setup/teardown. Decided with Çağatay on 14 Oct 2026: Sx0010x orders are always
        # Container import/export; a form without 'Container bestemd voor' (depot/terminal -> depot/terminal) is
        # Export with the start stop removed: Pickup container -> Drop full container (the only activities that
        # form offers; the label says "full" even when the box is empty).
        service = "Container import/export"
        number, lading = value("head", "Containernummer"), value("head", "Lading")
        if client is None:
            box["scenario"] = "Export"
            pickup["activity"], delivery["activity"] = "Pickup container", "Drop full container"
            consignments = [cons(pickup, delivery)]
            if not number:
                review.append(f"no Containernummer: an empty container of type {value('head', 'Containertype') or '?'} "
                              f"goes from {pickup['location']['name']} to {delivery['location']['name']}; Qargo's Export "
                              f"form can only call the last stop 'Drop full container'")
        else:
            # Import or Export: a sea vessel printed under Inleveren (Zeeschip, Bestemming) means the container
            # leaves by ship after the client = Export; one under Uithalen (Zeeschip, Herkomst) means it arrived
            # by ship and is unloaded at the client = Import. Without a vessel: no Containernummer means the box
            # is picked up empty (any box of that type) and loaded at the client = Export; a numbered box with
            # Lading is a full one unloaded at the client = Import.
            arrived = any(value("Uithalen bij", k) for k in ("Zeeschip", "Herkomst"))
            leaves = any(value("Inleveren bij", k) for k in ("Zeeschip", "Bestemming"))
            if leaves != arrived:
                scenario = "Export" if leaves else "Import"
            elif not number:
                scenario = "Export"
                review.append(f"Import or Export? No sea vessel printed; no Containernummer, so an empty container is "
                              f"picked up at {pickup['location']['name']} and loaded at {client['location']['name']}: "
                              f"Export")
            elif lading:
                scenario = "Import"
                review.append(f"Import or Export? No sea vessel printed; Containernummer and Lading are, so a full "
                              f"container is unloaded at {client['location']['name']}: Import")
            else:
                scenario = None
                review.append("Import or Export? The form names a sea vessel under neither Uithalen nor Inleveren (or "
                              "under both), and a numbered container without Lading says nothing: Qargo's stops depend "
                              "on it, so this order has to be made by hand")
            if scenario:
                box["scenario"] = scenario
            names = (pickup["location"]["name"], client["location"]["name"], delivery["location"]["name"])
            if scenario == "Import":
                pickup["activity"], client["activity"], delivery["activity"] = \
                    "Pickup full container", "Delivery", "Drop empty container"
                consignments, teardown = [cons(pickup, client)], delivery
                review.append("the container goes to %s first (Container bestemd voor): Import in Qargo, Pickup full "
                              "container at %s, Delivery at %s, end stop Drop empty container at %s; check the stops"
                              % (names[1], *names))
            else:
                if scenario:
                    pickup["activity"], client["activity"], delivery["activity"] = \
                        "Pickup empty container", "Collect", "Drop full container"
                    review.append("the container goes to %s first (Container bestemd voor): Export in Qargo, start stop "
                                  "Pickup empty container at %s, Collect at %s, Drop full container at %s; check the "
                                  "stops" % (names[1], *names))
                consignments, setup = [cons(client, delivery)], pickup
        if value("head", "Gevaargoed details"):
            review.append(f"Gevaargoed details printed ({value('head', 'Gevaargoed details')}): set ADR on the cargo "
                          f"item in Qargo, the bot leaves it at 'No dangerous goods'")
        instr = [value("head", "Truck") or None,
                 f"Opdrachtreferentie: {value('head', 'Opdrachtreferentie')}" if value("head", "Opdrachtreferentie") else None,
                 f"Gevaargoed: {value('head', 'Gevaargoed details')}" if value("head", "Gevaargoed details") else None,
                 f"Let op: {value('Inleveren bij', 'Let op')}" if value("Inleveren bij", "Let op") else None] + extra
        out.append({
            "customer": "Sx0010x", "customer_reference": ref, "ritnummer": None,
            "service": service, "container": box, "vehicle_category": "Chassis",      # a container always needs one
            "instructions": nl_join(*instr),
            "setup": setup, "teardown": teardown, "consignments": consignments,
            "source": src, "key": f"Sx0010x-{ref}",
            **({"review": review} if review else {}),
        })
    if not out:
        raise ValueError(f"{src}: no Truckopdracht with an 'Sx0010x boekingsnr.' found")
    return out

# ------------------------------------------------- Sx0002x
# "Transportopdracht" of Sx0002x (Rotterdam): a table of three columns. The first names the part of
# the job (Auto, Container, Opzetten = pick the container up, GASMETEN = a gas measurement on the way, Lossen /
# Laden = the client, Afzetten = drop the container off, Instructies), the second the field, the third its value;
# a long value runs on in the lines under it, and a second field can be printed at the right ("Kenteken ... Chassis").
Sx0003x_STOP_PARTS = ("Opzetten", "GASMETEN", "Lossen", "Laden", "Afzetten")
Sx0003x_CLIENT_FIELDS = ("Adres", "Datum", "Meldtijd", "Handrail", "Referentie", "Lading", "Colli / Verpakking", "Gewicht",
                    "Zegel", "Temperatuur", "Ventilatie (CBM)", "BRIX")
Sx0003x_KNOWN = {
    "Auto": ("Kenteken", "Chassis"),
    "Container": ("Container",),
    "Opzetten": ("Terminal", "Referentie", "Vessel", "Rederij", "Documentatie", "TAR-code", "Tijdslot"),
    "GASMETEN": ("Voorgaand", "Adres"),
    "Lossen": Sx0003x_CLIENT_FIELDS, "Laden": Sx0003x_CLIENT_FIELDS,
    "Afzetten": ("Terminal", "Referentie", "Vessel", "Bestemming", "Rederij", "TAR-code", "Tijdslot", "Closing"),
    "Instructies": (),
}
Sx0003x_ADDRESS = ("Terminal", "Adres")
Sx0003x_FLAGS = ("ADR",)                  # printed next to a field name ("Adres      ADR"): a property, not a value. Not
                                     # printed so far: the 'Voorgaand ADR' on every form is clipped away (pdf_layout.py)
Sx0003x_PENDING = ("volgt", "n.t.b.", "ntb", "nnb", "n.n.b.", "-", "?")      # a terminal Sx0003x does not know yet
Sx0003x_MONTHS = {m: i for i, m in enumerate(("januari", "februari", "maart", "april", "mei", "juni", "juli", "augustus",
                                         "september", "oktober", "november", "december"), 1)}
Sx0003x_NL_DATE = re.compile(r"\b(\d{1,2})\s+(" + "|".join(Sx0003x_MONTHS) + r")\s+(\d{4})\b", re.I)
Sx0003x_NL_PC = re.compile(r"^(\d{4})\s?([A-Z]{2})\b\s*-?\s*(.*)$")
Sx0003x_HARBOUR = re.compile(r"^haven\s*(?:nr\.?|nummer|no\.?)?\s*\d[\d\s/-]*$", re.I)   # 'Havennr 8410': a port's harbour number
Sx0003x_NUM = re.compile(r"Transportopdracht\s+(\d+)")
Sx0003x_BOX = re.compile(r"\b([A-Z]{4})[\s-]*(\d{6})[\s-]*(\d)\b")     # 'TIIU-430440-7' -> the ISO number TIIU4304407
Sx0003x_DEGREES = re.compile(r"^([+\-−]?\s*\d+(?:[.,]\d+)?)\s*(?:°\s*C|graden(?: celsius)?|gr\.?|C)?$", re.I)   # '-18', '+4 °C'

Sx0003x_CONT_REF = re.compile(r"cont(?:ainer)?\.?\s*(?:nr|nummer|no)\.?", re.I)   # 'cont nr': Sx0003x's placeholder for the box number (74940)
Sx0003x_SHUNT = re.compile(r"\boverrijden\b", re.I)      # 'BERTSCHI (OVERRIJDEN)': the full box is driven there and left

def Sx0029x_same_place(a, b):
    """the same building: same country, street and number (any case) and postcode; a Dutch postcode's letters are
    cosmetic for the same street + number (CLAUDE.md, Or-0000221)"""
    street = lambda L: " ".join(L["street"].lower().split())
    pc = lambda L: L["postcode"][:4] if L["country"] == "NL" else L["postcode"]
    return a["country"] == b["country"] and street(a) == street(b) and pc(a) == pc(b) != ""

def Sx0029x_degrees(s):
    """'Temperatuur -18' -> -18, '+4 °C' -> 4, '-18,5' -> -18.5; None when the text is not one number ('-18 / -20',
    'koel'): then Qargo's Requested temperature is for a person to set"""
    m = Sx0003x_DEGREES.match(s.strip())
    if not m:
        return None
    v = float(m.group(1).replace("−", "-").replace("+", "").replace(" ", "").replace(",", "."))
    return int(v) if v == int(v) else v

def Sx0029x_rows(text, src):
    """the order table of one page: [(part, field, [value lines], [flags])] in printed order, plus the text under
    'Instructies' and the lines printed outside the fields. The table is what lies between 'Bij deze verzoeken wij'
    and the conditions ('Op al onze werkzaamheden ...'). The field column starts where the first row's second
    word does ('Auto   Kenteken'), the value column where most values start."""
    lines = text.splitlines()
    a = next((i for i, x in enumerate(lines) if "Bij deze verzoeken wij" in x), None)
    if a is None:
        raise ValueError(f"{src}: no order table ('Bij deze verzoeken wij ...') on the page")
    b = next((i for i, x in enumerate(lines) if x.strip().startswith("Op al onze werkzaamheden")), len(lines))
    body = lines[a + 1:b]
    first = next((segs(l) for l in body if l.strip() and not l[0].isspace() and len(segs(l)) > 1), None)
    if first is None:
        raise ValueError(f"{src}: the order table has no 'part  field' row")
    label_col = first[1][0]
    starts = [s[0] for l in body for s in segs(l) if s[0] > label_col + 1 and s[1] not in Sx0003x_FLAGS]
    if not starts:
        raise ValueError(f"{src}: the order table has no values")
    value_col = max(set(starts), key=starts.count)
    rows, instr, stray, part, cur = [], [], [], None, None
    for l in body:
        if not l.strip():
            cur = None                                   # a value never runs on across an empty line
            continue
        if part == "Instructies":
            instr.append(l.strip())
            continue
        for start, txt in segs(l):
            if start < label_col:
                part, cur = txt, None
                if part == "Instructies":
                    rest = l[start + len(txt):].strip()
                    if rest:
                        instr.append(rest)
                    break
            elif start < value_col and txt in Sx0003x_FLAGS and cur is not None:
                cur[3].append(txt)
            elif start < value_col:
                cur = (part, txt, [], [])
                rows.append(cur)
            elif cur is not None and txt in Sx0003x_KNOWN.get(part, ()) and txt != cur[1]:
                cur = (part, txt, [], [])                # a second field at the right: 'Kenteken ... Chassis ...'
                rows.append(cur)
            elif cur is not None:
                cur[2].append(txt)
            else:
                stray.append(txt)
    return rows, instr, stray

def Sx0029x_address(value, label, src):
    """'ECT Delta, Europaweg 875, 3199 LA, Maasvlakte - Rotterdam' -> location (name = what is printed before the
    street). None when the place is not known yet ('volgt, , ,' or nothing). No postcode: an error, never a guess.
    A harbour number printed as a part of its own ('APM II, Europaweg 910,Havennr 8410, 3199 LC, Rotterdam', 74172)
    is neither the street nor the name: it comes back under 'remarks', for the stop's note."""
    parts = [p.strip() for p in value.split(",") if p.strip()]
    if not parts or (len(parts) == 1 and parts[0].lower() in Sx0003x_PENDING):
        return None
    country = None
    # Access prints a foreign country with its long form in brackets: 'Holdorf Duitsland (Bondsrepubliek)' (74172)
    m = re.match(r"^(.*?)(\S+)\s*\([^()]*\)$", parts[-1])
    if m and m.group(2).lower() in Sx0010x_COUNTRY:
        parts[-1] = (m.group(1) + m.group(2)).strip()
    words = parts[-1].split()
    if words and words[-1].lower() in Sx0010x_COUNTRY:
        country = Sx0010x_COUNTRY[words[-1].lower()]
        parts[-1] = " ".join(words[:-1])
        if not parts[-1]:
            parts.pop()
    for i, p in enumerate(parts):
        if i == 0:
            continue
        m = Sx0003x_NL_PC.match(p) if country in (None, "NL") else None
        if m:
            pc, city, cc = m.group(1) + m.group(2), m.group(3).strip(), "NL"
            break
        m = re.match(r"^(\d{4})(?:\s+(\S.*))?$", p) if country == "BE" else None
        m = m or (re.match(r"^(\d{5})(?:\s+(\S.*))?$", p) if country == "DE" else None)
        if m:
            pc, city, cc = m.group(1), (m.group(2) or "").strip(), country
            break
    else:
        raise ValueError(f"{src}: no 'postcode city' in the address under '{label}': {value!r}")
    if not city and i + 1 < len(parts):
        city = parts[i + 1]
    before = parts[:i]
    remarks = [p for p in before if Sx0003x_HARBOUR.match(p)]
    if remarks and len(remarks) < len(before):
        before = [p for p in before if p not in remarks]
    else:
        remarks = []                     # nothing but a harbour number before the postcode: it is the street
    street = before[-1]
    name = ", ".join(before[:-1]) or street
    L = loc(name, street, pc, city, cc)
    if remarks:
        L["remarks"] = remarks
    return L

def Sx0029x_client_when(value):
    """'woensdag, 14 oktober 2026 10:00 -' -> ('14/10/2026', '10:00', None); '... 08:00 - 12:00' -> both times;
    '... - 12:00' -> only the end; a lone time is a fixed time (start = end)"""
    value = value or ""
    m = Sx0003x_NL_DATE.search(value)
    if m:
        date, rest = f"{int(m.group(1)):02d}/{Sx0003x_MONTHS[m.group(2).lower()]:02d}/{m.group(3)}", value[m.end():]
    else:
        m = Sx0010x_DATE.search(value)
        date, rest = (dmy(m.group(1)), value[m.end():]) if m else (None, value)
    if "-" in rest:
        left, right = rest.split("-", 1)
        s, e = Sx0010x_TIME.search(left), Sx0010x_TIME.search(right)
        return date, s.group(1) if s else None, e.group(1) if e else None
    t = Sx0010x_TIME.search(rest)
    return date, (t.group(1) if t else None), (t.group(1) if t else None)

def parse_Sx0029x(text, src):
    """'Transportopdracht' of Sx0002x (Rotterdam), one container per order, maybe several orders in
    one PDF. Mapping (first guess, 13 Oct 2026, no hand-made order to learn from): the Transportopdracht number
    -> Customer Reference (key Sx0003x-<nr>), the Container -> the goods (and the container number), Opzetten -> the
    terminal the box is picked up at (Tijdslot -> its window, Referentie -> its reference, TAR-code / Vessel /
    Documentatie -> its note), Lossen / Laden -> the client (Datum -> date and times, Referentie, Lading / Gewicht /
    Zegel -> the goods, Temperatuur -> the goods' Requested temperature as well), Afzetten -> the terminal the box
    goes back to (Tijdslot or Closing). The stops follow Qargo's container form: Lossen = Import (Pickup full container -> Delivery -> end stop Drop empty container),
    Laden = Export (start stop Pickup empty container -> Collect -> Drop full container), no client = Export with
    the form's start stop removed (Pickup container -> Drop full container). GASMETEN and any other part with an address on the way is an
    extra stop of the consignment ("stops": the form's Add stop, Position "After <the stop before it>"), dated as
    the stop before it; its line stays in the Instructions too, and a review note asks to check it. A terminal that still reads 'volgt' is a stop the form needs and has not got: the order is
    refused ('unread') until Sx0003x sends it."""
    pages = [p for p in text.split("\f") if p.strip()]
    forms, numbers = {}, []
    for p in pages:
        m = Sx0003x_NUM.search(p)
        if m is None:
            if not numbers:
                raise ValueError(f"{src}: a page without a 'Transportopdracht <number>' title")
            forms[numbers[-1]].append(p)
            continue
        if m.group(1) not in forms:
            forms[m.group(1)] = []
            numbers.append(m.group(1))
        forms[m.group(1)].append(p)
    out = []
    for nr in numbers:
        rows, instr, stray, review, extra, unread = [], [], [], [], [], []
        for n, p in enumerate(forms[nr], 1):
            if "Bij deze verzoeken wij" in p:
                r, i, s = Sx0029x_rows(p, src)
                rows += r; instr += i; stray += s
            elif "Aanvullende instructies" not in p:      # the standard page 2 (Sx0003x's general instructions)
                review.append(f"page {n} of Transportopdracht {nr} is neither the order table nor the standard "
                              f"'Aanvullende instructies': it was not read, look at the PDF")
        if not rows:
            raise ValueError(f"{src}: Transportopdracht {nr} has no order table")
        # the parts of the form in printed order, each with its fields
        blocks, dup = [], []
        for part, field, lines, flags in rows:
            if not blocks or blocks[-1][0] != part:
                blocks.append((part, {}))
            fields = blocks[-1][1]
            if field in fields:
                dup.append(field)
                fields[field][0].extend(lines); fields[field][1].extend(flags)
            else:
                fields[field] = [list(lines), list(flags)]
        def value(fields, label):
            v = " ".join(fields.get(label, [[], []])[0]).strip()
            return "" if v.strip("-, ") == "" else v           # "-" and ", , ," are Sx0003x's empty
        for label in dict.fromkeys(dup):
            review.append(f"the field '{label}' is printed twice on the form; both values are kept")
        for s in stray:
            extra.append(s)
            review.append(f"a line printed outside the fields is kept in the Instructions: {s!r}")
        head = {part: fields for part, fields in blocks if part in ("Auto", "Container")}
        for part, fields in blocks:
            if part in Sx0003x_KNOWN:
                for label in fields:
                    if label not in Sx0003x_KNOWN[part] and value(fields, label):
                        extra.append(f"{label}: {value(fields, label)}")
                        review.append(f"the field '{label}' is not one the parser knows; its value is kept in the "
                                      f"Instructions")
        # the container is the goods; its ISO number goes to Qargo's Container number. Before a box is assigned the
        # field prints the type alone, '(45R1 - REEFER HIGHCUBE CONTAINER)' (74172): no number yet, not that text
        container = value(head.get("Container", {}), "Container")
        goods = {"quantity": 1, "description": container or "Container"}
        box = {}
        m = Sx0003x_BOX.search(container)
        if m:
            box["number"] = "".join(m.groups())
        elif container.split("(")[0].strip():
            box["number"] = container.split("(")[0].strip()
        elif container:
            review.append(f"the Container field reads {container!r}, a container type without a box number: "
                          f"Container number stays empty, fill it in when Sx0002x sends the number")
        # a Referentie that reads 'cont nr' (74940, 26 Oct 2026) is a placeholder for the container number: the box's
        # number when the form prints one, else empty; never that text over a real number in Qargo
        def reference(fields):
            v = value(fields, "Referentie")
            return (box.get("number") if Sx0003x_CONT_REF.fullmatch(v) else v) or None
        # the places on the form, in printed order: {part, place, date, start, end, note, reference}
        places, c_instr, empty_client = [], [], None
        for part, fields in blocks:
            if part in ("Auto", "Container", "Instructies"):
                continue
            address_label = next((l for l in Sx0003x_ADDRESS if l in fields), None)
            printed = value(fields, address_label) if address_label else ""
            place = Sx0029x_address(printed, address_label, src) if address_label else None
            flags = list(dict.fromkeys(f for v in fields.values() for f in v[1]))
            note = place.pop("remarks", []) if place else []      # a harbour number: for the driver, in the stop's note
            date, start, end, missing = None, None, None, None
            if part in ("Opzetten", "Afzetten"):
                date, start, end, dates = Sx0071x_when(value(fields, "Tijdslot"))
                if len(set(dates)) > 1:
                    review.append(f"Tijdslot runs from {dates[0]} to {dates[-1]}: Qargo has one date per stop, so "
                                  f"the window is kept on the first day")
                if not date and value(fields, "Closing"):
                    date, start, end, _ = Sx0071x_when(value(fields, "Closing"))
                    start, end = None, end or start
                elif value(fields, "Closing"):
                    note.append(f"Closing: {value(fields, 'Closing')}")
                for label in ("TAR-code", "Vessel", "Bestemming", "Documentatie"):
                    if value(fields, label):
                        note.append(f"{label}: {value(fields, label)}")
                missing = "Tijdslot and Closing" if "Closing" in fields else "Tijdslot"
                if value(fields, "Rederij"):
                    liner = re.sub(r"\s+,", ",", value(fields, "Rederij"))
                    if "liner" not in box:
                        box["liner"] = liner
                    elif liner != box["liner"]:
                        extra.append(f"Rederij ({part}): {value(fields, 'Rederij')}")
            elif part in ("Lossen", "Laden"):
                date, start, end = Sx0029x_client_when(value(fields, "Datum"))
                for label in ("Meldtijd", "Handrail"):
                    if value(fields, label):
                        note.append(f"{label}: {value(fields, label)}")
                for label in ("Lading", "Colli / Verpakking", "Temperatuur", "Ventilatie (CBM)", "BRIX"):
                    if value(fields, label):
                        c_instr.append(f"{label}: {value(fields, label)}")
                # an export is often sent before loading, with 'Gewicht 0': no weight known yet, not a 0 kg box
                if value(fields, "Gewicht") and Sx0072x_kg(value(fields, "Gewicht")):
                    goods["weight_kg"] = Sx0072x_kg(value(fields, "Gewicht"))
                if value(fields, "Zegel"):
                    box["seal"] = value(fields, "Zegel")
                # a reefer prints 'Temperatuur -18' (74172): Qargo's cargo item has a Requested temperature field, so
                # the number goes there as well (the printed line stays in the consignment instructions above)
                if value(fields, "Temperatuur"):
                    deg = Sx0029x_degrees(value(fields, "Temperatuur"))
                    if deg is None:
                        review.append(f"Temperatuur reads {value(fields, 'Temperatuur')!r}, not one number: set the "
                                      f"Requested temperature of the cargo item in Qargo yourself (the text is in the "
                                      f"consignment instructions)")
                    else:
                        goods["temperature_c"] = deg
                missing = "Datum"
            else:
                rest = []
                if part == "GASMETEN":
                    note.append("Gasmeten" + (" voorgaand" if "Voorgaand" in fields else ""))
                for label in fields:
                    if label not in (address_label, "Referentie") and value(fields, label):
                        (note if part == "GASMETEN" else rest).append(f"{label}: {value(fields, label)}")
                if place is not None:
                    extra += rest
            note += flags
            if place is None:
                # no address: a terminal Sx0003x does not know yet ('volgt'), or a part that is only a remark
                if part == "Afzetten" and address_label:
                    printed = ", ".join(x.strip() for x in printed.split(",") if x.strip()) or "(empty)"
                    unread.append(f"the {part} terminal is not on the document yet ({printed!r}): Qargo's container "
                                  f"form needs that stop, so this order has to wait until Sx0002x sends it")
                elif part in ("Lossen", "Laden") and address_label and not printed.strip(", "):
                    # a client part with an empty Adres: no client stop, the box goes from Opzetten straight to Afzetten.
                    # 74741 (22 Oct 2026): 'Lossen' with nothing but its Datum (Gewicht 0, Instructies 'LEGE CONTAINER!');
                    # Sx0003x confirmed it is only a drop-off, so its date and time go to the Afzetten stop (as for overrijden).
                    # 74837 (22 Oct 2026): 'Laden' with a Referentie, Gewicht 25.000, Zegel and Temperatuur: the box is
                    # loaded at the Opzetten place (Sx0003x: "pickup kramer with ref YMLU5545250"), so its date and time are
                    # the pickup there, the load data stay on the goods and the Referentie is the consignment's. The
                    # printed line stays in the Instructions either way
                    load = [f"{l} {value(fields, l)}" for l in fields
                            if l not in (address_label, "Datum") and value(fields, l)
                            and not (l == "Gewicht" and not Sx0072x_kg(value(fields, "Gewicht")))]
                    if load:
                        extra.append(f"{part}: no address, Datum {value(fields, 'Datum')}, {', '.join(load)} (the "
                                     f"container is {'loaded' if part == 'Laden' else 'unloaded'} at the Opzetten place "
                                     f"and picked up there: Opzetten straight to Afzetten)")
                    else:
                        extra.append(f"{part}: no address, Datum {value(fields, 'Datum')} (only a drop-off: the container goes "
                                     f"from Opzetten straight to Afzetten)")
                    empty_client = {"part": part, "date": date, "start": start, "end": end, "loaded": bool(load),
                                    "reference": reference(fields)}
                elif part in ("Lossen", "Laden", "Opzetten", "Afzetten"):
                    raise ValueError(f"{src}: Transportopdracht {nr}: the part '{part}' has no address ({printed!r})")
                else:
                    for label in fields:
                        if value(fields, label):
                            extra.append(f"{part} {label}: {value(fields, label)}")
                    review.append(f"the part '{part}' of the form has no address: its values are kept in the "
                                  f"Instructions")
                continue
            places.append({"part": part, "place": place, "date": date, "start": start, "end": end, "note": note,
                           "reference": reference(fields), "missing": missing, "printed": printed})
        # Qargo's container form has three stops of its own at most (first terminal, client, last terminal); anything
        # printed between them (GASMETEN, an unknown part with an address) is an extra stop of the consignment: the
        # form's "Add stop" (Stops, Position "After <the stop before it>"; surveyed on the live form 20 Oct 2026)
        kinds = [p["part"] for p in places]
        if kinds.count("Opzetten") != 1 or kinds.count("Afzetten") > 1 or kinds[0] != "Opzetten" \
                or (kinds.count("Afzetten") and kinds[-1] != "Afzetten"):
            raise ValueError(f"{src}: Transportopdracht {nr}: the form's parts are {kinds}; expected Opzetten first, "
                             f"Afzetten last and each of them once")
        clients = [p for p in places if p["part"] in ("Lossen", "Laden")]
        if len(clients) > 1:
            raise ValueError(f"{src}: Transportopdracht {nr}: {len(clients)} client parts ({[c['part'] for c in clients]}); "
                             f"Qargo's container form has one client stop")
        first = places[0]
        last = places[-1] if places[-1]["part"] == "Afzetten" else None
        client = clients[0] if clients else None
        # Overrijden (a shunt): Sx0003x prints the place the full box is driven to as the client, 'BERTSCHI (OVERRIJDEN)',
        # and the same place again as Afzetten (73724, 73876, 74325, 74336, 74561, 74586 of 14-20 Oct 2026). Nothing
        # is unloaded and no empty box comes back: terminal -> that place, as a form with no client part. The client
        # part's date, reference and notes go to the drop stop; its printed line stays in the Instructions.
        if client and last and Sx0003x_SHUNT.search(client["printed"]):
            if Sx0029x_same_place(client["place"], last["place"]):
                L = client["place"]
                extra.append(f"{client['part']}: {client['printed']} (overrijden: the full container is dropped here, "
                             f"not unloaded)")
                if not last["date"]:
                    last.update(date=client["date"], start=client["start"], end=client["end"])
                elif (client["date"], client["start"], client["end"]) != (last["date"], last["start"], last["end"]):
                    last["note"].append(f"{client['part']} Datum: {client['date']} "
                                        + "-".join(t for t in (client["start"], client["end"]) if t))
                if client["reference"] and client["reference"] != last["reference"]:
                    if last["reference"]:
                        last["note"].append(f"{client['part']} Referentie: {client['reference']}")
                    else:
                        last["reference"] = client["reference"]
                last["note"] = list(dict.fromkeys(last["note"] + client["note"]))
                places.remove(client)
                client = None
            else:
                review.append(f"{client['part']} reads {client['printed']!r} (overrijden: drop the full container "
                              f"there?) but Afzetten is another place; the stops are made as printed: check the order")
        elif client and last and Sx0029x_same_place(client["place"], last["place"]):
            review.append(f"{client['part']} and Afzetten are the same place ({client['place']['name']}): the box is "
                          f"{'unloaded' if client['part'] == 'Lossen' else 'loaded'} and left there; if it is only "
                          f"driven over (overrijden), change the order")
        if empty_client and last:
            # the part's date and time: the pickup at Opzetten when the box is loaded there (74837), else the drop-off
            # at Afzetten (74741) - on that stop when it prints no Tijdslot, else in its note
            target = first if empty_client["loaded"] else last
            when = (empty_client["date"], empty_client["start"], empty_client["end"])
            if not target["date"]:
                target.update(date=when[0], start=when[1], end=when[2])
            elif when[0] and when != (target["date"], target["start"], target["end"]):
                target["note"].append(f"{empty_client['part']} Datum: {when[0]} " + "-".join(t for t in when[1:] if t))
        kept = [p for p in (first, client, last) if p]
        on_the_way = []                  # (the extra stop, the form's stop before it)
        for k, p in enumerate(places):
            if p in kept:
                continue
            on_the_way.append((p, next((x for x in places[k - 1::-1] if x in kept), kept[0])))
            L = p["place"]
            # the printed line stays in the Instructions as well (the office sees it on the order)
            extra.append(f"{p['part']}: {L['name']}, {L['street']}, {L['postcode']} {L['city']}"
                         + (f" ({'; '.join(p['note'])})" if p["note"] else "")
                         + (f", ref. {p['reference']}" if p["reference"] else ""))
        # a stop without a date gets the date of the stop before it (the first one: the stop after it)
        for k, p in enumerate(kept):
            if p["date"]:
                continue
            other, side = next((x for x in kept[k - 1::-1] if x["date"]), None) if k else None, "before"
            if other is None:
                other, side = next((x for x in kept[k + 1:] if x["date"]), None), "after"
            if other is None:
                raise ValueError(f"{src}: Transportopdracht {nr}: no date anywhere on the form")
            p["date"] = other["date"]
            review.append(f"no date for the stop at {p['place']['name']} ({p['missing']} empty): the date of the "
                          f"stop {side} it, {p['date']}, is used")
        def mk(p, activity):
            p["activity"] = activity             # an extra stop's Position names it ("After Pickup full container")
            return stop(p["place"], p["date"], p["start"], p["end"], note=nl_join(*p["note"]),
                        reference=p["reference"]) | {"activity": activity}
        cons = lambda a, b: {"reference": None, "instructions": nl_join(*c_instr), "pickup": a, "delivery": b,
                             "goods": [dict(goods)]}
        setup = teardown = None
        # Always "Container import/export" (cargo type "Seacontainer (import/export)": a shipping line's box moved for
        # a client; "Container shunt" is for Sx0004x's own boxes - decided with Çağatay for Sx0010x on 14 Oct 2026, and Sx0003x
        # moves MSC's containers the same way). Qargo's form, read off the Create order page (13 Oct 2026): Lossen (a
        # full box unloaded at the client, it came in by ship) = Import: Pickup full container -> Delivery -> end stop
        # Drop empty container; Laden = Export: start stop Pickup empty container -> Collect -> Drop full container.
        # No client part (terminal -> terminal): Export with the form's start stop removed by the bot (no setup),
        # Pickup container -> Drop full container, the only activities that form offers.
        service = "Container import/export"
        if client is None:
            if last is None:             # Afzetten still 'volgt' (unread says so), or really one stop only
                raise ValueError(f"{src}: Transportopdracht {nr}: " + (unread[0] if unread else
                                 "no client and no Afzetten terminal: one stop only"))
            box["scenario"] = "Export"
            consignments = [cons(mk(first, "Pickup container"), mk(last, "Drop full container"))]
            if empty_client and empty_client["loaded"] and empty_client["reference"]:
                consignments[0]["reference"] = empty_client["reference"]      # the load's Referentie (74837: 82512952)
        else:
            if client["part"] == "Lossen":
                box["scenario"] = "Import"
                consignments = [cons(mk(first, "Pickup full container"), mk(client, "Delivery"))]
                teardown = mk(last, "Drop empty container") if last else None
            else:
                box["scenario"] = "Export"
                if last is None:      # the terminal is still 'volgt': an Export has no delivery stop to put in the file
                    raise ValueError(f"{src}: Transportopdracht {nr}: {unread[0]}")
                setup = mk(first, "Pickup empty container")
                consignments = [cons(mk(client, "Collect"), mk(last, "Drop full container"))]
        # the extra stops: dated as the stop before them (GASMETEN prints no date); Stop action "Gasmeten" is filled
        # only when Qargo has such an internal stop action (Locations > Internal stop actions, type Other)
        for p, before in on_the_way:
            L, position = p["place"], f"After {before['activity']}"
            if not p["date"]:
                p["date"] = before["date"]
                review.append(f"no date for the stop at {L['name']} ({p['part']} prints no date): the date of the "
                              f"stop before it, {p['date']}, is used")
            review.append(f"the stop at {L['name']} ({p['part']}) is an extra stop of the order (Stops: {position}); "
                          f"Qargo's help does not say how the driver's app shows such a stop: check it")
            s = stop(L, p["date"], p["start"], p["end"], note=nl_join(*p["note"]), reference=p["reference"])
            consignments[0].setdefault("stops", []).append(
                {"position": position} | s | ({"activity": "Gasmeten"} if p["part"] == "GASMETEN" else {}))
        auto = head.get("Auto", {})
        instr_lines = [f"{label}: {value(auto, label)}" for label in ("Kenteken", "Chassis") if value(auto, label)]
        flags = list(dict.fromkeys(f for _, fields in blocks for v in fields.values() for f in v[1]))
        if "ADR" in flags:
            where = ", ".join(f"{label} under {part}" for part, fields in blocks for label, v in fields.items() if "ADR" in v[1])
            review.append(f"ADR printed on the form (next to {where}): set ADR on the cargo item in Qargo, the bot "
                          f"leaves it at 'No dangerous goods'")
        # the shipping line goes to Qargo's Ocean liner name; only a different one under another part is kept here
        instr_lines += flags + instr + extra
        out.append(with_unread({
            "customer": "Sx0002x", "customer_reference": nr, "ritnummer": None,
            "service": service, "container": box,
            "instructions": nl_join(*instr_lines),
            "setup": setup, "teardown": teardown, "consignments": consignments,
            "source": src, "key": f"Sx0003x-{nr}",
            **({"review": review} if review else {}),
        }, unread))
    if not out:
        raise ValueError(f"{src}: no 'Transportopdracht <number>' found")
    return out

# ----------------------------------------------------------- Sx0028x
# Sx0020x mails one Transport_order_D<number>.pdf per Sx0004x truck per working day: an Sx0021x DC (Echt or
# Zwaagdijk) as LADEN and LOSSEN, no goods, a price per hour. It is not a trip: the truck's trips that day come
# with Sx0021x's route lists (the ACT- orders). Decided with Çağatay, 21 Oct 2026: no Qargo order of its own; the
# document is recognised and reported, so it is never listed as "not read". Anything else on such a form (goods,
# another place, a line the parser does not know) is refused: the form is then listed as not read.
DV_TITLES = ("TRANSPORT ORDER", "VERVOERSOPDRACHT", "TRANSPORTOPDRACHT")      # since 25 Sep 2026 / 2025-26 / 2024-25
DV_REF = re.compile(r"(?:Our Reference|Onze [Rr]eferentie)\s*:\s*(D\d{5,9})$")
DV_STOP = re.compile(r"(LADEN|LOSSEN)\s+:\s+(\S.*?)\s{2,}(\S.*?)\s{2,}([A-Z]{2})\s+(\d{4}\s?[A-Z]{2}|\d{4,5})\s+(\S.*)")
DV_WHEN = re.compile(r"(?:To execute as from|Uit te voeren vanaf)\s+(\d\d)[-/](\d\d)[-/](\d\d)\s+(\d{1,2}):(\d\d)\s+"
                     r"(?:Reference|Referentie)\s*:\s*(.*)")
DV_GOODS = re.compile(r"(?:Goods|Goederen)\s+KG\s+M3\s+L[ML]")
DV_COUNT = re.compile(r"0\s+(?:Uur|KM)")                   # hours and km, always 0 on the form
DV_PRICE_HEAD = re.compile(r"Agreed Price|Overeengekomen prijs")
DV_PRICE = re.compile(r"(?:Transport|DieselToeslag|Tol)\s+\d+(?:,\d+)?\s+(?:UUR\s+)?(?:at|op|aan)\s+[\d.]+,\d+\s+EUR\s+[\d.]+,\d+\s+EUR")
DV_NO_ORDER = "no order of its own: the trips come with the Sx0021x route lists"


def is_Sx0078x(text):
    page = text.split("\f")[0]
    return ("Sx0028x" in page and any(t in page for t in DV_TITLES)
            and any(DV_REF.fullmatch(l.strip()) for l in page.splitlines()))


def parse_Sx0078x(text, src):
    """A Sx0020x day hire -> one record for the "no order" list (not an order: see above), with what is printed:
    the D-number, the date, the DC, the start time when one is printed, and both References as printed (LADEN:
    "Trekker DD : Sx0001x 1 : Sx0079x", LOSSEN: the DC and stores of the first trip, "9000, 1418, 1316", or a
    remark like "09:00 LAATSTART"). Page 1 is read from the reference to the end of the prices; what comes after
    (Sx0020x's standard conditions, the e-mail footer) and page 2 (the terms) are the same on every form.
    Raises ValueError for a form that is anything else than a day hire at one Sx0021x DC."""
    lines = [l.strip() for l in text.split("\f")[0].splitlines()]
    start = next((i for i, l in enumerate(lines) if DV_REF.fullmatch(l)), None)
    if start is None:
        raise ValueError(f"{src}: no 'Our Reference : D<number>' found")
    ref = DV_REF.fullmatch(lines[start]).group(1)

    def refuse(why):
        raise ValueError(f"{src}: Sx0020x {ref} {why}: not a day hire at one Sx0021x DC, enter it by hand")

    blocks, zone, prices = [], "stops", 0
    for l in lines[start + 1:]:
        if not l:
            continue
        if zone == "stops":
            if (m := DV_STOP.fullmatch(l)):
                if blocks and "date" not in blocks[-1]:
                    refuse(f"prints {blocks[-1]['kind']} without its 'execute as from' line")
                blocks.append({"kind": m[1], "name": m[2], "street": m[3], "country": m[4],
                               "postcode": norm_pc(m[5]), "city": m[6]})
                continue
            if (m := DV_WHEN.fullmatch(l)) and blocks and "date" not in blocks[-1]:
                blocks[-1].update(date=f"{m[1]}/{m[2]}/20{m[3]}", time=f"{int(m[4]):02d}:{m[5]}", reference=m[6].strip())
                continue
            if DV_GOODS.fullmatch(l):
                zone = "goods"
                continue
        elif zone == "goods":
            if DV_COUNT.fullmatch(l):
                continue
            if DV_PRICE_HEAD.fullmatch(l):
                zone = "prices"
                continue
            refuse(f"prints goods or hours ({l!r})")
        elif zone == "prices":
            if DV_PRICE.fullmatch(l):
                prices += 1
                continue
            if prices:            # the total, or (2024-25 form, no total) the standard conditions after the prices
                break
        refuse(f"prints a line the parser does not know ({l!r})")
    else:
        if zone != "prices" or not prices:
            refuse("has no LADEN / LOSSEN, goods and prices as the day hire forms print them")

    kinds = [b["kind"] for b in blocks]
    if kinds not in (["LADEN", "LOSSEN"], ["LOSSEN"]) or any("date" not in b for b in blocks):
        refuse(f"prints {' / '.join(kinds) or 'no LADEN or LOSSEN'}")
    first = blocks[0]
    if any((b["street"], b["postcode"], b["city"]) != (first["street"], first["postcode"], first["city"]) for b in blocks):
        refuse("loads and unloads at different places")
    if not first["name"].lower().startswith("action"):
        refuse(f"is at {first['name']}, not at an Sx0021x DC")
    if len({b["date"] for b in blocks}) > 1:
        refuse("prints two dates")
    laden = next((b for b in blocks if b["kind"] == "LADEN"), None)
    lossen = blocks[-1]
    driver = re.sub(r"^Trekker(?:\s+DD)?\s*:\s*", "", laden["reference"]) if laden and laden["reference"] else None
    rec = {"file": src, "customer": "Sx0028x", "kind": "day_hire", "reference": ref, "date": first["date"],
           "start": laden["time"] if laden and laden["time"] != "00:00" else None,
           "end": lossen["time"] if lossen["time"] != "00:00" else None,
           "place": f"{first['name']}, {first['street']}, {first['postcode']} {first['city']}",
           "driver": driver,
           "references": {b["kind"]: b["reference"] for b in blocks if b["reference"]}}
    when = rec["date"] + (f" from {rec['start']}" if rec["start"] else "") + (f" until {rec['end']}" if rec["end"] else "")
    dc = first["name"] if first["city"].lower() in first["name"].lower() else f"{first['name']} {first['city']}"
    rec["summary"] = " | ".join([ref, when, dc]
                                + [f"{k}: {v}" for k, v in rec["references"].items()])
    return rec

# ------------------------------------------------------------------- Sx0066x
# "Nakliyeci Talimatı / Carrier Instructions" of Sx0066x Türkiye (mailed by noreply.Sx0080x@Sx0081x.com, T0000....pdf): a
# Turkish trailer comes by ferry (RORO) and train to a terminal; the Sx0004x truck collects it there, takes it to
# the customs place(s) and the unloading place(s). One trailer (Position) per PDF. Turkish and English labels.
Sx0066x_TITLE = "Carrier Instructions"
Sx0066x_HEAD = {"trailer": r"Treyler\s*/\s*Trailer", "position": r"Pozisyon\s*/\s*Position", "truck": r"Çekici\s*/\s*Truck",
             "printed": r"Tarih\s*/\s*Date", "driver": r"Şoför\s*/\s*Driver", "ilu": r"ILU Code\s*:"}
Sx0066x_ROUTE = re.compile(r"^(?P<place>\S.*?)\s{2,}(?P<mode>[A-Z][A-Z ]*?)\s{2,}ETA\s*:\s*(?P<eta>\S.*?)\s*$")
Sx0066x_PLACE_HEAD = re.compile(r"Gümrükleme Yeri\s*/\s*Customs Place\s*-\s*(\d+)|Boşaltma Yeri\s*/\s*Unloading Place\s*-\s*(\d+)")
Sx0066x_LOAD = re.compile(r"^KAP\s*:\s*(?P<kap>\d+)?\s+KG\s*:\s*(?P<kg>[\d.,]+)?\s+ETA\s*:\s*(?P<d>\d{2}/\d{2}/\d{4})?\s*(?P<t>\d{1,2}:\d{2})?\s*$")
Sx0066x_WHEN = re.compile(r"^(\d{2})[/.](\d{2})[/.](\d{4})\s+(\d{1,2}):(\d{2})(?::\d{2})?$")
Sx0066x_PC = re.compile(r"^(?P<cc>[A-Z]{2})\s+(?P<pc>\d{4,5})\s*(?P<rest>.*)$")
Sx0066x_POSTBUS = re.compile(r"\s+(POSTBUS|P\.?O\.?\s*BOX)\s+\d+\s*$", re.I)
Sx0066x_TERMINAL_COUNTRY = {"bettembourg": "LU", "ostrava": "CZ", "wels": "AT", "trieste": "IT"}   # else DE (Köln, Karlsruhe ...)

def Sx0081x_when(s):
    """'22/10/2026 08:30:00' / '20.10.2026 15:35:00' -> ('22/10/2026', '08:30'), or None"""
    m = Sx0066x_WHEN.match((s or "").strip())
    return (f"{m[1]}/{m[2]}/{m[3]}", f"{int(m[4]):02d}:{m[5]}") if m else None

def Sx0081x_kg(s):
    """'19.840,00' -> 19840, '8.913,80' -> 8913.8"""
    v = float(s.replace(".", "").replace(",", "."))
    return int(v) if v == int(v) else v

def Sx0081x_address(lines, what, src):
    """the lines of one printed place (name, street, extra lines, 'CC postcode city') -> (location, extra lines).
    'BE 2250ANTWERPEN - TURNHOUT / OLEN' (province - district / town) -> 2250, OLEN; 'BE 9220 OOST-VLAANDEREN -'
    prints no town (city left empty); 'NL 5928 LCVENLO' -> 5928LC, VENLO."""
    lines = [l for l in lines if l]
    k = next((i for i in range(len(lines) - 1, 0, -1) if Sx0066x_PC.match(lines[i])), None)
    if not lines or k is None:
        raise ValueError(f"{src}: the address of the {what} has no 'country postcode town' line: {lines}")
    m = Sx0066x_PC.match(lines[k])
    cc, pc, rest = m["cc"], m["pc"], m["rest"].strip()
    if cc == "NL":
        mn = re.match(r"^([A-Z]{2})\s*(.*)$", rest)
        if not mn:
            raise ValueError(f"{src}: the {what} prints the Dutch postcode {lines[k]!r} without its letters")
        pc, city = pc + mn[1], mn[2]
    elif "/" in rest:
        city = rest.rsplit("/", 1)[1]
    elif re.search(r"\s-\s*$", rest):
        city = ""                        # province - (no town printed)
    else:
        city = rest.rsplit(" - ", 1)[-1]
    name, middle, extra = lines[0], lines[1:k], lines[k + 1:]
    street = next((l for l in middle if re.search(r"\d", l) and not l.startswith("(")), None)
    if street is None:
        raise ValueError(f"{src}: the address of the {what} ({name}) prints no street with a number")
    others = [l for l in middle if l is not street]
    mb = Sx0066x_POSTBUS.search(street)
    if mb:
        others.insert(0, street[mb.start():].strip())
        street = street[:mb.start()].strip()
    return loc(name, street, pc, city.strip(), cc), others + extra

def is_Sx0081x(text):
    page = text.split("\f")[0]
    return Sx0066x_TITLE in page and re.search(Sx0066x_HEAD["position"], page) is not None

def parse_Sx0081x(text, src):
    """A Sx0066x Carrier Instructions PDF -> one order (MAPPING.md, Sx0066x). Stops: the trailer's last terminal (the
    last route line), then the Truck Customs place, each Customs Place-N and Unloading Place-N in printed order;
    the same place printed twice in a row is one stop with both roles in its note. A customs place that is not an
    unloading place is a stop of its own: the leg to it is a consignment without goods, the next unloading place
    is collected from there. Raises ValueError for a form it cannot read whole."""
    lines = [l.rstrip() for l in text.replace("\f", "\n").splitlines()]
    review, extra_instr = [], []
    head = {}
    for l in lines:
        for k, rx in Sx0066x_HEAD.items():
            for m in re.finditer(rx + r"\s+(\S.*?)(?=\s{2,}|$)", l):
                head.setdefault(k, m.group(1).strip())
    ref = head.get("position")
    if not ref or not re.fullmatch(r"\d+", ref):
        raise ValueError(f"{src}: no 'Pozisyon / Position' number found")

    def index(rx, start=0):
        return next((i for i in range(start, len(lines)) if re.search(rx, lines[i])), None)
    i_route, i_book = index(r"GÜZERGAH\s*/\s*ROUTE"), index(r"BOOKING DATE\s*:")
    i_truck = index(r"Tır Gümrüğü Yeri\s*/\s*Truck Customs")
    i_places = [i for i, l in enumerate(lines) if Sx0066x_PLACE_HEAD.search(l)]
    i_notes = index(r"NOTLAR\s*/\s*NOTES")
    if None in (i_route, i_book, i_truck) or not i_places or i_notes is None:
        raise ValueError(f"{src}: Sx0066x {ref}: the Route, Truck Customs, Customs / Unloading Place or Notes part is "
                         f"missing: not the layout the parser knows, enter it by hand")
    i_head_end = i_route

    # the header lines: every line must be one of the known fields
    for l in lines[:i_head_end]:
        rest = l
        for rx in [Sx0066x_TITLE.replace(" ", r"\s+"), r"Nakliyeci Talimatı\s*/"] + \
                  [rx + r"\s+\S.*?(?=\s{2,}|$)" for rx in Sx0066x_HEAD.values()]:
            rest = re.sub(rx, " ", rest)
        if rest.strip():
            extra_instr.append(l.strip())
            review.append(f"a line printed outside the fields is kept in the Instructions: {l.strip()}")

    # route: where the trailer comes from; the last line is the terminal the truck collects it at
    route = []
    for l in lines[i_route + 1:i_book]:
        if not l.strip():
            continue
        m = Sx0066x_ROUTE.match(l.strip())
        if not m:
            raise ValueError(f"{src}: Sx0066x {ref}: route line not read: {l.strip()!r}")
        route.append(m.groupdict())
    if not route:
        raise ValueError(f"{src}: Sx0066x {ref}: no route line, so the place the trailer is collected is not printed")
    booking = re.sub(r"^.*BOOKING DATE\s*:", "", lines[i_book]).strip()

    # Truck Customs: the place on the left, its date and time on the right
    block, when = [], None
    for l in lines[i_truck + 1:i_places[0]]:
        parts = []
        for _, s in segs(l):
            if Sx0081x_when(s) and when is None:
                when = Sx0081x_when(s)
            else:
                parts.append(s)
        if parts:
            block.append(" ".join(parts))
    truck_loc, truck_extra = Sx0081x_address(block, "Truck Customs", src)
    if when is None:
        raise ValueError(f"{src}: Sx0066x {ref}: no date and time printed for the Truck Customs")
    places = [{"loc": truck_loc, "roles": ["Truck customs (Tır Gümrüğü Yeri)"], "extra": truck_extra,
               "date": when[0], "times": [when[1]], "goods": None}]

    # Customs Place-N (left) / Unloading Place-N (right), each pair ending with its KAP / KG / ETA line
    for n, i in enumerate(i_places):
        end = i_places[n + 1] if n + 1 < len(i_places) else i_notes
        hl = lines[i]
        heads = {("customs" if m[1] else "unloading"): (m.start(), m[1] or m[2]) for m in Sx0066x_PLACE_HEAD.finditer(hl)}
        cut = heads["unloading"][0] - 10 if "unloading" in heads else None
        left, right, load = [], [], None
        for l in lines[i + 1:end]:
            if Sx0066x_LOAD.match(l.strip()):
                if load:
                    raise ValueError(f"{src}: Sx0066x {ref}: two KAP / KG lines under one place")
                load = Sx0066x_LOAD.match(l.strip())
                continue
            if load and l.strip():
                raise ValueError(f"{src}: Sx0066x {ref}: a line under the KAP / KG line not read: {l.strip()!r}")
            ls = [s for c, s in segs(l) if cut is None or c < cut]
            rs = [s for c, s in segs(l) if cut is not None and c >= cut]
            if "customs" not in heads and ls:
                raise ValueError(f"{src}: Sx0066x {ref}: text in the customs column without a Customs Place heading")
            left.append(" ".join(ls)); right.append(" ".join(rs))
        if "unloading" not in heads:
            raise ValueError(f"{src}: Sx0066x {ref}: Customs Place-{heads['customs'][1]} has no Unloading Place next "
                             f"to it: not the layout the parser knows, enter it by hand")
        if load is None:
            raise ValueError(f"{src}: Sx0066x {ref}: Unloading Place-{heads['unloading'][1]} has no KAP / KG / ETA line")
        if "customs" in heads:
            c_loc, c_extra = Sx0081x_address(left, f"Customs Place-{heads['customs'][1]}", src)
            places.append({"loc": c_loc, "roles": [f"Customs place {heads['customs'][1]} (Gümrükleme Yeri)"],
                           "extra": c_extra, "date": None, "times": [], "goods": None})
        u_loc, u_extra = Sx0081x_address(right, f"Unloading Place-{heads['unloading'][1]}", src)
        if not load["d"]:
            raise ValueError(f"{src}: Sx0066x {ref}: no ETA date for Unloading Place-{heads['unloading'][1]}")
        goods = {}
        if load["kap"]: goods["quantity"] = int(load["kap"])
        goods["description"] = "packages (KAP)"
        if load["kg"]: goods["weight_kg"] = Sx0081x_kg(load["kg"])
        places.append({"loc": u_loc, "roles": [f"Unloading place {heads['unloading'][1]} (Boşaltma Yeri)"],
                       "extra": u_extra, "date": load["d"], "times": [f"{int(load['t'][:-3]):02d}{load['t'][-3:]}"] if load["t"] else [],
                       "goods": goods})

    notes = [l.strip() for l in lines[i_notes + 1:] if l.strip()]

    # the same place printed twice in a row is one stop
    def same(a, b):
        return (norm_pc(a["postcode"]), re.sub(r"\W", "", a["street"].lower())) == \
               (norm_pc(b["postcode"]), re.sub(r"\W", "", b["street"].lower()))
    merged = []
    for p in places:
        # a customs place printed again further down (Sx0066x-61396862: Customs Place-1 and -2 both Franz-Greiß-Straße 7
        # Köln, Unloading Place-1 between them) is the place the truck was at already: one stop, never a leg from
        # it to itself. The unloading place after it is collected there
        first = next((q for q in merged if not p["goods"] and not q.get("again") and not q["goods"]
                      and same(q["loc"], p["loc"])), None)
        if first is not None and not (merged and merged[-1] is first):
            first["roles"] += [r for r in p["roles"] if r not in first["roles"]]
            first["extra"] += [x for x in p["extra"] if x not in first["extra"]]
            first["times"] += p["times"]
            merged.append({"again": first, "goods": None, "date": True})
            continue
        if merged and not merged[-1].get("again") and same(merged[-1]["loc"], p["loc"]):
            q = merged[-1]
            q["roles"] += p["roles"]
            q["extra"] += [x for x in p["extra"] if x not in q["extra"]]
            q["times"] += p["times"]
            q["date"] = q["date"] or p["date"]
            if p["goods"]:
                q["goods"] = p["goods"]
                q["loc"] = p["loc"]          # the unloading place's own spelling (postcode with its letters spaced)
        else:
            merged.append(dict(p))
    for k, p in enumerate(merged):
        if not p["date"]:
            nxt = next(q for q in merged[k + 1:] if q["date"] and not q.get("again"))
            p["date"] = nxt["date"]
            review.append(f"no date for the stop at {p['loc']['name']} ({' / '.join(p['roles'])} prints no date): "
                          f"the date of the stop after it, {p['date']}, is used")

    def stop_of(p):
        times = sorted(p["times"])
        note = nl_join(", ".join(p["roles"]), *p["extra"], *(notes if p["goods"] else []))
        return stop(p["loc"], p["date"], times[0] if times else None, times[-1] if times else None, note=note)

    last = route[-1]
    t_name = last["place"]
    t_loc = loc(t_name, "", None, None, Sx0066x_TERMINAL_COUNTRY.get(t_name.split()[0].lower(), "DE"), query=t_name)
    t_loc["no_address"] = True           # only a name is printed: never matched on it, stays empty unless it has its own record
    first_date = merged[0]["date"]
    terminal = stop(t_loc, first_date, note=nl_join(
        f"Collect trailer {head.get('trailer', '?')}" + (f" (ILU {head['ilu']})" if head.get("ilu") else ""),
        f"Arrives by {last['mode']}, ETA {last['eta']}"))
    review.append(f"no date for the stop at {t_name} (the route {last['mode']} ETA {last['eta']} prints no date): "
                  f"the date of the stop after it, {first_date}, is used")

    consignments, frm = [], terminal
    for p in merged:
        if p.get("again"):
            frm = stop_of(p["again"])
            continue
        s = stop_of(p)
        if p["goods"]:
            consignments.append({"pickup": frm, "delivery": s, "goods": [p["goods"]]})
        else:
            consignments.append({"pickup": frm, "delivery": s,
                                 "instructions": f"Trailer {head.get('trailer', '?')} to {' / '.join(p['roles'])}"})
            frm = dict(s)
    if not any(p["goods"] for p in merged):
        raise ValueError(f"{src}: Sx0066x {ref}: no unloading place read")

    instr = [f"Truck {head['truck']}" if head.get("truck") else None,
             f"Trailer {head.get('trailer', '?')}" + (f", ILU {head['ilu']}" if head.get("ilu") else ""),
             f"Driver: {head['driver']}" if head.get("driver") else None,
             "Route: " + "; ".join(f"{r['place']} {r['mode']} ETA {r['eta']}" for r in route),
             f"Booking date: {booking}" if booking else None,
             f"Sx0066x position {ref}, printed {head['printed']}" if head.get("printed") else None,
             *extra_instr, *notes]
    return {"customer": "Sx0066x Türkiye", "customer_reference": ref, "ritnummer": None,
            "instructions": nl_join(*instr), "setup": None, "teardown": None,
            "consignments": consignments, "source": src, "key": f"Sx0066x-{ref}",
            **({"review": review} if review else {})}

# ------------------------------------------------------------------- main
def detect(text):
    if "Sx0082x" in text and "Chauffeurs instructie" in text: return "Sx0073x"
    if "Sx0014x" in text and "TRANSPORTOPDRACHT" in text: return "Sx0047x"
    if "Route-inhoud" in text and "Dienstnummer" in text: return "Sx0026x"
    if "Sx0074x" in text and "Laadreferentie" in text: return "Sx0022x"
    if "Sx0077x" in text and "Truckopdracht" in text: return "Sx0071x"
    if ("Sx0083x" in text or "Sx0052x" in text) and "Transportopdracht" in text: return "Sx0029x"
    if is_Sx0078x(text): return "Sx0078x"           # a day hire: no order of its own (parse_Sx0078x)
    if is_Sx0081x(text): return "Sx0081x"
    if Sx0027x_mail.is_Sx0027x_text(text): return "Sx0027x"      # a rit PDF the mail check wrote from an Sx0017x planning mail
    if Sx0057x_mail.is_Sx0057x_text(text): return "Sx0057x"   # a row PDF the mail check wrote from a Sx0058x schedule mail
    return None

def resolve_coupling(orders):
    """Coupling/uncoupling places are printed as one string without postcode, e.g.
    'DCT Pegasusweg 1 Tilburg'. Match them to a street seen elsewhere in the batch."""
    known = {}
    for o in orders:
        for c in o["consignments"]:
            for s in (c["pickup"], c["delivery"]):
                L = s["location"]
                if L.get("street"): known.setdefault(L["street"].lower(), L)
    for o in orders:
        for key in ("setup", "teardown"):
            s = o.get(key)
            if not s or "raw" not in s["location"]: continue
            raw = s["location"]["raw"]
            hit = None
            for st, L in sorted(known.items(), key=lambda kv: -len(kv[0])):
                if st and st in raw.lower():
                    hit = L; break
            if hit:
                s["location"] = dict(hit, name=raw)
            else:
                m = re.search(r"([A-Za-z][\w'.-]*\s+\d+(?:\s?[A-Z]\b)?)\s+([A-Za-z][\w -]*)$", raw)
                street, city = (m.group(1), m.group(2)) if m else (raw, "")
                s["location"] = loc(raw, street, None, city)
                s["location"]["unverified"] = True

def add_page_ranges(orders, text):
    """Several orders in one PDF (Sx0014x: 2-3 rits, Sx0016x: several routes, Sx0010x / Sx0003x: several forms): give each its pages
    ([first, last], 1-based, inclusive: its own first page up to the page before the next order), so the bot attaches
    only those pages ("Select page range" in Qargo). An order whose first page can't be found gets the whole PDF."""
    if len(orders) < 2:
        return
    pages = text.split("\f")
    last = max((i for i, pg in enumerate(pages, 1) if pg.strip()), default=1)
    marker = {"Sx0014x": r"REFERENTIENUMMER:\s*{}\b", "Sx0016x": r"Dienstnummer\s+{}\b",
              "Sx0010x": r"Sx0010x boekingsnr\.\s*:\s*{}\b", "Sx0002x": r"Transportopdracht\s+{}\b"}
    def first_page(o):
        rx = marker.get(o["customer"], "").format(re.escape(o["customer_reference"]))
        return next((i for i, pg in enumerate(pages, 1) if rx and re.search(rx, pg)), None)
    starts = [(first_page(o), n) for n, o in enumerate(orders)]
    found = sorted(s for s in starts if s[0] is not None)
    for k, (s, n) in enumerate(found):
        orders[n]["pages"] = [s, found[k + 1][0] - 1 if k + 1 < len(found) else last]
    for s, n in starts:
        if s is None:
            orders[n].setdefault("review", []).append("could not find this order's pages in the PDF: the whole PDF "
                                                      "is attached (it holds other orders too)")

def parse_paths(paths, uncouple_as_note=False, no_order=None):
    """PDFs and folders of PDFs -> (orders, skipped). skipped = file names that could not be read,
    with the reason; one bad PDF never stops the others.
    no_order: a list that gets one record (dict, see parse_Sx0078x) per document the parser knows and that makes
    no order (a Sx0020x day hire). Without that list such a document goes to skipped as "name (DAY HIRE: ...)",
    so a caller that does not know about them still lists it instead of dropping it in silence."""
    global KEEP_UNCOUPLE
    KEEP_UNCOUPLE = not uncouple_as_note
    files = []
    for p in paths:
        p = Path(p).expanduser()
        files += sorted(f for f in p.iterdir() if f.suffix.lower() == ".pdf") if p.is_dir() else [p]
    orders, skipped = [], []
    for f in files:
        try:
            t = pdftext(f); kind = detect(t)
            if kind == "Sx0073x": found = [parse_Sx0073x(t, f.name)]
            elif kind == "Sx0022x": found = [parse_Sx0022x(t, f.name)]
            elif kind == "Sx0081x": found = [parse_Sx0081x(t, f.name)]
            elif kind == "Sx0027x": found = Sx0027x_mail.parse_text(t, f.name)
            elif kind == "Sx0057x": found = Sx0057x_mail.parse_text(t, f.name)
            elif kind in ("Sx0047x", "Sx0026x", "Sx0071x", "Sx0029x"):
                found = {"Sx0047x": parse_Sx0047x, "Sx0026x": parse_Sx0026x, "Sx0071x": parse_Sx0071x, "Sx0029x": parse_Sx0029x}[kind](t, f.name)
                add_page_ranges(found, t)
            elif kind == "Sx0078x":
                rec = parse_Sx0078x(t, f.name)
                if no_order is None:
                    skipped.append(f"{f.name} (DAY HIRE: Sx0020x {rec['summary']} - {DV_NO_ORDER})")
                else:
                    no_order.append(rec)
                continue
            else:
                skipped.append(f.name); continue
            if CHANGE_FILE.search(f.name):
                for o in found: o["change"] = True
            orders += found
        except Exception as e:
            skipped.append(f"{f.name} ({type(e).__name__}: {e})")
    resolve_coupling(orders)
    Sx0072x_cross_check(orders)
    return latest_changes(orders, files), skipped

# A document that changes orders the customer sent before: Sx0016x mails a "Routemutatie" (W42Routemutatie31918P.pdf)
# in the same layout as the Route-inhoud, holding the whole route again as it is now. Its orders get "change": the
# bot edits the order Qargo has with that customer reference instead of making a second one.
CHANGE_FILE = re.compile(r"mutatie", re.I)

def latest_changes(orders, files):
    """One order per key. A change replaces the order read from the customer's first document (that route is no
    longer what they want), and of two changes to one order the one from the newest file counts."""
    age = {f.name: (f.stat().st_mtime, f.name) for f in files if f.exists()}
    best = {}
    for o in orders:
        k = o["key"]
        if not o.get("change"):
            best.setdefault(k, o)
        elif not best.get(k, {}).get("change") or age.get(o["source"], (0, "")) >= age.get(best[k]["source"], (0, "")):
            best[k] = o
    keep = []
    for o in orders:
        if best[o["key"]] is o:
            keep.append(o)
        elif best[o["key"]].get("change"):
            print(f"{o['key']} from {o['source']}: left out, {best[o['key']]['source']} changes it", file=sys.stderr)
        else:
            keep.append(o)          # the same order twice, neither a change: run.py / the app leave the second out
    return keep

def print_no_order(records):
    """the documents that make no order, one line each (run.py and the command line)"""
    if records:
        print(f"Sx0020x day hires, {DV_NO_ORDER}:")
        for r in records:
            print(f"  {r['summary']}  ({r['file']})")

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("paths", nargs="+")
    ap.add_argument("-o", "--out", default="orders.json")
    ap.add_argument("--uncouple-as-note", action="store_true",
                    help="Sx0013x: put Afkoppelen in the Instructions instead of an end stop")
    a = ap.parse_args()
    no_order = []
    orders, skipped = parse_paths(a.paths, a.uncouple_as_note, no_order=no_order)
    Path(a.out).write_text(json.dumps(orders, indent=1, ensure_ascii=False), encoding="utf-8")
    print(f"{len(orders)} orders -> {a.out}")
    print_no_order(no_order)
    if skipped:
        print(f"!! NOT READ (unknown layout, enter these another way): {skipped}")
    errors, warnings = validate(orders)
    report(errors, warnings)
    if errors:
        print(f"!! {len({k for k, _ in errors})} order(s) have errors; qargo_fill.py will refuse them")
        sys.exit(1)

if __name__ == "__main__":
    main()
